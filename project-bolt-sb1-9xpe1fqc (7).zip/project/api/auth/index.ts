// api/auth/index.ts
import { serve } from "bun";
import bcrypt from "bcryptjs";
import jwt from "jsonwebtoken";
import { createClient } from "@supabase/supabase-js";
import crypto from "crypto";

const JWT_SECRET = process.env.JWT_SECRET || "super-secret-key";
const SUPABASE_URL = process.env.VITE_SUPABASE_URL!;
const SUPABASE_SERVICE_KEY = process.env.SUPABASE_SERVICE_ROLE_KEY!;

const supabase = createClient(SUPABASE_URL, SUPABASE_SERVICE_KEY);

async function checkPasswordLeaked(password: string): Promise<boolean> {
  try {
    const hash = crypto.createHash("sha1").update(password).digest("hex").toUpperCase();
    const prefix = hash.substring(0, 5);
    const suffix = hash.substring(5);

    const response = await fetch(`https://api.pwnedpasswords.com/range/${prefix}`);
    const data = await response.text();

    const lines = data.split("\n");
    for (const line of lines) {
      const [hashSuffix] = line.split(":");
      if (hashSuffix === suffix) {
        return true;
      }
    }
    return false;
  } catch (error) {
    console.error("Password leak check failed:", error);
    return false;
  }
}

function jsonResponse(data: any, status = 200) {
  return new Response(JSON.stringify(data), {
    status,
    headers: {
      "Content-Type": "application/json",
      "Access-Control-Allow-Origin": "*",
      "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
      "Access-Control-Allow-Headers": "Content-Type, Authorization",
    },
  });
}

serve({
  async fetch(req) {
    const url = new URL(req.url);
    const path = url.pathname;
    const method = req.method;

    console.log("Incoming request:", path, method);

    // ✅ handle preflight CORS
    if (method === "OPTIONS") {
      return new Response(null, {
        status: 200,
        headers: {
          "Access-Control-Allow-Origin": "*",
          "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
          "Access-Control-Allow-Headers": "Content-Type, Authorization",
        },
      });
    }

    // ✅ SIGNUP
    if (path === "/api/auth/signup" && method === "POST") {
      try {
        const { email, username, password, country } = await req.json();
        if (!email || !username || !password)
          return jsonResponse({ error: "Missing fields" }, 400);

        const isLeaked = await checkPasswordLeaked(password);
        if (isLeaked) {
          return jsonResponse({
            error: "This password has been compromised in a data breach. Please choose a different password."
          }, 400);
        }

        const { data: existingUser } = await supabase
          .from("users")
          .select("id")
          .or(`email.eq.${email},username.eq.${username}`)
          .single();

        if (existingUser) {
          return jsonResponse({ error: "Email or username already exists" }, 400);
        }

        const hashed = await bcrypt.hash(password, 10);

        const { data: newUser, error } = await supabase
          .from("users")
          .insert({
            email,
            username,
            password_hash: hashed,
            country: country || null,
          })
          .select()
          .single();

        if (error) {
          console.error("Database error:", error);
          return jsonResponse({ error: "Failed to create user" }, 500);
        }

        const token = jwt.sign({ id: newUser.id, email }, JWT_SECRET, { expiresIn: "7d" });

        return jsonResponse({
          user: {
            id: newUser.id,
            email: newUser.email,
            username: newUser.username,
            avatar_url: newUser.avatar_url,
            country: newUser.country
          },
          token
        });
      } catch (err) {
        console.error("Signup error:", err);
        return jsonResponse({ error: "Signup failed" }, 500);
      }
    }

    // ✅ LOGIN
    if (path === "/api/auth/login" && method === "POST") {
      try {
        const { email, password } = await req.json();
        if (!email || !password)
          return jsonResponse({ error: "Missing email or password" }, 400);

        const { data: user, error } = await supabase
          .from("users")
          .select("*")
          .eq("email", email)
          .single();

        if (error || !user) {
          return jsonResponse({ error: "Invalid credentials" }, 401);
        }

        const valid = await bcrypt.compare(password, user.password_hash);
        if (!valid) return jsonResponse({ error: "Invalid credentials" }, 401);

        const token = jwt.sign({ id: user.id, email }, JWT_SECRET, { expiresIn: "7d" });
        return jsonResponse({
          user: {
            id: user.id,
            email: user.email,
            username: user.username,
            avatar_url: user.avatar_url,
            country: user.country
          },
          token
        });
      } catch (err) {
        console.error("Login error:", err);
        return jsonResponse({ error: "Login failed" }, 500);
      }
    }

    // ✅ Protected route
    if (path === "/api/auth/me" && method === "GET") {
      try {
        const auth = req.headers.get("Authorization");
        if (!auth || !auth.startsWith("Bearer "))
          return jsonResponse({ error: "Unauthorized" }, 401);

        const token = auth.split(" ")[1];
        const decoded = jwt.verify(token, JWT_SECRET) as any;

        const { data: user, error } = await supabase
          .from("users")
          .select("*")
          .eq("id", decoded.id)
          .single();

        if (error || !user) {
          return jsonResponse({ error: "User not found" }, 404);
        }

        return jsonResponse({
          user: {
            id: user.id,
            email: user.email,
            username: user.username,
            avatar_url: user.avatar_url,
            country: user.country
          }
        });
      } catch {
        return jsonResponse({ error: "Invalid token" }, 401);
      }
    }

    // fallback
    return jsonResponse({ error: "Not found" }, 404);
  },
});
