# Authentication Setup - Real Backend API

## What Changed

The frontend authentication system has been updated to connect to the **real backend API** instead of using mock localStorage data.

### Previous Issue
- Frontend was using mock auth (localStorage only)
- Users created in one browser couldn't log in in another browser
- No persistent user data across sessions

### Current Solution
- Frontend now connects to real backend API at `http://localhost:3001`
- User data persists on the server
- Accounts can be accessed from any browser/device
- Tokens validated by backend

## How to Test

### Step 1: Make Sure Backend is Running
Your backend should be running on `http://localhost:3001` with these endpoints:
- `POST /api/auth/signup` - Create new account
- `POST /api/auth/login` - Login with credentials
- `GET /api/auth/me` - Get current user (requires token)

### Step 2: Create an Account
1. Go to the login page
2. Click "Don't have an account? Sign up"
3. Enter:
   - **Username**: Any username (e.g., `testuser`)
   - **Email**: Valid email format (e.g., `test@example.com`)
   - **Password**: At least 6 characters
4. Click "Sign Up"
5. If successful, you'll be logged in and see the home page

### Step 3: Test Login
1. Click the user menu and select "Logout"
2. Enter the same email and password
3. Click "Log In"
4. You should be logged in again

### Step 4: Test Persistence
1. After logging in, refresh the page (F5)
2. You should remain logged in
3. The token is saved in browser localStorage

## API Endpoints Used

```
POST /api/auth/signup
Body: { username, email, password }
Response: { user: { id, username, email }, token }

POST /api/auth/login
Body: { email, password }
Response: { user: { id, username, email }, token }

GET /api/auth/me
Headers: Authorization: Bearer <token>
Response: { user: { id, username, email } }
```

## Files Modified

**src/lib/customAuth.ts** (complete rewrite)
- Removed mock localStorage system
- Added real API calls to backend
- Updated `signup()`, `login()`, `getCurrentUser()` to use `/api/auth/*` endpoints
- Proper error handling for API failures

## Session Storage

Sessions persist using:
- **Token**: Stored in `auth_token` (localStorage)
- **User**: Stored in `auth_user` (localStorage)
- Both tokens are validated against the backend

## Error Messages

You may see these errors:
- **"Invalid credentials"** - Email not found or wrong password
- **"User already exists"** - Email already registered
- **"Missing fields"** - Form validation failed
- **Request failed** - Backend connection issue

## Troubleshooting

### Backend not running?
If you see "Request failed" errors, make sure the backend API is running on port 3001:
```bash
# Check if backend is running
curl http://localhost:3001/api/auth/login
```

### User not found after signup?
This means the backend received the signup request. The user should be stored on the server.

### Token expired?
The backend issues 7-day tokens. If you see "Invalid token", your session expired.

## Next Steps

Once authentication is working, you can:
1. Create new user profiles
2. Add follow/follower relationships
3. Implement profile page (currently has a minor API issue)
4. Add live streaming features
5. Add monetization features
