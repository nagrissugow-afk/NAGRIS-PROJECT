# Custom Authentication System Documentation

## Overview

This application now uses a **complete custom authentication system** built with:
- **Database**: Supabase PostgreSQL (standalone users table)
- **Backend**: Supabase Edge Functions with Express-like routing
- **Password Security**: Bcrypt hashing (salt rounds 10+)
- **Session Management**: JWT tokens (7-day expiration)
- **Storage**: Browser localStorage

## Architecture

### Backend (Edge Functions)

**Location**: `/supabase/functions/auth/index.ts`

**Endpoints**:

1. **POST /auth/signup**
   - Creates new user account
   - Validates username uniqueness
   - Validates email uniqueness
   - Hashes password with bcrypt
   - Returns user object + JWT token
   - Automatically creates wallet for new users

2. **POST /auth/login**
   - Authenticates existing user
   - Verifies email and password
   - Checks if account is blocked
   - Returns user object + JWT token

3. **POST /auth/forgot-password**
   - Sends password reset token
   - Token valid for 1 hour
   - Currently logs to console (replace with email service in production)

4. **POST /auth/reset-password**
   - Accepts reset token + new password
   - Verifies token validity and expiration
   - Updates password hash
   - Clears reset token

5. **GET /auth/me**
   - Returns current user data
   - Requires valid JWT in Authorization header
   - Used for session validation

### Frontend

**Auth Library**: `/src/lib/customAuth.ts`

Functions:
- `signup(username, email, password)` - Create account
- `login(email, password)` - Authenticate user
- `logout()` - Clear session and redirect
- `forgotPassword(email)` - Request password reset
- `resetPassword(token, newPassword)` - Complete password reset
- `getCurrentUser()` - Validate and refresh session
- `isAuthenticated()` - Check if user is logged in
- `requireAuth(redirectTo)` - Redirect if not authenticated

**Auth Context**: `/src/lib/newAuthContext.tsx`

Provides:
- `user` - Current user object or null
- `loading` - Initial auth check state
- `isAuthenticated` - Boolean authentication status
- `logout()` - Logout function
- `refreshUser()` - Refresh user data

**Auth UI**: `/src/components/NewAuthPage.tsx`

Features:
- Login form (email + password)
- Signup form (username + email + password)
- Forgot password form
- Reset password form
- Password visibility toggle
- Error handling
- Loading states

**Route Protection**: `/src/components/ProtectedRoute.tsx`

Wraps protected routes and redirects unauthenticated users to home page.

## Database Schema

**Table**: `users`

```sql
CREATE TABLE users (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  username text UNIQUE NOT NULL,
  email text UNIQUE NOT NULL,
  password_hash text NOT NULL,
  bio text DEFAULT '',
  avatar_url text DEFAULT '',
  country text DEFAULT 'US',
  followers_count integer DEFAULT 0,
  following_count integer DEFAULT 0,
  total_likes integer DEFAULT 0,
  total_views bigint DEFAULT 0,
  is_verified boolean DEFAULT false,
  kyc_status text DEFAULT 'not_submitted',
  kyc_documents jsonb DEFAULT '{}'::jsonb,
  fraud_score integer DEFAULT 0,
  is_blocked boolean DEFAULT false,
  last_username_change timestamptz DEFAULT now(),
  reset_token text,
  reset_token_expires timestamptz,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);
```

**Indexes**:
- `idx_users_email` - Fast login lookups
- `idx_users_username` - Username uniqueness checks
- `idx_users_reset_token` - Password reset flow

**RLS Policies**:
- Public signup (anyone can insert)
- Public profile viewing (SELECT allowed)
- Self-update only (users can only update their own data)

## Security Features

1. **Password Security**
   - Bcrypt hashing with salt
   - Minimum 6 characters required
   - Never stored in plain text
   - Never exposed in API responses

2. **JWT Tokens**
   - HMAC-SHA256 signing
   - 7-day expiration
   - Stored in localStorage
   - Sent via Authorization header

3. **Username Change Limit**
   - Users can only change username once every 20 days
   - Tracked via `last_username_change` timestamp

4. **Account Protection**
   - Blocked accounts cannot login
   - Email and username uniqueness enforced at database level
   - Reset tokens expire after 1 hour

5. **Input Validation**
   - Username: minimum 3 characters
   - Email: valid format required
   - Password: minimum 6 characters

## Protected Routes

The following routes require authentication:

- `/upload` - Video upload page
- `/wallet` - Wallet and earnings
- `/profile` - User profile (own profile only)

Unauthenticated users are redirected to the home page.

## Environment Variables

```env
VITE_SUPABASE_URL=your_supabase_url
VITE_SUPABASE_ANON_KEY=your_anon_key
SUPABASE_SERVICE_ROLE_KEY=your_service_role_key
JWT_SECRET=your-super-secret-jwt-key
```

**Important**: Change `JWT_SECRET` in production!

## Testing Checklist

### Signup Flow
- [ ] Create account with valid username, email, password
- [ ] Error on duplicate email
- [ ] Error on duplicate username
- [ ] Error on password < 6 characters
- [ ] Successful signup redirects to home page
- [ ] JWT token stored in localStorage
- [ ] User data stored in localStorage

### Login Flow
- [ ] Login with correct credentials
- [ ] Error on incorrect password
- [ ] Error on non-existent email
- [ ] Error on blocked account
- [ ] Successful login redirects to home page
- [ ] JWT token stored in localStorage

### Session Persistence
- [ ] Refresh browser - user stays logged in
- [ ] Close and reopen browser - user stays logged in
- [ ] Token expiration (after 7 days) logs user out

### Logout Flow
- [ ] Logout button clears localStorage
- [ ] Logout redirects to home page
- [ ] Cannot access protected routes after logout

### Password Reset Flow
- [ ] Enter email on forgot password page
- [ ] Reset token generated (check console logs)
- [ ] Reset token works on reset password page
- [ ] New password updates successfully
- [ ] Can login with new password
- [ ] Old password no longer works
- [ ] Expired token (1 hour) shows error

### Route Protection
- [ ] Access /upload while logged out → redirected
- [ ] Access /wallet while logged out → redirected
- [ ] Access /profile while logged out → redirected
- [ ] Access protected routes while logged in → success

### Username Constraints
- [ ] Username must be unique
- [ ] Username cannot be changed more than once in 20 days

## Migration from Supabase Auth

This system replaces Supabase Auth completely. Key differences:

| Feature | Supabase Auth | Custom Auth |
|---------|---------------|-------------|
| User Table | `auth.users` | `public.users` |
| Authentication | OAuth, Magic Links, Email/Password | Email/Password only |
| Session Storage | Supabase manages | localStorage JWT |
| Password Storage | Supabase manages | Bcrypt in database |
| Reset Flow | Email service required | Custom token system |

## Production Considerations

1. **Email Service**
   - Replace console.log in forgot-password endpoint
   - Integrate SendGrid, AWS SES, or similar
   - Send professional reset emails with branded templates

2. **JWT Secret**
   - Generate strong random secret (32+ characters)
   - Store in environment variables
   - Never commit to git

3. **Rate Limiting**
   - Add rate limiting to auth endpoints
   - Prevent brute force attacks
   - Limit failed login attempts

4. **HTTPS**
   - Always use HTTPS in production
   - JWT tokens sent over secure connection only

5. **Token Refresh**
   - Consider implementing refresh tokens
   - Current system: 7-day expiration
   - Optional: Add automatic token refresh

6. **Monitoring**
   - Log authentication attempts
   - Monitor failed login rates
   - Track suspicious activity

7. **Backup**
   - Regular database backups
   - User data is critical
   - Test restore procedures

## API Usage Examples

### Signup
```typescript
import { signup } from './lib/customAuth';

try {
  const { user, token } = await signup('johndoe', 'john@example.com', 'password123');
  console.log('Signed up:', user);
} catch (error) {
  console.error('Signup failed:', error.message);
}
```

### Login
```typescript
import { login } from './lib/customAuth';

try {
  const { user, token } = await login('john@example.com', 'password123');
  console.log('Logged in:', user);
} catch (error) {
  console.error('Login failed:', error.message);
}
```

### Logout
```typescript
import { logout } from './lib/customAuth';

logout(); // Clears session and redirects
```

### Check Authentication
```typescript
import { isAuthenticated, getUser } from './lib/customAuth';

if (isAuthenticated()) {
  const user = getUser();
  console.log('Current user:', user);
} else {
  console.log('Not logged in');
}
```

### Password Reset
```typescript
import { forgotPassword, resetPassword } from './lib/customAuth';

// Request reset
const result = await forgotPassword('john@example.com');
console.log(result.message);

// Reset password
await resetPassword('reset-token-here', 'newpassword123');
```

## Troubleshooting

### "Invalid email or password"
- Check email is correct
- Check password is correct
- Verify user exists in database

### "Email already exists"
- Email is already registered
- Try logging in instead
- Use password reset if forgot password

### "Username already taken"
- Choose different username
- Usernames must be unique

### "Unauthorized" on protected routes
- JWT token missing or expired
- Login again to get new token
- Check localStorage for auth_token

### Session not persisting
- Check localStorage is enabled
- Verify JWT_SECRET matches on client/server
- Check token expiration (7 days default)

## Support

For issues or questions:
1. Check this documentation
2. Review console logs for errors
3. Verify environment variables are set
4. Test with fresh signup/login
