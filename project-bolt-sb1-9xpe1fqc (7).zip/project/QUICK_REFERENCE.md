# Quick Reference Card - Custom Authentication System

## API Endpoints

```
BASE_URL: https://your-project.supabase.co/functions/v1/auth
```

### Signup
```bash
POST /auth/signup
Content-Type: application/json

{
  "username": "johndoe",
  "email": "john@example.com",
  "password": "password123"
}

Response: { user: {...}, token: "jwt-token" }
```

### Login
```bash
POST /auth/login
Content-Type: application/json

{
  "email": "john@example.com",
  "password": "password123"
}

Response: { user: {...}, token: "jwt-token" }
```

### Forgot Password
```bash
POST /auth/forgot-password
Content-Type: application/json

{
  "email": "john@example.com"
}

Response: { message: "...", devToken: "..." }
```

### Reset Password
```bash
POST /auth/reset-password
Content-Type: application/json

{
  "token": "reset-token-here",
  "newPassword": "newpass123"
}

Response: { message: "Password reset successful" }
```

### Get Current User
```bash
GET /auth/me
Authorization: Bearer <jwt-token>

Response: { user: {...} }
```

## Frontend Usage

### Import Auth Functions
```typescript
import {
  signup,
  login,
  logout,
  forgotPassword,
  resetPassword,
  getCurrentUser,
  isAuthenticated,
  getUser,
  getToken
} from './lib/customAuth';
```

### Signup Example
```typescript
try {
  const { user, token } = await signup(
    'johndoe',
    'john@example.com',
    'password123'
  );
  console.log('Signed up:', user);
} catch (error) {
  console.error(error.message);
}
```

### Login Example
```typescript
try {
  const { user, token } = await login(
    'john@example.com',
    'password123'
  );
  console.log('Logged in:', user);
} catch (error) {
  console.error(error.message);
}
```

### Logout
```typescript
logout(); // Clears session and redirects
```

### Check if Authenticated
```typescript
if (isAuthenticated()) {
  const user = getUser();
  console.log('Current user:', user);
}
```

### Get Current User (with API call)
```typescript
const user = await getCurrentUser();
if (user) {
  console.log('User:', user);
} else {
  console.log('Not logged in');
}
```

## React Hook Usage

### Use Auth Context
```typescript
import { useAuth } from './lib/newAuthContext';

function MyComponent() {
  const { user, loading, isAuthenticated, logout } = useAuth();

  if (loading) return <div>Loading...</div>;

  if (!isAuthenticated) {
    return <div>Please log in</div>;
  }

  return (
    <div>
      <p>Welcome, {user.username}!</p>
      <button onClick={logout}>Logout</button>
    </div>
  );
}
```

## Protected Routes

### Wrap Routes
```typescript
import ProtectedRoute from './components/ProtectedRoute';

<Route
  path="/upload"
  element={
    <ProtectedRoute>
      <UploadPage />
    </ProtectedRoute>
  }
/>
```

### Manual Protection
```typescript
import { requireAuth } from './lib/customAuth';

function ProtectedPage() {
  useEffect(() => {
    requireAuth('/'); // Redirect to home if not authenticated
  }, []);

  return <div>Protected content</div>;
}
```

## Database Queries

### Get User by ID
```sql
SELECT * FROM users WHERE id = 'user-uuid';
```

### Get User by Email
```sql
SELECT * FROM users WHERE email = 'john@example.com';
```

### Get User by Username
```sql
SELECT * FROM users WHERE username = 'johndoe';
```

### Check Username Availability
```sql
SELECT EXISTS(SELECT 1 FROM users WHERE username = 'johndoe');
```

### Check Email Availability
```sql
SELECT EXISTS(SELECT 1 FROM users WHERE email = 'john@example.com');
```

### Update User Profile
```sql
UPDATE users
SET bio = 'New bio', avatar_url = 'https://...'
WHERE id = 'user-uuid';
```

## Environment Variables

```env
# Frontend (.env)
VITE_SUPABASE_URL=https://your-project.supabase.co
VITE_SUPABASE_ANON_KEY=your-anon-key

# Backend (Supabase Edge Function Secrets)
SUPABASE_SERVICE_ROLE_KEY=your-service-role-key
JWT_SECRET=your-super-secret-jwt-key-32-chars-min
```

## Common Errors

### "Invalid email or password"
- Wrong email or password
- User doesn't exist

### "Email already exists"
- Email is registered
- Try login instead

### "Username already taken"
- Choose different username

### "Unauthorized"
- Not logged in
- Token expired
- Invalid token

### "Password must be at least 6 characters"
- Password too short

## localStorage Keys

```typescript
// Auth token
localStorage.getItem('auth_token')

// User data
localStorage.getItem('auth_user')

// Clear all auth data
localStorage.removeItem('auth_token')
localStorage.removeItem('auth_user')
```

## JWT Token Structure

```json
{
  "userId": "uuid",
  "email": "john@example.com",
  "username": "johndoe",
  "exp": 1234567890
}
```

## Password Requirements

- Minimum: 6 characters
- No maximum
- Hashed with bcrypt (10 salt rounds)
- Never stored in plain text

## Username Requirements

- Minimum: 3 characters
- Must be unique
- Case-sensitive
- Can only change once every 20 days

## Email Requirements

- Must be valid email format
- Must be unique
- Case-insensitive for lookups

## Token Expiration

- Access token: 7 days
- Reset token: 1 hour

## Security Headers

```typescript
const headers = {
  'Content-Type': 'application/json',
  'Authorization': `Bearer ${token}`, // For authenticated requests
};
```

## Error Response Format

```json
{
  "error": "Error message here"
}
```

## Success Response Format

### Signup/Login
```json
{
  "user": {
    "id": "uuid",
    "username": "johndoe",
    "email": "john@example.com",
    "avatar_url": "",
    "bio": "",
    "created_at": "2024-..."
  },
  "token": "jwt-token-here"
}
```

### Forgot Password
```json
{
  "message": "If email exists, reset link has been sent",
  "devToken": "reset-token-for-dev-only"
}
```

### Reset Password
```json
{
  "message": "Password reset successful"
}
```

### Get Current User
```json
{
  "user": {
    "id": "uuid",
    "username": "johndoe",
    "email": "john@example.com",
    ...
  }
}
```

## HTTP Status Codes

- `200` - Success
- `201` - Created (signup)
- `400` - Bad Request (validation error)
- `401` - Unauthorized (invalid credentials)
- `403` - Forbidden (blocked account)
- `404` - Not Found
- `500` - Internal Server Error

## Useful Commands

### Build Project
```bash
npm run build
```

### Run Development Server
```bash
npm run dev
```

### Clear localStorage (Browser Console)
```javascript
localStorage.clear()
```

### Decode JWT Token (Browser Console)
```javascript
const token = localStorage.getItem('auth_token');
const parts = token.split('.');
const payload = JSON.parse(atob(parts[1]));
console.log(payload);
```

## Testing URLs

```
Homepage: http://localhost:5173/
Upload (Protected): http://localhost:5173/upload
Wallet (Protected): http://localhost:5173/wallet
Profile (Protected): http://localhost:5173/profile
```

## Key Files

```
Frontend:
- src/lib/customAuth.ts (auth functions)
- src/lib/newAuthContext.tsx (React context)
- src/components/NewAuthPage.tsx (auth UI)
- src/components/ProtectedRoute.tsx (route guard)

Backend:
- supabase/functions/auth/index.ts (API endpoints)
- supabase/migrations/20251018000001_create_standalone_auth.sql (database)

Documentation:
- AUTH_SYSTEM_DOCUMENTATION.md (full docs)
- SETUP_INSTRUCTIONS.md (setup guide)
- IMPLEMENTATION_COMPLETE.md (summary)
- QUICK_REFERENCE.md (this file)
```

## Need Help?

1. Check browser console for errors
2. Verify environment variables are set
3. Check localStorage has auth_token
4. Review Edge Function logs in Supabase dashboard
5. Test with fresh signup/login
6. Read AUTH_SYSTEM_DOCUMENTATION.md
