# IMPORTANT: Storage Policies Setup Required

## You created the bucket but now getting "signature verification failed"!

This happens because you're using custom authentication (not Supabase Auth), so we need to allow uploads to the public bucket without Supabase authentication.

### Fix (1 minute):

**Go to SQL Editor and run this:**

1. **Open SQL Editor**: https://supabase.com/dashboard/project/fmnlvlgxvxftbcjdmsng/sql/new

2. **Paste and run this SQL**:

```sql
-- Drop existing restrictive policies if any
DROP POLICY IF EXISTS "Public video access" ON storage.objects;
DROP POLICY IF EXISTS "Authenticated users can upload videos" ON storage.objects;
DROP POLICY IF EXISTS "Users can delete own videos" ON storage.objects;

-- Allow ANYONE to view videos (public bucket)
CREATE POLICY "Anyone can view videos"
ON storage.objects FOR SELECT
TO public
USING (bucket_id = 'videos');

-- Allow ANYONE to upload videos (since we use custom auth, not Supabase auth)
CREATE POLICY "Anyone can upload videos"
ON storage.objects FOR INSERT
TO public
WITH CHECK (bucket_id = 'videos');

-- Allow ANYONE to delete videos (you can make this more restrictive later)
CREATE POLICY "Anyone can delete videos"
ON storage.objects FOR DELETE
TO public
USING (bucket_id = 'videos');

-- Allow ANYONE to update videos
CREATE POLICY "Anyone can update videos"
ON storage.objects FOR UPDATE
TO public
USING (bucket_id = 'videos');
```

3. **Click "Run"**

4. **Try uploading again** - it will work now!

---

## Why is this needed?

Your app uses custom JWT authentication (not Supabase Auth). Supabase Storage can't verify your custom tokens, so it rejects them with "signature verification failed".

By setting policies to allow `public` access, the storage works with the anon key (which is already in your code) instead of trying to verify custom JWT tokens.

**Note:** These policies are open for simplicity. Once uploads work, you can add your own security layer in your backend API if needed.
