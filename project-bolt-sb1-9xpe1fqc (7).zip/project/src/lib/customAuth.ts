const TOKEN_KEY = 'auth_token';
const REFRESH_TOKEN_KEY = 'auth_refresh_token';
const USER_KEY = 'auth_user';

const API_URL = import.meta.env.VITE_SUPABASE_URL;

export interface User {
  id: string;
  username: string;
  email: string;
  avatar_url?: string;
  bio?: string;
  country?: string;
  full_name?: string;
  followers_count?: number;
  following_count?: number;
  total_likes?: number;
  is_verified?: boolean;
  email_verified?: boolean;
  wallet_balance?: number;
  total_earned?: number;
  total_withdrawn?: number;
  created_at?: string;
}

export interface AuthResponse {
  user: User;
  token: string;
  refresh_token?: string;
}

export interface SignupData {
  email: string;
  password: string;
  username: string;
  country: string;
  avatar_url?: string;
  bio?: string;
}

async function apiRequest<T>(endpoint: string, options: RequestInit = {}): Promise<T> {
  const token = getToken();
  const headers: Record<string, string> = {
    'Content-Type': 'application/json',
    'apikey': import.meta.env.VITE_SUPABASE_ANON_KEY,
    ...(options.headers as Record<string, string> || {}),
  };

  if (token) {
    headers['Authorization'] = `Bearer ${token}`;
  }

  const response = await fetch(`${API_URL}/functions/v1/auth${endpoint}`, {
    ...options,
    headers,
  });

  const data = await response.json();

  if (!response.ok || data.error) {
    throw new Error(data.message || 'Request failed');
  }

  return data;
}

export const signup = async (data: SignupData): Promise<AuthResponse> => {
  const response = await apiRequest<{
    success: boolean;
    user: User;
    access_token: string;
    refresh_token: string;
  }>('/signup', {
    method: 'POST',
    body: JSON.stringify(data),
  });

  setToken(response.access_token);
  setRefreshToken(response.refresh_token);
  setUser(response.user);

  return {
    user: response.user,
    token: response.access_token,
    refresh_token: response.refresh_token,
  };
};

export const login = async (email: string, password: string): Promise<AuthResponse> => {
  const response = await apiRequest<{
    success: boolean;
    user: User;
    access_token: string;
    refresh_token: string;
  }>('/login', {
    method: 'POST',
    body: JSON.stringify({ email, password }),
  });

  setToken(response.access_token);
  setRefreshToken(response.refresh_token);
  setUser(response.user);

  return {
    user: response.user,
    token: response.access_token,
    refresh_token: response.refresh_token,
  };
};

export const logout = async () => {
  try {
    const token = getToken();
    if (token) {
      await apiRequest('/logout', { method: 'POST' });
    }
  } catch (error) {
    console.error('Logout API error:', error);
  } finally {
    localStorage.removeItem(TOKEN_KEY);
    localStorage.removeItem(REFRESH_TOKEN_KEY);
    localStorage.removeItem(USER_KEY);
    window.location.href = '/';
  }
};

export const refreshToken = async (): Promise<boolean> => {
  const refresh = getRefreshToken();
  if (!refresh) return false;

  try {
    const response = await fetch(`${API_URL}/functions/v1/auth/refresh`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'apikey': import.meta.env.VITE_SUPABASE_ANON_KEY,
      },
      body: JSON.stringify({ refresh_token: refresh }),
    });

    const data = await response.json();

    if (data.success) {
      setToken(data.access_token);
      setRefreshToken(data.refresh_token);
      return true;
    }
  } catch (error) {
    console.error('Token refresh failed:', error);
  }

  return false;
};

export const forgotPassword = async (email: string): Promise<{ message: string; reset_token?: string }> => {
  const response = await apiRequest<{
    success: boolean;
    message: string;
    reset_token?: string;
  }>('/forgot-password', {
    method: 'POST',
    body: JSON.stringify({ email }),
  });

  return { message: response.message, reset_token: response.reset_token };
};

export const resetPassword = async (token: string, newPassword: string): Promise<{ message: string }> => {
  const response = await apiRequest<{
    success: boolean;
    message: string;
  }>('/reset-password', {
    method: 'POST',
    body: JSON.stringify({ token, new_password: newPassword }),
  });

  return { message: response.message };
};

export const changePassword = async (currentPassword: string, newPassword: string): Promise<{ message: string }> => {
  const response = await apiRequest<{
    success: boolean;
    message: string;
  }>('/change-password', {
    method: 'POST',
    body: JSON.stringify({ current_password: currentPassword, new_password: newPassword }),
  });

  return { message: response.message };
};

export const getProfile = async (): Promise<User> => {
  const response = await apiRequest<{
    success: boolean;
    user: User;
  }>('/profile', { method: 'GET' });

  setUser(response.user);
  return response.user;
};

export const updateProfile = async (data: Partial<User>): Promise<User> => {
  const response = await apiRequest<{
    success: boolean;
    user: User;
  }>('/profile', {
    method: 'PUT',
    body: JSON.stringify(data),
  });

  setUser(response.user);
  return response.user;
};

export const verifyEmail = async (token: string): Promise<{ message: string }> => {
  const response = await apiRequest<{
    success: boolean;
    message: string;
  }>('/verify-email', {
    method: 'POST',
    body: JSON.stringify({ token }),
  });

  return { message: response.message };
};

export const resendVerification = async (): Promise<{ message: string; verification_token?: string }> => {
  const response = await apiRequest<{
    success: boolean;
    message: string;
    verification_token?: string;
  }>('/resend-verification', { method: 'POST' });

  return { message: response.message, verification_token: response.verification_token };
};

export const getSessions = async (): Promise<{ sessions: Array<{
  id: string;
  device_info: Record<string, string>;
  ip_address: string;
  created_at: string;
  last_active_at: string;
}> }> => {
  return await apiRequest('/sessions', { method: 'GET' });
};

export const revokeSession = async (sessionId: string): Promise<{ message: string }> => {
  const response = await apiRequest<{
    success: boolean;
    message: string;
  }>('/revoke-session', {
    method: 'POST',
    body: JSON.stringify({ session_id: sessionId }),
  });

  return { message: response.message };
};

export const getCountries = async (): Promise<string[]> => {
  const response = await apiRequest<{
    success: boolean;
    countries: string[];
  }>('/countries', { method: 'GET' });

  return response.countries;
};

export const getCurrentUser = (): User | null => {
  return getUser();
};

export const getToken = (): string | null => {
  return localStorage.getItem(TOKEN_KEY);
};

export const setToken = (token: string) => {
  localStorage.setItem(TOKEN_KEY, token);
};

export const getRefreshToken = (): string | null => {
  return localStorage.getItem(REFRESH_TOKEN_KEY);
};

export const setRefreshToken = (token: string) => {
  localStorage.setItem(REFRESH_TOKEN_KEY, token);
};

export const getUser = (): User | null => {
  const userStr = localStorage.getItem(USER_KEY);
  if (!userStr) return null;
  try {
    return JSON.parse(userStr);
  } catch {
    return null;
  }
};

export const setUser = (user: User) => {
  localStorage.setItem(USER_KEY, JSON.stringify(user));
};

export const isAuthenticated = (): boolean => {
  return !!getToken();
};

export const requireAuth = (redirectTo = '/'): boolean => {
  if (!isAuthenticated()) {
    window.location.href = redirectTo;
    return false;
  }
  return true;
};
