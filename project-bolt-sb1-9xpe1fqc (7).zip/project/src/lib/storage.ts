const CLOUDINARY_CLOUD_NAME = 'dshgdmj0x';
const CLOUDINARY_UPLOAD_PRESET = 'nagris_video_upload';

export const storageApi = {
  async uploadVideo(file: File): Promise<string> {
    const formData = new FormData();
    formData.append('file', file);
    formData.append('upload_preset', CLOUDINARY_UPLOAD_PRESET);
    formData.append('folder', 'nagris-videos');

    try {
      const response = await fetch(
        `https://api.cloudinary.com/v1_1/${CLOUDINARY_CLOUD_NAME}/video/upload`,
        {
          method: 'POST',
          body: formData,
        }
      );

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.error?.message || 'Upload failed');
      }

      const data = await response.json();
      return data.secure_url;
    } catch (error: any) {
      console.error('Upload error:', error);
      throw new Error(`Upload failed: ${error.message}`);
    }
  },

  async deleteVideo(url: string): Promise<void> {
    console.log('Delete not implemented for Cloudinary demo account');
  },

  async uploadImage(file: File): Promise<string> {
    const formData = new FormData();
    formData.append('file', file);
    formData.append('upload_preset', CLOUDINARY_UPLOAD_PRESET);
    formData.append('folder', 'nagris-avatars');

    try {
      const response = await fetch(
        `https://api.cloudinary.com/v1_1/${CLOUDINARY_CLOUD_NAME}/image/upload`,
        {
          method: 'POST',
          body: formData,
        }
      );

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.error?.message || 'Upload failed');
      }

      const data = await response.json();
      return data.secure_url;
    } catch (error: any) {
      console.error('Upload error:', error);
      throw new Error(`Upload failed: ${error.message}`);
    }
  },
};
