import type { User } from '../lib/types';

export interface Gift {
  id: string;
  name: string;
  coin_cost: number;
  usd_value: number;
  description: string;
  icon_url: string | null;
  display_order: number;
}

export interface UserCoins {
  user_id: string;
  balance: number;
  lifetime_purchased: number;
  lifetime_spent: number;
}

export interface WalletEarnings {
  user_id: string;
  view_earnings: number;
  gift_earnings: number;
  total_earnings: number;
  total_withdrawn: number;
  pending_withdrawal: number;
}

const GIFTS_DB_KEY = 'gifts_data';
const USER_COINS_DB_KEY = 'user_coins';
const WALLET_DB_KEY = 'wallet_earnings';

function getGiftsDB(): Record<string, Gift> {
  try {
    const data = localStorage.getItem(GIFTS_DB_KEY);
    if (!data) {
      const defaultGifts = {
        'gift1': { id: 'gift1', name: 'Rose', coin_cost: 10, usd_value: 0.10, description: 'Beautiful rose', icon_url: '🌹', display_order: 1 },
        'gift2': { id: 'gift2', name: 'Heart', coin_cost: 50, usd_value: 0.50, description: 'Red heart', icon_url: '❤️', display_order: 2 },
        'gift3': { id: 'gift3', name: 'Diamond', coin_cost: 100, usd_value: 1.00, description: 'Sparkling diamond', icon_url: '💎', display_order: 3 },
      };
      localStorage.setItem(GIFTS_DB_KEY, JSON.stringify(defaultGifts));
      return defaultGifts;
    }
    return JSON.parse(data);
  } catch {
    return {};
  }
}

function getUserCoinsDB(): Record<string, UserCoins> {
  try {
    const data = localStorage.getItem(USER_COINS_DB_KEY);
    return data ? JSON.parse(data) : {};
  } catch {
    return {};
  }
}

function saveUserCoinsDB(data: Record<string, UserCoins>) {
  localStorage.setItem(USER_COINS_DB_KEY, JSON.stringify(data));
}

function getWalletDB(): Record<string, WalletEarnings> {
  try {
    const data = localStorage.getItem(WALLET_DB_KEY);
    return data ? JSON.parse(data) : {};
  } catch {
    return {};
  }
}

function saveWalletDB(data: Record<string, WalletEarnings>) {
  localStorage.setItem(WALLET_DB_KEY, JSON.stringify(data));
}

export async function getAvailableGifts(): Promise<Gift[]> {
  const gifts = getGiftsDB();
  return Object.values(gifts).sort((a, b) => a.display_order - b.display_order);
}

export async function getUserCoins(userId: string): Promise<UserCoins | null> {
  const coinsDB = getUserCoinsDB();

  if (!coinsDB[userId]) {
    coinsDB[userId] = {
      user_id: userId,
      balance: 100,
      lifetime_purchased: 0,
      lifetime_spent: 0
    };
    saveUserCoinsDB(coinsDB);
  }

  return coinsDB[userId];
}

export async function getWalletEarnings(userId: string): Promise<WalletEarnings | null> {
  const walletDB = getWalletDB();

  if (!walletDB[userId]) {
    walletDB[userId] = {
      user_id: userId,
      view_earnings: 0,
      gift_earnings: 0,
      total_earnings: 0,
      total_withdrawn: 0,
      pending_withdrawal: 0
    };
    saveWalletDB(walletDB);
  }

  return walletDB[userId];
}

export async function sendGift(
  senderId: string,
  recipientId: string,
  giftId: string,
  videoId?: string,
  liveStreamId?: string
): Promise<{ success: boolean; message?: string }> {
  try {
    const coins = await getUserCoins(senderId);
    if (!coins) {
      return { success: false, message: 'Unable to fetch coin balance' };
    }

    const gifts = await getAvailableGifts();
    const gift = gifts.find(g => g.id === giftId);
    if (!gift) {
      return { success: false, message: 'Gift not found' };
    }

    if (coins.balance < gift.coin_cost) {
      return { success: false, message: 'Insufficient coins' };
    }

    const coinsDB = getUserCoinsDB();
    coinsDB[senderId].balance -= gift.coin_cost;
    coinsDB[senderId].lifetime_spent += gift.coin_cost;
    saveUserCoinsDB(coinsDB);

    return { success: true };
  } catch (error) {
    console.error('Error sending gift:', error);
    return { success: false, message: 'Failed to send gift' };
  }
}

export async function purchaseCoins(
  userId: string,
  amount: number
): Promise<{ success: boolean; message?: string }> {
  try {
    const coins = await getUserCoins(userId);
    if (!coins) {
      return { success: false, message: 'Unable to fetch coin balance' };
    }

    const coinsDB = getUserCoinsDB();
    coinsDB[userId].balance += amount;
    coinsDB[userId].lifetime_purchased += amount;
    saveUserCoinsDB(coinsDB);

    return { success: true };
  } catch (error) {
    console.error('Error purchasing coins:', error);
    return { success: false, message: 'Failed to purchase coins' };
  }
}

export async function requestWithdrawal(
  userId: string,
  amount: number,
  paymentMethod: string,
  paymentDetails: Record<string, unknown>
): Promise<{ success: boolean; message?: string }> {
  try {
    const earnings = await getWalletEarnings(userId);
    if (!earnings) {
      return { success: false, message: 'Unable to fetch earnings' };
    }

    const availableBalance = earnings.total_earnings - earnings.total_withdrawn - earnings.pending_withdrawal;
    if (availableBalance < amount) {
      return { success: false, message: 'Insufficient balance' };
    }

    const walletDB = getWalletDB();
    walletDB[userId].pending_withdrawal += amount;
    saveWalletDB(walletDB);

    return { success: true };
  } catch (error) {
    console.error('Error requesting withdrawal:', error);
    return { success: false, message: 'Failed to request withdrawal' };
  }
}

export const COIN_PACKAGES = [
  { coins: 100, usd: 0.99, bonus: 0 },
  { coins: 500, usd: 4.99, bonus: 50 },
  { coins: 1000, usd: 9.99, bonus: 150 },
  { coins: 5000, usd: 49.99, bonus: 1000 },
  { coins: 10000, usd: 99.99, bonus: 2500 }
];