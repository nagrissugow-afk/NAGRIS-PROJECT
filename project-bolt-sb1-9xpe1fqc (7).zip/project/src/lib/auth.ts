// src/lib/auth.ts
import { apiRequest } from "./apiRequest";

export interface AuthUser {
  id: string;
  email: string;
  username: string;
  avatar_url?: string;
  country?: string;
}

export const auth = {
  // Sign up a new user
  async signUp(email: string, password: string, username: string, country: string) {
    const data = await apiRequest("POST", "/api/auth/signup", {
      email,
      password,
      username,
      country,
    });

    if (!data?.token) {
      throw new Error("Signup failed. No token returned.");
    }

    localStorage.setItem("token", data.token);
    return data.user as AuthUser;
  },

  // Log in existing user
  async signIn(email: string, password: string) {
    const data = await apiRequest("POST", "/api/auth/login", { email, password });

    if (!data?.token) {
      throw new Error("Login failed. No token returned.");
    }

    localStorage.setItem("token", data.token);
    return data.user as AuthUser;
  },

  // Log out user
  async signOut() {
    localStorage.removeItem("token");
  },

  // Get currently authenticated user
  async getCurrentUser(): Promise<AuthUser | null> {
    try {
      const data = await apiRequest("GET", "/api/auth/me", null, {
        Authorization: `Bearer ${localStorage.getItem("token")}`,
      });
      return data.user as AuthUser;
    } catch (err) {
      return null;
    }
  },

  // Listen for manual auth state changes (not like Supabase real-time)
  onAuthStateChange(callback: (user: AuthUser | null) => void) {
    window.addEventListener("storage", async (event) => {
      if (event.key === "token") {
        const user = await auth.getCurrentUser();
        callback(user);
      }
    });
  },

  // Get stored JWT token
  getToken() {
    return localStorage.getItem("token");
  },
};
