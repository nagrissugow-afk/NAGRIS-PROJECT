import type { User } from '../lib/types';
import { getUser, getToken } from './customAuth';

export interface LiveStream {
  id: string;
  user_id: string;
  title: string;
  description: string;
  thumbnail_url: string;
  is_active: boolean;
  viewer_count: number;
  total_likes: number;
  total_gifts_received: number;
  total_gift_value: number;
  agora_channel_id?: string;
  agora_token?: string;
  started_at: string;
  ended_at?: string;
  user?: {
    id: string;
    username: string;
    avatar_url: string;
    is_verified: boolean;
  };
}

export interface LiveGame {
  id: string;
  live_room_id: string;
  game_type: 'poll' | 'trivia' | 'spin_wheel';
  game_data: any;
  results?: any;
  is_active: boolean;
  created_at: string;
}

export interface ChatMessage {
  id: string;
  live_room_id: string;
  user_id: string;
  message: string;
  created_at: string;
  user?: {
    username: string;
    avatar_url: string;
    is_verified: boolean;
  };
}

export interface GiftTransaction {
  id: string;
  live_stream_id: string;
  gift_id: string;
  sender_id: string;
  recipient_id: string;
  coin_amount: number;
  creator_share: number;
  platform_share: number;
  created_at: string;
}

// Mock live streams storage
const liveStreamsStore: Map<string, LiveStream> = new Map();
const chatMessagesStore: Map<string, ChatMessage[]> = new Map();

export const liveApi = {
  async canStartLive(): Promise<{ canStart: boolean; followerCount: number }> {
    const user = getUser();
    if (!user) throw new Error('Not authenticated');

    try {
      const token = getToken();
      const apiUrl = `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/check-live-eligibility`;

      const response = await fetch(apiUrl, {
        method: 'GET',
        headers: {
          'Authorization': `Bearer ${token}`,
          'Content-Type': 'application/json',
        },
      });

      const data = await response.json();

      if (!response.ok) {
        return {
          canStart: false,
          followerCount: user.followers_count || 0,
        };
      }

      return {
        canStart: data.eligible,
        followerCount: user.followers_count || 0,
      };
    } catch (err) {
      console.error('Error checking live eligibility:', err);
      return {
        canStart: false,
        followerCount: user.followers_count || 0,
      };
    }
  },

  async startLive(title: string, description: string, thumbnail_url?: string): Promise<LiveStream> {
    const user = getUser();
    if (!user) throw new Error('Not authenticated');

    try {
      const token = getToken();
      const apiUrl = `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/check-live-eligibility`;

      const response = await fetch(apiUrl, {
        method: 'GET',
        headers: {
          'Authorization': `Bearer ${token}`,
          'Content-Type': 'application/json',
        },
      });

      const data = await response.json();

      if (!response.ok || !data.eligible) {
        throw new Error(data.error || 'Need 500 followers to start live streaming.');
      }
    } catch (err: any) {
      throw new Error(err.message || 'Failed to verify eligibility');
    }

    const agoraChannelId = `live_${user.id}_${Date.now()}`;
    const liveStreamId = `stream_${Date.now()}_${Math.random().toString(36).substring(7)}`;

    const liveStream: LiveStream = {
      id: liveStreamId,
      user_id: user.id,
      title,
      description,
      thumbnail_url: thumbnail_url || '',
      is_active: true,
      viewer_count: 0,
      total_likes: 0,
      total_gifts_received: 0,
      total_gift_value: 0,
      agora_channel_id: agoraChannelId,
      started_at: new Date().toISOString(),
      user: {
        id: user.id,
        username: user.username,
        avatar_url: user.avatar_url || '',
        is_verified: user.is_verified || false,
      },
    };

    liveStreamsStore.set(liveStreamId, liveStream);
    chatMessagesStore.set(liveStreamId, []);

    return liveStream;
  },

  async endLive(liveStreamId: string): Promise<void> {
    const user = getUser();
    if (!user) throw new Error('Not authenticated');

    const stream = liveStreamsStore.get(liveStreamId);
    if (stream && stream.user_id === user.id) {
      stream.is_active = false;
      stream.ended_at = new Date().toISOString();
      liveStreamsStore.set(liveStreamId, stream);
    }
  },

  async getActiveLiveStreams(): Promise<LiveStream[]> {
    return Array.from(liveStreamsStore.values()).filter(s => s.is_active);
  },

  async getLiveStream(id: string): Promise<LiveStream | null> {
    return liveStreamsStore.get(id) || null;
  },

  async joinLive(liveStreamId: string): Promise<void> {
    const user = getUser();
    if (!user) throw new Error('Not authenticated');

    const stream = liveStreamsStore.get(liveStreamId);
    if (stream) {
      stream.viewer_count = (stream.viewer_count || 0) + 1;
      liveStreamsStore.set(liveStreamId, stream);
    }
  },

  async leaveLive(liveStreamId: string): Promise<void> {
    const stream = liveStreamsStore.get(liveStreamId);
    if (stream && stream.viewer_count > 0) {
      stream.viewer_count -= 1;
      liveStreamsStore.set(liveStreamId, stream);
    }
  },

  async sendChatMessage(liveRoomId: string, message: string): Promise<void> {
    const user = getUser();
    if (!user) throw new Error('Not authenticated');

    const messages = chatMessagesStore.get(liveRoomId) || [];
    const chatMessage: ChatMessage = {
      id: `msg_${Date.now()}`,
      live_room_id: liveRoomId,
      user_id: user.id,
      message,
      created_at: new Date().toISOString(),
      user: {
        username: user.username,
        avatar_url: user.avatar_url || '',
        is_verified: user.is_verified || false,
      },
    };
    messages.push(chatMessage);
    chatMessagesStore.set(liveRoomId, messages);
  },

  async getChatMessages(liveRoomId: string, limit = 50): Promise<ChatMessage[]> {
    const messages = chatMessagesStore.get(liveRoomId) || [];
    return messages.slice(-limit);
  },

  async sendGift(liveStreamId: string, giftId: string): Promise<void> {
    const user = getUser();
    if (!user) throw new Error('Not authenticated');

    const stream = liveStreamsStore.get(liveStreamId);
    if (stream) {
      stream.total_gifts_received = (stream.total_gifts_received || 0) + 1;
      stream.total_gift_value = (stream.total_gift_value || 0) + 50;
      liveStreamsStore.set(liveStreamId, stream);
    }
  },

  async startGame(liveRoomId: string, gameType: 'poll' | 'trivia' | 'spin_wheel', gameData: any): Promise<LiveGame> {
    return {
      id: `game_${Date.now()}`,
      live_room_id: liveRoomId,
      game_type: gameType,
      game_data: gameData,
      is_active: true,
      created_at: new Date().toISOString(),
    };
  },

  async endGame(gameId: string): Promise<void> {
    // Mock implementation
  },

  async submitGameAnswer(gameId: string, answer: any): Promise<void> {
    // Mock implementation
  },

  async getGameResults(gameId: string): Promise<any> {
    return {
      responses: [],
      summary: {},
      totalResponses: 0,
    };
  },

  subscribeToChatMessages(liveRoomId: string, callback: (message: ChatMessage) => void) {
    return {
      unsubscribe: () => {},
    };
  },

  subscribeToGifts(liveStreamId: string, callback: (gift: any) => void) {
    return {
      unsubscribe: () => {},
    };
  },

  subscribeToGames(liveRoomId: string, callback: (game: LiveGame) => void) {
    return {
      unsubscribe: () => {},
    };
  },
};
