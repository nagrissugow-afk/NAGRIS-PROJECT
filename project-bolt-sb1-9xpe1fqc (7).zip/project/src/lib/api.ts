import type {
  Video,
  User,
  Comment,
  Notification,
  Wallet,
  WithdrawalRequest,
  LiveRoom,
  Music,
} from "./types";
import { getUser, getToken } from './customAuth';
import { supabase } from './supabase';

const USERS_DB_KEY = 'auth_users_db';
const VIDEOS_DB_KEY = 'videos_db';
const COMMENTS_DB_KEY = 'comments_db';
const LIKES_DB_KEY = 'likes_db';
const FOLLOWS_DB_KEY = 'follows_db';
const SAVES_DB_KEY = 'saves_db';
const DEMO_VIDEOS_SEEDED = 'demo_videos_seeded';

function generateUUID(): string {
  return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function(c) {
    const r = Math.random() * 16 | 0;
    const v = c == 'x' ? r : (r & 0x3 | 0x8);
    return v.toString(16);
  });
}

function getUsersDB(): User[] {
  try {
    const data = localStorage.getItem(USERS_DB_KEY);
    return data ? JSON.parse(data) : [];
  } catch {
    return [];
  }
}

function getVideosDB(): Video[] {
  try {
    const data = localStorage.getItem(VIDEOS_DB_KEY);
    return data ? JSON.parse(data) : [];
  } catch {
    return [];
  }
}

function saveVideosDB(videos: Video[]) {
  localStorage.setItem(VIDEOS_DB_KEY, JSON.stringify(videos));
}

function getCommentsDB(): Comment[] {
  try {
    const data = localStorage.getItem(COMMENTS_DB_KEY);
    return data ? JSON.parse(data) : [];
  } catch {
    return [];
  }
}

function saveCommentsDB(comments: Comment[]) {
  localStorage.setItem(COMMENTS_DB_KEY, JSON.stringify(comments));
}

function getLikesDB(): Record<string, string[]> {
  try {
    const data = localStorage.getItem(LIKES_DB_KEY);
    return data ? JSON.parse(data) : {};
  } catch {
    return {};
  }
}

function saveLikesDB(likes: Record<string, string[]>) {
  localStorage.setItem(LIKES_DB_KEY, JSON.stringify(likes));
}

function getFollowsDB(): Record<string, string[]> {
  try {
    const data = localStorage.getItem(FOLLOWS_DB_KEY);
    return data ? JSON.parse(data) : {};
  } catch {
    return {};
  }
}

function saveFollowsDB(follows: Record<string, string[]>) {
  localStorage.setItem(FOLLOWS_DB_KEY, JSON.stringify(follows));
}

function getSavesDB(): Record<string, string[]> {
  try {
    const data = localStorage.getItem(SAVES_DB_KEY);
    return data ? JSON.parse(data) : {};
  } catch {
    return {};
  }
}

function saveSavesDB(saves: Record<string, string[]>) {
  localStorage.setItem(SAVES_DB_KEY, JSON.stringify(saves));
}

function migrateOldVideos() {
  const videos = getVideosDB();
  const hasOldIds = videos.some(v => !v.id.match(/^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i));

  if (hasOldIds) {
    localStorage.removeItem(VIDEOS_DB_KEY);
    localStorage.removeItem(DEMO_VIDEOS_SEEDED);
    localStorage.removeItem(LIKES_DB_KEY);
    localStorage.removeItem(SAVES_DB_KEY);
  }
}

function seedDemoVideos() {
  migrateOldVideos();

  if (localStorage.getItem(DEMO_VIDEOS_SEEDED)) return;

  const demoUserId = '00000000-0000-4000-8000-000000000001';
  const demoUser: User = {
    id: demoUserId,
    username: 'demo',
    email: 'demo@example.com',
    avatar_url: 'https://api.dicebear.com/7.x/avataaars/svg?seed=demo',
    full_name: 'Demo User',
    bio: 'Sample demo account',
    followers_count: 1000,
    following_count: 500,
    is_verified: true,
    created_at: new Date().toISOString(),
  };

  const demoVideos: Video[] = [
    {
      id: '00000000-0000-4000-8000-000000000101',
      user_id: demoUserId,
      user: demoUser,
      title: 'Welcome to the platform! Upload your first video to get started.',
      video_url: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4',
      thumbnail_url: '',
      likes_count: 150,
      comments_count: 25,
      shares_count: 10,
      views_count: 1200,
      duration: 15,
      is_private: false,
      created_at: new Date(Date.now() - 86400000).toISOString(),
    },
    {
      id: '00000000-0000-4000-8000-000000000102',
      user_id: demoUserId,
      user: demoUser,
      title: 'Check out this amazing video! Like and share if you enjoy it.',
      video_url: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ElephantsDream.mp4',
      thumbnail_url: '',
      likes_count: 89,
      comments_count: 12,
      shares_count: 5,
      views_count: 890,
      duration: 12,
      is_private: false,
      created_at: new Date(Date.now() - 172800000).toISOString(),
    },
  ];

  const existingVideos = getVideosDB();
  if (existingVideos.length === 0) {
    saveVideosDB(demoVideos);
  }

  localStorage.setItem(DEMO_VIDEOS_SEEDED, 'true');
}

export const api = {
  // ===== Videos =====
  async getVideos(cursor?: string, limit = 10): Promise<{ videos: Video[]; nextCursor?: string }> {
    seedDemoVideos();
    const videos = getVideosDB();
    return {
      videos: videos.slice(0, limit),
      nextCursor: undefined,
    };
  },

  async checkDailyUploadLimit(userId: string): Promise<{ canUpload: boolean; uploadedToday: number; message: string }> {
    const videos = getVideosDB();
    const now = Date.now();
    const oneDayAgo = now - (24 * 60 * 60 * 1000);

    const todaysVideos = videos.filter(v => {
      if (v.user_id !== userId) return false;
      const videoTime = new Date(v.created_at).getTime();
      return videoTime >= oneDayAgo;
    });

    const uploadedToday = todaysVideos.length;

    if (uploadedToday >= 2) {
      return {
        canUpload: false,
        uploadedToday,
        message: 'You have reached your daily upload limit of 2 videos. Please try again tomorrow.'
      };
    }

    return {
      canUpload: true,
      uploadedToday,
      message: `You can upload ${2 - uploadedToday} more video${2 - uploadedToday === 1 ? '' : 's'} today.`
    };
  },

  async uploadVideo(video: { title: string; url: string; is_private?: boolean }) {
    const user = getUser();
    if (!user) throw new Error('Not authenticated');

    const limitCheck = await this.checkDailyUploadLimit(user.id);
    if (!limitCheck.canUpload) {
      throw new Error(limitCheck.message);
    }

    const videos = getVideosDB();
    const newVideo: Video = {
      id: generateUUID(),
      user_id: user.id,
      user,
      title: video.title || 'Untitled',
      video_url: video.url,
      thumbnail_url: '',
      likes_count: 0,
      comments_count: 0,
      shares_count: 0,
      views_count: 0,
      is_private: video.is_private || false,
      created_at: new Date().toISOString(),
    };

    videos.unshift(newVideo);
    saveVideosDB(videos);
    return newVideo;
  },

  async getFollowingVideos(cursor?: string, limit = 10): Promise<{ videos: Video[]; nextCursor?: string }> {
    const user = getUser();
    if (!user) return { videos: [] };

    const follows = getFollowsDB();
    const following = follows[user.id] || [];
    const videos = getVideosDB().filter(v => following.includes(v.user_id));

    return {
      videos: videos.slice(0, limit),
      nextCursor: undefined,
    };
  },

  async getVideoById(id: string): Promise<Video | null> {
    const videos = getVideosDB();
    return videos.find(v => v.id === id) || null;
  },

  // ===== Users =====
  async getUserProfile(userId: string): Promise<User | null> {
    try {
      const { data: user, error } = await supabase
        .from('users')
        .select('*')
        .eq('id', userId)
        .maybeSingle();

      if (error || !user) {
        console.error('Error fetching user profile:', error);
        return null;
      }

      const { data: wallet } = await supabase
        .from('wallet')
        .select('balance')
        .eq('user_id', userId)
        .maybeSingle();

      return {
        id: user.id,
        username: user.username,
        email: user.email,
        avatar_url: user.avatar_url,
        bio: user.bio,
        country: user.country,
        full_name: user.full_name,
        followers_count: user.followers_count || 0,
        following_count: user.following_count || 0,
        total_likes: 0,
        is_verified: user.is_verified || false,
        email_verified: user.email_verified || false,
        wallet_balance: wallet?.balance || 0,
        created_at: user.created_at,
      };
    } catch (err) {
      console.error('Error in getUserProfile:', err);
      return null;
    }
  },

  async getUserVideos(userId: string, tab: "videos" | "liked" | "private" | "saved" = "videos"): Promise<Video[]> {
    const videos = getVideosDB();
    const user = getUser();

    if (tab === 'videos') {
      return videos.filter(v => v.user_id === userId && !v.is_private);
    } else if (tab === 'private' && user?.id === userId) {
      return videos.filter(v => v.user_id === userId && v.is_private);
    } else if (tab === 'liked' && user?.id === userId) {
      const likes = getLikesDB();
      const likedIds = likes[userId] || [];
      return videos.filter(v => likedIds.includes(v.id));
    } else if (tab === 'saved' && user?.id === userId) {
      const saves = getSavesDB();
      const savedIds = saves[userId] || [];
      return videos.filter(v => savedIds.includes(v.id));
    }

    return [];
  },

 // ===== Likes & Saves =====
async likeVideo(videoId: string): Promise<void> {
  const user = getUser();
  if (!user) throw new Error('Not authenticated');

  const { supabase } = await import('./supabase');

  // Check if already liked
  const { data: existing } = await supabase
    .from('likes')
    .select('id')
    .eq('video_id', videoId)
    .eq('user_id', user.id)
    .maybeSingle();

  if (existing) {
    // Already liked, do nothing
    return;
  }

  const { error } = await supabase
    .from('likes')
    .insert({ user_id: user.id, video_id: videoId });

  if (error && error.code !== '23505') {
    throw error;
  }
},

async unlikeVideo(videoId: string): Promise<void> {
  const user = getUser();
  if (!user) throw new Error('Not authenticated');

  const { supabase } = await import('./supabase');

  await supabase
    .from('likes')
    .delete()
    .eq('user_id', user.id)
    .eq('video_id', videoId);
},

async checkVideoLiked(videoId: string): Promise<boolean> {
  const user = getUser();
  if (!user) return false;

  const { supabase } = await import('./supabase');

  const { data } = await supabase
    .from('likes')
    .select('id')
    .eq('user_id', user.id)
    .eq('video_id', videoId)
    .maybeSingle();

  return !!data;
},

  async saveVideo(videoId: string): Promise<void> {
    const user = getUser();
    if (!user) throw new Error('Not authenticated');

    const { supabase } = await import('./supabase');

    const { error } = await supabase
      .from('saves')
      .insert({
        user_id: user.id,
        video_id: videoId
      });

    if (error && error.code !== '23505') {
      throw error;
    }
  },

  async unsaveVideo(videoId: string): Promise<void> {
    const user = getUser();
    if (!user) throw new Error('Not authenticated');

    const { supabase } = await import('./supabase');

    await supabase
      .from('saves')
      .delete()
      .eq('user_id', user.id)
      .eq('video_id', videoId);
  },

  async checkVideoSaved(videoId: string): Promise<boolean> {
    const user = getUser();
    if (!user) return false;

    const { supabase } = await import('./supabase');

    const { data } = await supabase
      .from('saves')
      .select('id')
      .eq('user_id', user.id)
      .eq('video_id', videoId)
      .maybeSingle();

    return !!data;
  },

  async getSavedVideos(): Promise<Video[]> {
    const user = getUser();
    if (!user) return [];

    const { supabase } = await import('./supabase');

    const { data, error } = await supabase
      .from('saves')
      .select(`
        video_id,
        videos (
          *,
          user:users (*)
        )
      `)
      .eq('user_id', user.id)
      .order('created_at', { ascending: false });

    if (error) {
      console.error('Failed to fetch saved videos:', error);
      return [];
    }

    return (data || [])
      .filter(save => save.videos)
      .map(save => ({
        ...save.videos,
        user: save.videos.user
      }));
  },

  // ===== Comments =====
  async getComments(videoId: string): Promise<Comment[]> {
    const { supabase } = await import('./supabase');

    const { data, error } = await supabase
      .from('comments')
      .select(`
        *,
        user:users (*)
      `)
      .eq('video_id', videoId)
      .order('created_at', { ascending: true });

    if (error) {
      console.error('Failed to fetch comments:', error);
      return [];
    }

    return (data || []).map(comment => ({
      ...comment,
      user: comment.user
    }));
  },

  async addComment(videoId: string, content: string, parentId?: string): Promise<void> {
    const user = getUser();
    if (!user) throw new Error('Not authenticated');

    const { supabase } = await import('./supabase');

    const { error } = await supabase
      .from('comments')
      .insert({
        video_id: videoId,
        user_id: user.id,
        content,
        parent_id: parentId || null
      });

    if (error) {
      throw error;
    }
  },

  async deleteComment(commentId: string): Promise<void> {
    const user = getUser();
    if (!user) throw new Error('Not authenticated');

    const { supabase } = await import('./supabase');

    await supabase
      .from('comments')
      .delete()
      .eq('id', commentId)
      .eq('user_id', user.id);
  },

  async likeComment(commentId: string): Promise<void> {
    const user = getUser();
    if (!user) throw new Error('Not authenticated');

    const { supabase } = await import('./supabase');

    const { error } = await supabase
      .from('likes')
      .insert({
        user_id: user.id,
        comment_id: commentId
      });

    if (error && error.code !== '23505') {
      throw error;
    }
  },

  async unlikeComment(commentId: string): Promise<void> {
    const user = getUser();
    if (!user) throw new Error('Not authenticated');

    const { supabase } = await import('./supabase');

    await supabase
      .from('likes')
      .delete()
      .eq('user_id', user.id)
      .eq('comment_id', commentId);
  },

  async checkCommentLiked(commentId: string): Promise<boolean> {
    const user = getUser();
    if (!user) return false;

    const { supabase } = await import('./supabase');

    const { data } = await supabase
      .from('likes')
      .select('id')
      .eq('user_id', user.id)
      .eq('comment_id', commentId)
      .maybeSingle();

    return !!data;
  },

  async getCommentLikedStates(commentIds: string[]): Promise<Record<string, boolean>> {
    const user = getUser();
    if (!user) return {};

    const { supabase } = await import('./supabase');

    const { data } = await supabase
      .from('likes')
      .select('comment_id')
      .eq('user_id', user.id)
      .in('comment_id', commentIds);

    const likedMap: Record<string, boolean> = {};
    commentIds.forEach(id => likedMap[id] = false);
    (data || []).forEach(like => {
      if (like.comment_id) {
        likedMap[like.comment_id] = true;
      }
    });

    return likedMap;
  },

  async pinComment(videoId: string, commentId: string): Promise<void> {
    const user = getUser();
    if (!user) throw new Error('Not authenticated');

    const { supabase } = await import('./supabase');

    await supabase
      .from('comments')
      .update({ is_pinned: true })
      .eq('id', commentId)
      .eq('video_id', videoId);
  },

  async unpinComment(videoId: string, commentId: string): Promise<void> {
    const user = getUser();
    if (!user) throw new Error('Not authenticated');

    const { supabase } = await import('./supabase');

    await supabase
      .from('comments')
      .update({ is_pinned: false })
      .eq('id', commentId)
      .eq('video_id', videoId);
  },

  // ===== Follows =====
  async followUser(userId: string): Promise<void> {
    const user = getUser();
    if (!user) throw new Error('Not authenticated');

    const { supabase } = await import('./supabase');

    const { error } = await supabase
      .from('follows')
      .insert({
        follower_id: user.id,
        following_id: userId
      });

    if (error && error.code !== '23505') {
      throw error;
    }
  },

  async unfollowUser(userId: string): Promise<void> {
    const user = getUser();
    if (!user) throw new Error('Not authenticated');

    const { supabase } = await import('./supabase');

    await supabase
      .from('follows')
      .delete()
      .eq('follower_id', user.id)
      .eq('following_id', userId);
  },

  async isFollowing(userId: string): Promise<boolean> {
    const user = getUser();
    if (!user) return false;

    const { supabase } = await import('./supabase');

    const { data } = await supabase
      .from('follows')
      .select('id')
      .eq('follower_id', user.id)
      .eq('following_id', userId)
      .maybeSingle();

    return !!data;
  },

  async getFollowers(userId: string): Promise<User[]> {
    const { supabase } = await import('./supabase');

    const { data, error } = await supabase
      .from('follows')
      .select(`
        follower:follower_id (*)
      `)
      .eq('following_id', userId);

    if (error) {
      console.error('Failed to fetch followers:', error);
      return [];
    }

    return (data || [])
      .filter(item => item.follower)
      .map(item => item.follower);
  },

  async getFollowing(userId: string): Promise<User[]> {
    const { supabase } = await import('./supabase');

    const { data, error } = await supabase
      .from('follows')
      .select(`
        following:following_id (*)
      `)
      .eq('follower_id', userId);

    if (error) {
      console.error('Failed to fetch following:', error);
      return [];
    }

    return (data || [])
      .filter(item => item.following)
      .map(item => item.following);
  },

  async getFollowingIds(): Promise<string[]> {
    const user = getUser();
    if (!user) return [];

    const { supabase } = await import('./supabase');

    const { data, error } = await supabase
      .from('follows')
      .select('following_id')
      .eq('follower_id', user.id);

    if (error) {
      console.error('Failed to fetch following IDs:', error);
      return [];
    }

    return (data || []).map(item => item.following_id);
  },

  async blockUser(userId: string): Promise<void> {
    const user = getUser();
    if (!user) throw new Error('Not authenticated');

    const { supabase } = await import('./supabase');

    const { error } = await supabase
      .from('blocked_users')
      .insert({
        blocker_id: user.id,
        blocked_id: userId
      });

    if (error && error.code !== '23505') {
      throw error;
    }
  },

  async unblockUser(userId: string): Promise<void> {
    const user = getUser();
    if (!user) throw new Error('Not authenticated');

    const { supabase } = await import('./supabase');

    await supabase
      .from('blocked_users')
      .delete()
      .eq('blocker_id', user.id)
      .eq('blocked_id', userId);
  },

  async isBlocked(userId: string): Promise<boolean> {
    const user = getUser();
    if (!user) return false;

    const { supabase } = await import('./supabase');

    const { data } = await supabase
      .from('blocked_users')
      .select('id')
      .eq('blocker_id', user.id)
      .eq('blocked_id', userId)
      .maybeSingle();

    return !!data;
  },

  async reportUser(userId: string, reason: string, description: string): Promise<void> {
    const user = getUser();
    if (!user) throw new Error('Not authenticated');

    const { supabase } = await import('./supabase');

    const { error } = await supabase
      .from('reports')
      .insert({
        reporter_id: user.id,
        reported_user_id: userId,
        report_type: reason,
        description
      });

    if (error) {
      throw error;
    }
  },

  async reportVideo(videoId: string, reason: string, description: string): Promise<void> {
    const user = getUser();
    if (!user) throw new Error('Not authenticated');

    const { supabase } = await import('./supabase');

    const { error } = await supabase
      .from('reports')
      .insert({
        reporter_id: user.id,
        reported_video_id: videoId,
        report_type: reason,
        description
      });

    if (error) {
      throw error;
    }
  },

  async updateProfile(data: Partial<User>): Promise<User> {
    const user = getUser();
    if (!user) throw new Error('Not authenticated');

    const users = getUsersDB();
    const userIndex = users.findIndex(u => u.id === user.id);
    if (userIndex !== -1) {
      users[userIndex] = { ...users[userIndex], ...data };
      localStorage.setItem(USERS_DB_KEY, JSON.stringify(users));
      localStorage.setItem('auth_user', JSON.stringify(users[userIndex]));
      return users[userIndex];
    }

    throw new Error('User not found');
  },

  async searchUsers(query: string): Promise<User[]> {
    const users = getUsersDB();
    return users.filter(u =>
      u.username.toLowerCase().includes(query.toLowerCase()) ||
      u.email.toLowerCase().includes(query.toLowerCase())
    );
  },

  async searchVideos(query: string): Promise<Video[]> {
    const videos = getVideosDB();
    return videos.filter(v =>
      v.title?.toLowerCase().includes(query.toLowerCase())
    );
  },

  async getNotifications(): Promise<Notification[]> {
    const user = getUser();
    if (!user) return [];

    const { supabase } = await import('./supabase');

    const { data, error } = await supabase
      .from('notifications')
      .select(`
        *,
        related_user:related_user_id(id, username, avatar_url)
      `)
      .eq('user_id', user.id)
      .order('created_at', { ascending: false });

    if (error) {
      console.error('Failed to fetch notifications:', error);
      return [];
    }

    return (data || []).map(notif => ({
      id: notif.id,
      user_id: notif.user_id,
      actor_id: notif.related_user_id,
      type: notif.type,
      reference_id: notif.related_video_id || notif.related_comment_id,
      message: notif.message,
      is_read: notif.is_read,
      created_at: notif.created_at,
      actor: notif.related_user ? {
        id: notif.related_user.id,
        username: notif.related_user.username,
        avatar_url: notif.related_user.avatar_url,
      } : undefined
    }));
  },

  async markNotificationRead(notificationId: string): Promise<void> {
    const user = getUser();
    if (!user) return;

    const { supabase } = await import('./supabase');

    await supabase
      .from('notifications')
      .update({ is_read: true })
      .eq('id', notificationId)
      .eq('user_id', user.id);
  },

  async markAllNotificationsRead(): Promise<void> {
    const user = getUser();
    if (!user) return;

    const { supabase } = await import('./supabase');

    await supabase
      .from('notifications')
      .update({ is_read: true })
      .eq('user_id', user.id)
      .eq('is_read', false);
  },

  async getWallet(): Promise<Wallet | null> {
    return {
      balance: 0,
      total_earned: 0,
      total_withdrawn: 0,
      pending: 0,
    };
  },

  async requestWithdrawal(amount: number, method: string, details: any): Promise<void> {
    console.log('Request withdrawal:', amount, method, details);
  },

  async getWithdrawalRequests(): Promise<WithdrawalRequest[]> {
    return [];
  },

  async getLiveRooms(): Promise<LiveRoom[]> {
    return [];
  },

  async createLiveRoom(title: string): Promise<LiveRoom> {
    const user = getUser();
    if (!user) throw new Error('Not authenticated');

    return {
      id: 'live_' + Date.now(),
      user_id: user.id,
      user,
      title,
      viewers_count: 0,
      is_live: true,
      created_at: new Date().toISOString(),
    };
  },

  async endLiveRoom(roomId: string): Promise<void> {
    console.log('End live room:', roomId);
  },

  async joinLiveRoom(roomId: string): Promise<void> {
    console.log('Join live room:', roomId);
  },

  async leaveLiveRoom(roomId: string): Promise<void> {
    console.log('Leave live room:', roomId);
  },

  async getMusicLibrary(): Promise<Music[]> {
    return [];
  },

  async shareVideo(videoId: string): Promise<void> {
    const videos = getVideosDB();
    const video = videos.find(v => v.id === videoId);
    if (video) {
      video.shares_count = (video.shares_count || 0) + 1;
      saveVideosDB(videos);
    }
  },

  async addWatchHistory(videoId: string): Promise<void> {
    const user = getUser();
    if (!user) return;

    const { supabase } = await import('./supabase');

    await supabase
      .from('watch_history')
      .insert({
        user_id: user.id,
        video_id: videoId,
        watch_duration: 0
      });

    const videos = getVideosDB();
    const video = videos.find(v => v.id === videoId);
    if (video) {
      video.views_count = (video.views_count || 0) + 1;
      saveVideosDB(videos);
    }
  },

  async reportContent(type: string, contentId: string, reason: string, description: string): Promise<void> {
    console.log('Report content:', type, contentId, reason, description);
  },

  async search(query: string): Promise<{ users: User[]; videos: Video[] }> {
    const users = await this.searchUsers(query);
    const videos = await this.searchVideos(query);
    return { users, videos };
  },

  async deleteVideo(videoId: string): Promise<void> {
    const videos = getVideosDB();
    const video = videos.find(v => v.id === videoId);

    if (video?.video_url && !video.video_url.includes('commondatastorage.googleapis.com')) {
      try {
        const { storageApi } = await import('./storage');
        await storageApi.deleteVideo(video.video_url);
      } catch (err) {
        console.error('Failed to delete video from storage:', err);
      }
    }

    const filtered = videos.filter(v => v.id !== videoId);
    saveVideosDB(filtered);
  },

  async toggleVideoPrivacy(videoId: string): Promise<void> {
    const videos = getVideosDB();
    const video = videos.find(v => v.id === videoId);
    if (video) {
      video.is_private = !video.is_private;
      saveVideosDB(videos);
    }
  },

  async checkUsernameChangeAllowed(userId: string, newUsername: string): Promise<{ allowed: boolean; message: string }> {
    const users = getUsersDB();
    const user = users.find(u => u.id === userId);

    if (!user) {
      return { allowed: false, message: 'User not found' };
    }

    const existingUser = users.find(u => u.username === newUsername && u.id !== userId);
    if (existingUser) {
      return { allowed: false, message: 'Username already taken' };
    }

    const lastChanged = user.username_changed_at;
    if (lastChanged) {
      const daysSinceChange = Math.floor((Date.now() - new Date(lastChanged).getTime()) / (1000 * 60 * 60 * 24));
      if (daysSinceChange < 20) {
        return { allowed: false, message: `You can change your username again in ${20 - daysSinceChange} days` };
      }
    }

    return { allowed: true, message: 'Username change allowed' };
  },

  async uploadAvatar(userId: string, file: File): Promise<{ url: string }> {
    const { storageApi } = await import('./storage');
    const url = await storageApi.uploadImage(file);
    return { url };
  },

  async updateUserProfile(userId: string, data: { username?: string; bio?: string; avatar_url?: string }): Promise<User> {
    const users = getUsersDB();
    const userIndex = users.findIndex(u => u.id === userId);

    if (userIndex === -1) {
      throw new Error('User not found');
    }

    const updates: any = { ...data };
    if (data.username && data.username !== users[userIndex].username) {
      updates.username_changed_at = new Date().toISOString();
    }

    users[userIndex] = { ...users[userIndex], ...updates };
    localStorage.setItem(USERS_DB_KEY, JSON.stringify(users));
    localStorage.setItem('auth_user', JSON.stringify(users[userIndex]));

    return users[userIndex];
  },

  async getUserSettings(userId: string): Promise<any> {
    const { supabase } = await import('./supabase');

    const { data: user, error } = await supabase
      .from('users')
      .select('is_private, who_can_comment, who_can_message, who_can_mention, allow_downloads')
      .eq('id', userId)
      .maybeSingle();

    if (error || !user) {
      return {
        is_private: false,
        who_can_comment: 'Everyone',
        who_can_message: 'Everyone',
        who_can_mention: 'Everyone',
        allow_downloads: true,
        show_activity_status: true,
        allow_mentions: true,
        allow_duets: true,
        privacy_settings: {
          profile_visibility: 'public',
          who_can_comment: 'Everyone',
          who_can_duet: 'Everyone',
          who_can_message: 'Everyone',
        },
        notification_settings: {
          likes: true,
          comments: true,
          new_followers: true,
          mentions: true,
          live_notifications: true,
        },
        theme_preference: 'dark'
      };
    }

    return {
      is_private: user.is_private,
      who_can_comment: user.who_can_comment,
      who_can_message: user.who_can_message,
      who_can_mention: user.who_can_mention,
      allow_downloads: user.allow_downloads,
      show_activity_status: true,
      allow_mentions: user.who_can_mention !== 'NoOne',
      allow_duets: true,
      privacy_settings: {
        profile_visibility: user.is_private ? 'private' : 'public',
        who_can_comment: user.who_can_comment,
        who_can_duet: 'Everyone',
        who_can_message: user.who_can_message,
      },
      notification_settings: {
        likes: true,
        comments: true,
        new_followers: true,
        mentions: true,
        live_notifications: true,
      },
      theme_preference: 'dark'
    };
  },

  async updateUserSettings(userId: string, settings: any): Promise<void> {
    const { supabase } = await import('./supabase');

    const updates: any = {};

    if (settings.is_private !== undefined) {
      updates.is_private = settings.is_private;
    }
    if (settings.who_can_comment !== undefined) {
      updates.who_can_comment = settings.who_can_comment;
    }
    if (settings.who_can_message !== undefined) {
      updates.who_can_message = settings.who_can_message;
    }
    if (settings.who_can_mention !== undefined) {
      updates.who_can_mention = settings.who_can_mention;
    }
    if (settings.allow_downloads !== undefined) {
      updates.allow_downloads = settings.allow_downloads;
    }
    if (settings.allow_mentions !== undefined) {
      updates.who_can_mention = settings.allow_mentions ? 'Everyone' : 'NoOne';
    }

    if (settings.privacy_settings) {
      if (settings.privacy_settings.profile_visibility === 'private') {
        updates.is_private = true;
      } else if (settings.privacy_settings.profile_visibility === 'public') {
        updates.is_private = false;
      }
      if (settings.privacy_settings.who_can_comment) {
        updates.who_can_comment = settings.privacy_settings.who_can_comment;
      }
      if (settings.privacy_settings.who_can_message) {
        updates.who_can_message = settings.privacy_settings.who_can_message;
      }
    }

    if (Object.keys(updates).length > 0) {
      await supabase
        .from('users')
        .update(updates)
        .eq('id', userId);
    }
  },

  async getWatchHistory(): Promise<any[]> {
    const user = getUser();
    if (!user) return [];

    const { supabase } = await import('./supabase');

    const { data, error } = await supabase
      .from('watch_history')
      .select(`
        *,
        video:videos (
          *,
          user:users (*)
        )
      `)
      .eq('user_id', user.id)
      .order('watched_at', { ascending: false })
      .limit(100);

    if (error) {
      console.error('Failed to fetch watch history:', error);
      return [];
    }

    return (data || [])
      .filter(item => item.video)
      .map(item => ({
        ...item.video,
        user: item.video.user,
        watched_at: item.watched_at
      }));
  },

  async clearWatchHistory(userId: string): Promise<void> {
    const { supabase } = await import('./supabase');

    await supabase
      .from('watch_history')
      .delete()
      .eq('user_id', userId);
  },

  async deleteAccount(password: string): Promise<void> {
    const token = getToken();
    if (!token) throw new Error('Not authenticated');

    const response = await fetch(`${import.meta.env.VITE_SUPABASE_URL}/functions/v1/auth/delete-account`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${token}`,
        'apikey': import.meta.env.VITE_SUPABASE_ANON_KEY,
      },
      body: JSON.stringify({ password })
    });

    const data = await response.json();

    if (!response.ok || data.error) {
      throw new Error(data.message || 'Failed to delete account');
    }

    localStorage.removeItem('auth_token');
    localStorage.removeItem('auth_refresh_token');
    localStorage.removeItem('auth_user');
  },
};
