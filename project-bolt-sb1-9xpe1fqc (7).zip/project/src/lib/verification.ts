import type { User } from '../lib/types';

export interface VerificationResult {
  success: boolean;
  countryCode?: string;
  vpnDetected?: boolean;
  message?: string;
}

export interface CountryInfo {
  code: string;
  name: string;
  eligibleForViewPayouts: boolean;
}

export const ELIGIBLE_COUNTRIES = ['KE', 'SO'];

export const COUNTRY_NAMES: Record<string, string> = {
  'KE': 'Kenya',
  'SO': 'Somalia'
};

export async function detectCountry(): Promise<{ countryCode: string; vpnDetected: boolean }> {
  try {
    const response = await fetch('https://ipapi.co/json/');
    const data = await response.json();

    const countryCode = data.country_code || 'UNKNOWN';
    const vpnDetected = data.vpn || data.proxy || data.hosting || false;

    return { countryCode, vpnDetected };
  } catch (error) {
    console.error('Error detecting country:', error);
    return { countryCode: 'UNKNOWN', vpnDetected: false };
  }
}

export async function generateVerificationCode(): Promise<string> {
  return Math.floor(100000 + Math.random() * 900000).toString();
}

const VERIFICATION_DB_KEY = 'verification_data';

function getVerificationDB(): Record<string, any> {
  try {
    const data = localStorage.getItem(VERIFICATION_DB_KEY);
    return data ? JSON.parse(data) : {};
  } catch {
    return {};
  }
}

function saveVerificationDB(data: Record<string, any>) {
  localStorage.setItem(VERIFICATION_DB_KEY, JSON.stringify(data));
}

export async function sendVerificationCode(userId: string, code: string): Promise<boolean> {
  try {
    const expiresAt = new Date();
    expiresAt.setMinutes(expiresAt.getMinutes() + 15);

    const { countryCode, vpnDetected } = await detectCountry();

    const db = getVerificationDB();
    db[userId] = {
      user_id: userId,
      country_code: countryCode,
      verification_code: code,
      code_expires_at: expiresAt.toISOString(),
      vpn_detected: vpnDetected,
      is_verified: false
    };
    saveVerificationDB(db);

    console.log(`Verification code for user ${userId}: ${code}`);
    return true;
  } catch (error) {
    console.error('Error sending verification code:', error);
    return false;
  }
}

export async function verifyCode(userId: string, code: string): Promise<VerificationResult> {
  try {
    const db = getVerificationDB();
    const data = db[userId];

    if (!data) {
      return { success: false, message: 'No verification request found' };
    }

    if (data.verification_code !== code) {
      return { success: false, message: 'Invalid verification code' };
    }

    const expiresAt = new Date(data.code_expires_at);
    if (expiresAt < new Date()) {
      return { success: false, message: 'Verification code expired' };
    }

    if (data.vpn_detected) {
      return {
        success: false,
        message: 'VPN detected. Please disable VPN and try again.',
        vpnDetected: true
      };
    }

    data.is_verified = true;
    data.verified_at = new Date().toISOString();
    db[userId] = data;
    saveVerificationDB(db);

    return {
      success: true,
      countryCode: data.country_code,
      vpnDetected: false
    };
  } catch (error) {
    console.error('Error verifying code:', error);
    return { success: false, message: 'Verification failed' };
  }
}

export async function getUserVerification(userId: string) {
  try {
    const db = getVerificationDB();
    return db[userId] || null;
  } catch (error) {
    console.error('Error fetching verification:', error);
    return null;
  }
}

export async function getMonetizationEligibility(userId: string) {
  try {
    const db = getVerificationDB();
    const verification = db[userId];

    if (!verification) {
      return null;
    }

    return {
      user_id: userId,
      is_eligible: ELIGIBLE_COUNTRIES.includes(verification.country_code),
      country_code: verification.country_code,
      reason: verification.vpn_detected ? 'VPN Detected' : 'Eligible'
    };
  } catch (error) {
    console.error('Error fetching eligibility:', error);
    return null;
  }
}

export function isEligibleCountry(countryCode: string): boolean {
  return ELIGIBLE_COUNTRIES.includes(countryCode);
}

export function getCountryName(countryCode: string): string {
  return COUNTRY_NAMES[countryCode] || countryCode;
}

export async function refreshMonetizationStatus(userId: string): Promise<void> {
  try {
    await getMonetizationEligibility(userId);
  } catch (error) {
    console.error('Error refreshing monetization status:', error);
  }
}