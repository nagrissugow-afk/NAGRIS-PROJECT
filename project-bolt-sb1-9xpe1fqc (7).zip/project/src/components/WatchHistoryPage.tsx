import { useState, useEffect } from 'react';
import { ArrowLeft, Trash2, Clock } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { api } from '../lib/api';
import { getCurrentUser } from '../lib/customAuth';
import type { Video } from '../lib/types';

export default function WatchHistoryPage() {
  const navigate = useNavigate();
  const [videos, setVideos] = useState<Video[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadHistory();
  }, []);

  const loadHistory = async () => {
    try {
      const history = await api.getWatchHistory();
      setVideos(history);
    } catch (err) {
      console.error('Failed to load watch history:', err);
    } finally {
      setLoading(false);
    }
  };

  const handleClearHistory = async () => {
    if (!confirm('Are you sure you want to clear your entire watch history? This cannot be undone.')) {
      return;
    }

    try {
      const user = await getCurrentUser();
      if (!user) return;

      await api.clearWatchHistory(user.id);
      setVideos([]);
      alert('Watch history cleared');
    } catch (err) {
      console.error('Failed to clear history:', err);
      alert('Failed to clear watch history');
    }
  };

  const handleVideoClick = (video: Video) => {
    navigate('/', { state: { videoId: video.id } });
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-900 via-blue-900 to-slate-900 flex items-center justify-center">
        <p className="text-white">Loading history...</p>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-blue-900 to-slate-900 pb-20">
      <div className="max-w-4xl mx-auto">
        <div className="sticky top-0 bg-slate-900/80 backdrop-blur-lg border-b border-slate-700 px-4 py-4 flex items-center gap-4 z-10">
          <button
            onClick={() => navigate('/settings')}
            className="text-white hover:bg-slate-700/50 p-2 rounded-lg transition-colors"
          >
            <ArrowLeft size={24} />
          </button>
          <div className="flex-1">
            <h1 className="text-xl font-bold text-white">Watch History</h1>
            <p className="text-sm text-slate-400">{videos.length} videos</p>
          </div>
          {videos.length > 0 && (
            <button
              onClick={handleClearHistory}
              className="flex items-center gap-2 px-4 py-2 bg-red-500/20 hover:bg-red-500/30 text-red-400 rounded-lg transition-colors"
            >
              <Trash2 size={18} />
              <span className="text-sm font-medium">Clear All</span>
            </button>
          )}
        </div>

        <div className="px-4 py-6">
          {videos.length === 0 ? (
            <div className="text-center py-16">
              <div className="w-20 h-20 bg-slate-800 rounded-full flex items-center justify-center mx-auto mb-4">
                <Clock className="text-slate-600" size={40} />
              </div>
              <p className="text-slate-400 text-lg">No watch history yet</p>
              <p className="text-slate-500 text-sm mt-2">Videos you watch will appear here</p>
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
              {videos.map((video) => (
                <div
                  key={video.id}
                  onClick={() => handleVideoClick(video)}
                  className="bg-slate-800/50 backdrop-blur-lg rounded-xl border border-slate-700 overflow-hidden cursor-pointer hover:border-cyan-500/50 transition-colors group"
                >
                  <div className="relative aspect-[9/16]">
                    {video.thumbnail_url ? (
                      <img
                        src={video.thumbnail_url}
                        alt={video.title}
                        className="w-full h-full object-cover"
                      />
                    ) : (
                      <div className="w-full h-full bg-gradient-to-br from-cyan-500 to-blue-600 flex items-center justify-center">
                        <Clock size={48} className="text-white/50" />
                      </div>
                    )}
                    <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent opacity-0 group-hover:opacity-100 transition-opacity" />
                  </div>

                  <div className="p-3 space-y-2">
                    <div className="flex items-start gap-2">
                      <img
                        src={video.user?.avatar_url || 'https://via.placeholder.com/32'}
                        alt={video.user?.username}
                        className="w-8 h-8 rounded-full"
                      />
                      <div className="flex-1 min-w-0">
                        <p className="text-white text-sm font-medium line-clamp-2">
                          {video.title || 'Untitled Video'}
                        </p>
                        <p className="text-slate-400 text-xs">@{video.user?.username}</p>
                      </div>
                    </div>

                    <div className="flex items-center gap-4 text-xs text-slate-400">
                      <span>{video.views_count || 0} views</span>
                      <span>{video.likes_count || 0} likes</span>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
