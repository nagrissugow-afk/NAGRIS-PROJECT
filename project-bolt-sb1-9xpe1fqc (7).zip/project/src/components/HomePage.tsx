import { useState, useEffect, useRef, useCallback } from 'react';
import { Search, X } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import type { User, Video } from '../lib/types';
import { api } from '../lib/api';
import { useAuth } from '../lib/newAuthContext';  // ✅ use newAuthContext
import VideoPlayer from './VideoPlayer';
import CommentsModal from './CommentsModal';
import ReportModal from './ReportModal';

export default function HomePage() {
  const navigate = useNavigate();
  const { user } = useAuth();
  const [activeTab, setActiveTab] = useState<'foryou' | 'following'>('foryou');
  const [videos, setVideos] = useState<Video[]>([]);
  const [loading, setLoading] = useState(true);
  const [currentIndex, setCurrentIndex] = useState(0);
  const [nextCursor, setNextCursor] = useState<string | undefined>();
  const [selectedVideo, setSelectedVideo] = useState<Video | null>(null);
  const [showComments, setShowComments] = useState(false);
  const [showReport, setShowReport] = useState(false);
  const [showSearch, setShowSearch] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [searchResults, setSearchResults] = useState<any[]>([]);
  const containerRef = useRef<HTMLDivElement>(null);

  const loadVideos = useCallback(async (cursor?: string) => {
    try {
      let response;
      if (activeTab === 'following' && user) {
        response = await api.getFollowingVideos(cursor);
      } else {
        response = await api.getVideos(cursor);
      }
      setVideos(prev => cursor ? [...prev, ...response.videos] : response.videos);
      setNextCursor(response.nextCursor);
      setLoading(false);
    } catch (err) {
      console.error('Failed to load videos:', err);
      setLoading(false);
    }
  }, [activeTab, user]);

  useEffect(() => {
    setVideos([]);
    setLoading(true);
    setCurrentIndex(0);
    loadVideos();
  }, [activeTab, loadVideos]);

  useEffect(() => {
    const container = containerRef.current;
    if (!container) return;

    const handleScroll = () => {
      const scrollTop = container.scrollTop;
      const videoHeight = window.innerHeight;
      const newIndex = Math.round(scrollTop / videoHeight);

      setCurrentIndex(newIndex);

      if (newIndex >= videos.length - 3 && nextCursor && !loading) {
        loadVideos(nextCursor);
      }
    };

    container.addEventListener('scroll', handleScroll);
    return () => container.removeEventListener('scroll', handleScroll);
  }, [videos.length, nextCursor, loading, loadVideos]);

  const handleSearch = async (query: string) => {
    if (!query.trim()) {
      setSearchResults([]);
      return;
    }

    try {
      // ✅ Use backend API instead of Supabase
      const results = await api.search(query); 

      // results should return { users: User[], videos: Video[] }
      setSearchResults([
        ...results.users.map(u => ({ type: 'user', data: u })),
        ...results.videos.map(v => ({ type: 'video', data: v }))
      ]);
    } catch (err) {
      console.error('Search failed:', err);
    }
  };

  if (loading && videos.length === 0) {
    return (
      <div className="flex items-center justify-center h-screen bg-black">
        <div className="text-white text-xl">Loading videos...</div>
      </div>
    );
  }

  return (
    <div className="relative h-screen bg-black">
      <div className="fixed top-0 left-0 right-0 z-20 bg-gradient-to-b from-black/80 to-transparent">
        <div className="flex items-center justify-between p-4">
          <button
            onClick={() => setShowSearch(!showSearch)}
            className="p-2 text-white hover:bg-white/10 rounded-full transition-colors"
          >
            <Search size={24} />
          </button>

          <div className="flex-1 flex justify-center">
            <div className="bg-black/40 backdrop-blur-sm rounded-full p-1 flex gap-1">
              <button
                onClick={() => setActiveTab('following')}
                disabled={!user}
                className={`px-6 py-2 rounded-full font-semibold transition-all ${
                  activeTab === 'following'
                    ? 'bg-white text-black'
                    : 'text-white/70 hover:text-white disabled:opacity-50'
                }`}
              >
                Following
              </button>
              <button
                onClick={() => setActiveTab('foryou')}
                className={`px-6 py-2 rounded-full font-semibold transition-all ${
                  activeTab === 'foryou'
                    ? 'bg-white text-black'
                    : 'text-white/70 hover:text-white'
                }`}
              >
                For You
              </button>
            </div>
          </div>

          <div className="w-10"></div>
        </div>

        {showSearch && (
          <div className="absolute top-full left-0 right-0 bg-slate-900 border-b border-slate-700 max-h-96 overflow-y-auto">
            <div className="p-4">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={20} />
                <input
                  type="text"
                  value={searchQuery}
                  onChange={(e) => {
                    setSearchQuery(e.target.value);
                    handleSearch(e.target.value);
                  }}
                  placeholder="Search users, videos..."
                  className="w-full pl-10 pr-10 py-3 bg-slate-800 border border-slate-700 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-cyan-500"
                  autoFocus
                />
                {searchQuery && (
                  <button
                    onClick={() => {
                      setSearchQuery('');
                      setSearchResults([]);
                    }}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-white"
                  >
                    <X size={20} />
                  </button>
                )}
              </div>

              {searchResults.length > 0 && (
                <div className="mt-4 space-y-2">
                  {searchResults.map((result, index) => (
                    <div
                      key={index}
                      onClick={() => {
                        if (result.type === 'user') {
                          navigate(`/profile/${result.data.id}`);
                          setShowSearch(false);
                        }
                      }}
                      className="p-3 bg-slate-800 rounded-lg hover:bg-slate-700 cursor-pointer transition-colors"
                    >
                      {result.type === 'user' ? (
                        <div className="flex items-center gap-3">
                          <img
                            src={result.data.avatar_url || `https://api.dicebear.com/7.x/avataaars/svg?seed=${result.data.username}`}
                            alt={result.data.username}
                            className="w-10 h-10 rounded-full"
                          />
                          <div>
                            <p className="text-white font-medium">@{result.data.username}</p>
                            <p className="text-slate-400 text-sm">{result.data.full_name || 'User'}</p>
                          </div>
                        </div>
                      ) : (
                        <div className="flex gap-3">
                          <img
                            src={result.data.thumbnail_url || '/default-thumbnail.jpg'}
                            alt="Video"
                            className="w-16 h-24 object-cover rounded"
                          />
                          <div className="flex-1">
                            <p className="text-white line-clamp-2">{result.data.caption}</p>
                            <p className="text-slate-400 text-sm">@{result.data.users?.username}</p>
                          </div>
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        )}
      </div>

      <div
        ref={containerRef}
        className="h-screen overflow-y-scroll snap-y snap-mandatory scroll-smooth hide-scrollbar"
      >
        {videos.map((video, index) => (
          <div key={video.id} className="h-screen snap-start relative">
            <VideoPlayer
              video={video}
              isActive={index === currentIndex}
              onOpenComments={() => {
                setSelectedVideo(video);
                setShowComments(true);
              }}
              onReport={() => {
                setSelectedVideo(video);
                setShowReport(true);
              }}
            />
          </div>
        ))}
      </div>

      {showComments && selectedVideo && (
        <CommentsModal
          video={selectedVideo}
          onClose={() => setShowComments(false)}
        />
      )}

      {showReport && selectedVideo && (
        <ReportModal
          contentType="video"
          contentId={selectedVideo.id}
          onClose={() => setShowReport(false)}
        />
      )}
    </div>
  );
}
