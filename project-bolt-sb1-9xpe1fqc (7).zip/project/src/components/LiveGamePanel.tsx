import { useState, useEffect } from 'react';
import { X, Plus, Check } from 'lucide-react';
import { liveApi, type LiveGame } from '../lib/liveApi';

interface LiveGamePanelProps {
  streamId: string;
  onClose: () => void;
}

export default function LiveGamePanel({ streamId, onClose }: LiveGamePanelProps) {
  const [activeGame, setActiveGame] = useState<LiveGame | null>(null);
  const [gameType, setGameType] = useState<'poll' | 'trivia' | 'spin_wheel'>('poll');
  const [showCreate, setShowCreate] = useState(false);

  const [pollQuestion, setPollQuestion] = useState('');
  const [pollOptions, setPollOptions] = useState(['', '', '', '']);

  const [triviaQuestion, setTriviaQuestion] = useState('');
  const [triviaOptions, setTriviaOptions] = useState(['', '', '', '']);
  const [correctAnswer, setCorrectAnswer] = useState(0);

  const [wheelPrizes, setWheelPrizes] = useState(['', '', '', '', '', '']);

  useEffect(() => {
    const subscription = liveApi.subscribeToGames(streamId, (game) => {
      if (game.is_active) {
        setActiveGame(game);
      } else {
        setActiveGame(null);
      }
    });

    return () => {
      subscription.unsubscribe();
    };
  }, [streamId]);

  const handleCreatePoll = async () => {
    const validOptions = pollOptions.filter(opt => opt.trim());
    if (!pollQuestion.trim() || validOptions.length < 2) {
      alert('Please enter a question and at least 2 options');
      return;
    }

    try {
      const game = await liveApi.startGame(streamId, 'poll', {
        question: pollQuestion,
        options: validOptions,
      });
      setActiveGame(game);
      setShowCreate(false);
      resetForms();
    } catch (err) {
      console.error('Failed to create poll:', err);
    }
  };

  const handleCreateTrivia = async () => {
    const validOptions = triviaOptions.filter(opt => opt.trim());
    if (!triviaQuestion.trim() || validOptions.length < 2) {
      alert('Please enter a question and at least 2 options');
      return;
    }

    try {
      const game = await liveApi.startGame(streamId, 'trivia', {
        question: triviaQuestion,
        options: validOptions,
        correctAnswer,
      });
      setActiveGame(game);
      setShowCreate(false);
      resetForms();
    } catch (err) {
      console.error('Failed to create trivia:', err);
    }
  };

  const handleCreateSpinWheel = async () => {
    const validPrizes = wheelPrizes.filter(prize => prize.trim());
    if (validPrizes.length < 4) {
      alert('Please enter at least 4 prizes');
      return;
    }

    try {
      const game = await liveApi.startGame(streamId, 'spin_wheel', {
        prizes: validPrizes,
      });
      setActiveGame(game);
      setShowCreate(false);
      resetForms();
    } catch (err) {
      console.error('Failed to create spin wheel:', err);
    }
  };

  const handleEndGame = async () => {
    if (!activeGame) return;

    try {
      await liveApi.endGame(activeGame.id);
      setActiveGame(null);
    } catch (err) {
      console.error('Failed to end game:', err);
    }
  };

  const resetForms = () => {
    setPollQuestion('');
    setPollOptions(['', '', '', '']);
    setTriviaQuestion('');
    setTriviaOptions(['', '', '', '']);
    setCorrectAnswer(0);
    setWheelPrizes(['', '', '', '', '', '']);
  };

  return (
    <div className="absolute top-0 right-0 bottom-0 w-80 bg-slate-800 shadow-2xl z-50 flex flex-col">
      <div className="p-4 border-b border-slate-700 flex items-center justify-between">
        <h3 className="text-white font-bold">Live Games</h3>
        <button
          onClick={onClose}
          className="p-1 hover:bg-slate-700 rounded transition-colors text-white"
        >
          <X size={20} />
        </button>
      </div>

      <div className="flex-1 overflow-y-auto p-4">
        {activeGame ? (
          <div className="bg-slate-700 rounded-lg p-4">
            <div className="flex items-center justify-between mb-3">
              <span className="text-xs bg-green-500 text-white px-2 py-1 rounded-full font-semibold">
                ACTIVE
              </span>
              <span className="text-xs text-slate-300 uppercase">{activeGame.game_type}</span>
            </div>

            <p className="text-white font-semibold mb-2">
              {activeGame.game_data.question || 'Game Active'}
            </p>

            {activeGame.game_data.options && (
              <div className="space-y-2 mb-4">
                {activeGame.game_data.options.map((option: string, index: number) => (
                  <div
                    key={index}
                    className="bg-slate-600 rounded-lg px-3 py-2 text-sm text-white"
                  >
                    {option}
                  </div>
                ))}
              </div>
            )}

            <button
              onClick={handleEndGame}
              className="w-full px-4 py-2 bg-red-500 hover:bg-red-600 text-white rounded-lg font-semibold transition-colors"
            >
              End Game
            </button>
          </div>
        ) : showCreate ? (
          <div>
            <div className="flex gap-2 mb-4">
              <button
                onClick={() => setGameType('poll')}
                className={`flex-1 px-3 py-2 rounded-lg text-sm font-semibold transition-colors ${
                  gameType === 'poll'
                    ? 'bg-cyan-500 text-white'
                    : 'bg-slate-700 text-slate-300 hover:bg-slate-600'
                }`}
              >
                Poll
              </button>
              <button
                onClick={() => setGameType('trivia')}
                className={`flex-1 px-3 py-2 rounded-lg text-sm font-semibold transition-colors ${
                  gameType === 'trivia'
                    ? 'bg-cyan-500 text-white'
                    : 'bg-slate-700 text-slate-300 hover:bg-slate-600'
                }`}
              >
                Trivia
              </button>
              <button
                onClick={() => setGameType('spin_wheel')}
                className={`flex-1 px-3 py-2 rounded-lg text-sm font-semibold transition-colors ${
                  gameType === 'spin_wheel'
                    ? 'bg-cyan-500 text-white'
                    : 'bg-slate-700 text-slate-300 hover:bg-slate-600'
                }`}
              >
                Wheel
              </button>
            </div>

            {gameType === 'poll' && (
              <div className="space-y-3">
                <input
                  type="text"
                  value={pollQuestion}
                  onChange={(e) => setPollQuestion(e.target.value)}
                  placeholder="Poll question"
                  className="w-full px-3 py-2 bg-slate-700 text-white rounded-lg focus:outline-none focus:ring-2 focus:ring-cyan-500"
                />
                {pollOptions.map((option, index) => (
                  <input
                    key={index}
                    type="text"
                    value={option}
                    onChange={(e) => {
                      const newOptions = [...pollOptions];
                      newOptions[index] = e.target.value;
                      setPollOptions(newOptions);
                    }}
                    placeholder={`Option ${index + 1}`}
                    className="w-full px-3 py-2 bg-slate-700 text-white rounded-lg focus:outline-none focus:ring-2 focus:ring-cyan-500"
                  />
                ))}
                <button
                  onClick={handleCreatePoll}
                  className="w-full px-4 py-2 bg-cyan-500 hover:bg-cyan-600 text-white rounded-lg font-semibold transition-colors"
                >
                  Start Poll
                </button>
              </div>
            )}

            {gameType === 'trivia' && (
              <div className="space-y-3">
                <input
                  type="text"
                  value={triviaQuestion}
                  onChange={(e) => setTriviaQuestion(e.target.value)}
                  placeholder="Trivia question"
                  className="w-full px-3 py-2 bg-slate-700 text-white rounded-lg focus:outline-none focus:ring-2 focus:ring-cyan-500"
                />
                {triviaOptions.map((option, index) => (
                  <div key={index} className="flex gap-2">
                    <input
                      type="text"
                      value={option}
                      onChange={(e) => {
                        const newOptions = [...triviaOptions];
                        newOptions[index] = e.target.value;
                        setTriviaOptions(newOptions);
                      }}
                      placeholder={`Option ${index + 1}`}
                      className="flex-1 px-3 py-2 bg-slate-700 text-white rounded-lg focus:outline-none focus:ring-2 focus:ring-cyan-500"
                    />
                    <button
                      onClick={() => setCorrectAnswer(index)}
                      className={`px-3 py-2 rounded-lg transition-colors ${
                        correctAnswer === index
                          ? 'bg-green-500 text-white'
                          : 'bg-slate-600 text-slate-300 hover:bg-slate-500'
                      }`}
                    >
                      <Check size={16} />
                    </button>
                  </div>
                ))}
                <button
                  onClick={handleCreateTrivia}
                  className="w-full px-4 py-2 bg-cyan-500 hover:bg-cyan-600 text-white rounded-lg font-semibold transition-colors"
                >
                  Start Trivia
                </button>
              </div>
            )}

            {gameType === 'spin_wheel' && (
              <div className="space-y-3">
                <p className="text-sm text-slate-300 mb-2">Enter prizes for the wheel</p>
                {wheelPrizes.map((prize, index) => (
                  <input
                    key={index}
                    type="text"
                    value={prize}
                    onChange={(e) => {
                      const newPrizes = [...wheelPrizes];
                      newPrizes[index] = e.target.value;
                      setWheelPrizes(newPrizes);
                    }}
                    placeholder={`Prize ${index + 1}`}
                    className="w-full px-3 py-2 bg-slate-700 text-white rounded-lg focus:outline-none focus:ring-2 focus:ring-cyan-500"
                  />
                ))}
                <button
                  onClick={handleCreateSpinWheel}
                  className="w-full px-4 py-2 bg-cyan-500 hover:bg-cyan-600 text-white rounded-lg font-semibold transition-colors"
                >
                  Start Spin Wheel
                </button>
              </div>
            )}

            <button
              onClick={() => setShowCreate(false)}
              className="w-full px-4 py-2 bg-slate-700 hover:bg-slate-600 text-white rounded-lg font-semibold transition-colors mt-3"
            >
              Cancel
            </button>
          </div>
        ) : (
          <div className="text-center">
            <p className="text-slate-400 mb-4">No active games</p>
            <button
              onClick={() => setShowCreate(true)}
              className="flex items-center justify-center gap-2 w-full px-4 py-3 bg-cyan-500 hover:bg-cyan-600 text-white rounded-lg font-semibold transition-colors"
            >
              <Plus size={20} />
              Create Game
            </button>
          </div>
        )}
      </div>
    </div>
  );
}
