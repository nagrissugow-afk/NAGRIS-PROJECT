import { useState, useRef, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Heart, MessageCircle, Share2, Bookmark, Volume2, VolumeX, UserPlus, UserMinus, MoreVertical } from 'lucide-react';
import type { Video } from '../lib/types';
import { api } from '../lib/api';
import { useAuth } from '../lib/newAuthContext'; // ✅ use custom auth
import ShareMenu from "./ShareMenu";

interface VideoPlayerProps {
  video: Video;
  isActive: boolean;
  onOpenComments: () => void;
  onReport: () => void;
}

export default function VideoPlayer({ video, isActive, onOpenComments, onReport }: VideoPlayerProps) {
  const navigate = useNavigate();
  const { user: authUser } = useAuth(); // ✅ current logged-in user
  const videoRef = useRef<HTMLVideoElement>(null);
  const [isPlaying, setIsPlaying] = useState(false);
  const [isMuted, setIsMuted] = useState(() => {
    const savedMute = localStorage.getItem('video_muted');
    return savedMute === 'true';
  });
  const [liked, setLiked] = useState(false);
  const [saved, setSaved] = useState(false);
  const [likes, setLikes] = useState(video.likes_count || 0);
  const [saves, setSaves] = useState(video.saves_count || 0);
  const [shares, setShares] = useState(video.shares_count || 0);
  const [showShareMenu, setShowShareMenu] = useState(false);
  const [showMenu, setShowMenu] = useState(false);
  const [isFollowing, setIsFollowing] = useState(false);
  const [currentUserId, setCurrentUserId] = useState<string | null>(null);

  useEffect(() => {
    const playVideo = async () => {
      if (videoRef.current && isActive) {
        try {
          videoRef.current.currentTime = 0;
          await videoRef.current.play();
          setIsPlaying(true);
          api.addWatchHistory(video.id);
        } catch (error) {
          console.error('Failed to play video:', error);
          setIsPlaying(false);
        }
      } else if (videoRef.current && !isActive) {
        videoRef.current.pause();
        setIsPlaying(false);
      }
    };

    playVideo();
  }, [isActive, video.id]);

  useEffect(() => {
    if (authUser) {
      setCurrentUserId(authUser.id); // ✅ no supabase here
    }
    checkFollowStatus();
    checkEngagementStatus();
  }, [video.user?.id, video.id, authUser]);

  const checkEngagementStatus = async () => {
    try {
      const [likedStatus, savedStatus] = await Promise.all([
        api.checkVideoLiked(video.id),
        api.checkVideoSaved(video.id)
      ]);
      setLiked(likedStatus);
      setSaved(savedStatus);
    } catch (err) {
      console.error('Failed to check engagement status:', err);
    }
  };

  const checkFollowStatus = async () => {
    if (!video.user?.id) return;
    try {
      const following = await api.isFollowing(video.user.id);
      setIsFollowing(following);
    } catch (err) {
      console.error('Failed to check follow status:', err);
    }
  };

  const handleFollow = async () => {
    if (!video.user?.id) return;
    try {
      if (isFollowing) {
        await api.unfollowUser(video.user.id);
      } else {
        await api.followUser(video.user.id);
      }
      setIsFollowing(!isFollowing);
    } catch (err) {
      console.error('Failed to follow/unfollow:', err);
    }
  };

  const goToProfile = () => {
    if (video.user?.id) {
      navigate(`/profile/${video.user.id}`);
    }
  };

  const togglePlay = async (e: React.MouseEvent) => {
    e.stopPropagation();
    if (videoRef.current) {
      try {
        if (isPlaying) {
          videoRef.current.pause();
          setIsPlaying(false);
        } else {
          await videoRef.current.play();
          setIsPlaying(true);
        }
      } catch (error) {
        console.error('Toggle play error:', error);
      }
    }
  };
   let lastTap = 0;

const handleTap = async () => {
  const now = Date.now();
  if (now - lastTap < 300) {
    // 👉 Double tap = like
    await handleLike();
  } else {
    // 👉 Single tap = pause/play
    togglePlay(new MouseEvent("click") as any);
  }
  lastTap = now;
};
  
  const toggleMute = () => {
    if (videoRef.current) {
      const newMutedState = !isMuted;
      videoRef.current.muted = newMutedState;
      setIsMuted(newMutedState);
      localStorage.setItem('video_muted', String(newMutedState));
    }
  };

  const handleLike = async () => {
    const newLiked = !liked;
    const newLikes = newLiked ? likes + 1 : likes - 1;

    setLiked(newLiked);
    setLikes(newLikes);

    try {
      if (newLiked) {
        await api.likeVideo(video.id);
      } else {
        await api.unlikeVideo(video.id);
      }
    } catch (err) {
      console.error('Failed to like video:', err);
      setLiked(!newLiked);
      setLikes(likes);
    }
  };

  const handleSave = async () => {
    const newSaved = !saved;
    const newSaves = newSaved ? saves + 1 : saves - 1;

    setSaved(newSaved);
    setSaves(newSaves);

    try {
      if (newSaved) {
        await api.saveVideo(video.id);
      } else {
        await api.unsaveVideo(video.id);
      }
    } catch (err) {
      console.error('Failed to save video:', err);
      setSaved(!newSaved);
      setSaves(saves);
    }
  };

  const handleShare = async () => {
    try {
      await api.shareVideo(video.id);
      setShares(shares + 1);

      if (navigator.share) {
        await navigator.share({
          title: video.title,
          text: `Check out this video on Nagris!`,
          url: window.location.href,
        });
      } else {
        await navigator.clipboard.writeText(window.location.href);
        alert('Link copied to clipboard!');
      }
    } catch (err) {
      console.error('Failed to share video:', err);
    }
  };

  const formatCount = (count: number): string => {
    if (count >= 1000000) {
      return (count / 1000000).toFixed(1) + 'M';
    } else if (count >= 1000) {
      return (count / 1000).toFixed(1) + 'K';
    }
    return count.toString();
  };

  return (
    <div className="relative w-full h-screen bg-black snap-start snap-always">
      <video
        ref={videoRef}
        src={video.video_url}
        className="w-full h-full object-contain"
        loop
        playsInline
        muted={isMuted}
        onClick={handleTap}
        preload="auto"
        crossOrigin="anonymous"
        onLoadedData={() => {
          if (videoRef.current && isActive) {
            videoRef.current.play().catch(() => {});
          }
        }}
        onPlay={() => setIsPlaying(true)}
        onPause={() => setIsPlaying(false)}
      />

      <button
        onClick={toggleMute}
        className="absolute top-4 right-4 z-10 bg-black/50 backdrop-blur-sm p-3 rounded-full text-white hover:bg-black/70 transition-colors"
      >
        {isMuted ? <VolumeX size={24} /> : <Volume2 size={24} />}
      </button>

      <div className="absolute bottom-0 left-0 right-0 p-4 bg-gradient-to-t from-black/80 via-black/40 to-transparent">
        <div className="flex items-end justify-between">
          <div className="flex-1 mr-4">
            <div className="flex items-center gap-2 mb-2">
              <img
                src={video.user?.avatar_url || 'https://via.placeholder.com/40'}
                alt={video.user?.username}
                onClick={goToProfile}
                className="w-10 h-10 rounded-full border-2 border-white cursor-pointer hover:opacity-80 transition-opacity"
              />
              <div className="flex-1">
                <p
                  onClick={goToProfile}
                  className="text-white font-semibold cursor-pointer hover:underline"
                >
                  @{video.user?.username}
                </p>
                <p className="text-white/70 text-sm">{new Date(video.created_at).toLocaleDateString()}</p>
              </div>
              {currentUserId && currentUserId !== video.user?.id && (
                <button
                  onClick={handleFollow}
                  className={`px-4 py-1.5 rounded-full font-medium transition-all text-sm flex items-center gap-1.5 ${
                    isFollowing
                      ? 'bg-slate-700 text-white hover:bg-slate-600'
                      : 'bg-gradient-to-r from-cyan-500 to-orange-500 text-white hover:from-cyan-600 hover:to-orange-600'
                  }`}
                >
                  {isFollowing ? <UserMinus size={14} /> : <UserPlus size={14} />}
                  {isFollowing ? 'Following' : 'Follow'}
                </button>
              )}
            </div>
            <p className="text-white text-sm mb-2">{video.title}</p>
            <div className="flex items-center gap-4 text-white/70 text-xs">
              <span>{video.views_count.toLocaleString()} views</span>
              <span>{video.duration}s</span>
            </div>
          </div>

          <div className="flex flex-col gap-4">
            <button
              onClick={handleLike}
              className="flex flex-col items-center gap-1 text-white hover:scale-110 transition-transform"
            >
              <div className={`p-3 rounded-full ${liked ? 'bg-red-500' : 'bg-black/50'} backdrop-blur-sm`}>
                <Heart size={24} fill={liked ? 'white' : 'none'} />
              </div>
              <span className="text-xs font-semibold">{formatCount(likes)}</span>
            </button>

            <button
              onClick={onOpenComments}
              className="flex flex-col items-center gap-1 text-white hover:scale-110 transition-transform"
            >
              <div className="p-3 rounded-full bg-black/50 backdrop-blur-sm">
                <MessageCircle size={24} />
              </div>
              <span className="text-xs font-semibold">{formatCount(video.comments_count)}</span>
            </button>

            <button
              onClick={handleSave}
              className="flex flex-col items-center gap-1 text-white hover:scale-110 transition-transform"
            >
              <div className={`p-3 rounded-full ${saved ? 'bg-yellow-500' : 'bg-black/50'} backdrop-blur-sm`}>
                <Bookmark size={24} fill={saved ? 'white' : 'none'} />
              </div>
              <span className="text-xs font-semibold">{formatCount(saves)}</span>
            </button>

            <button
              onClick={() => setShowShareMenu(true)}
              className="flex flex-col items-center gap-1 text-white hover:scale-110 transition-transform"
            >
              <div className="p-3 rounded-full bg-black/50 backdrop-blur-sm">
                <Share2 size={24} />
              </div>
              <span className="text-xs font-semibold">{formatCount(shares)}</span>
            </button>
            
            <div className="relative">
              <button
                onClick={() => setShowMenu(!showMenu)}
                className="p-3 rounded-full bg-black/50 backdrop-blur-sm text-white hover:scale-110 transition-transform"
              >
                <MoreVertical size={24} />
              </button>
              {showMenu && (
                <div className="absolute bottom-full right-0 mb-2 bg-slate-800 rounded-lg shadow-xl border border-slate-700 min-w-[150px] overflow-hidden">
                  <button
                    onClick={() => {
                      onReport();
                      setShowMenu(false);
                    }}
                    className="w-full px-4 py-3 text-left text-white hover:bg-slate-700 transition-colors text-sm"
                  >
                    Report
                  </button>
                </div>
              )}
            </div>
          </div> 
        </div>   
      </div>
 {/* Share Menu */}
      {showShareMenu && (
        <ShareMenu
          video={video}
          onClose={() => setShowShareMenu(false)}
          onShared={() => setShares((prev) => prev + 1)}  
        />
      )}
    </div>
  );
 }
       