import { useState } from 'react';
import { X, Shield, Check, AlertCircle } from 'lucide-react';
import { sendVerificationCode, verifyCode } from '../lib/verification';
import { useAuth } from '../lib/newAuthContext';  // ✅ use custom auth

interface VerificationModalProps {
  onClose: () => void;
  onSuccess: () => void;
}

export default function VerificationModal({ onClose, onSuccess }: VerificationModalProps) {
  const { user } = useAuth(); // ✅ logged-in user
  const [step, setStep] = useState<'info' | 'code' | 'success'>('info');
  const [code, setCode] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [verificationCode, setVerificationCode] = useState('');

  const handleSendCode = async () => {
    if (!user) {
      setError('Not authenticated');
      return;
    }

    setLoading(true);
    setError('');

    try {
      const generatedCode = Math.floor(100000 + Math.random() * 900000).toString();
      setVerificationCode(generatedCode);

      const success = await sendVerificationCode(user.id, generatedCode);

      if (success) {
        setStep('code');
      } else {
        setError('Failed to send verification code. Please try again.');
      }
    } catch (err: any) {
      setError(err.message || 'An error occurred');
    } finally {
      setLoading(false);
    }
  };

  const handleVerifyCode = async () => {
    if (!user) {
      setError('Not authenticated');
      return;
    }

    setLoading(true);
    setError('');

    try {
      const result = await verifyCode(user.id, code);

      if (result.success) {
        if (result.vpnDetected) {
          setError('VPN detected. Please disable your VPN and try again.');
        } else {
          setStep('success');
          setTimeout(() => {
            onSuccess();
            onClose();
          }, 2000);
        }
      } else {
        setError(result.message || 'Invalid verification code');
      }
    } catch (err: any) {
      setError(err.message || 'Verification failed');
    } finally {
      setLoading(false);
    }
  };

  // ✅ return moved inside the component
  return (
    <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
      <div className="bg-slate-900 rounded-2xl max-w-md w-full p-6 border border-slate-700 relative">
        <button
          onClick={onClose}
          className="absolute top-4 right-4 text-slate-400 hover:text-white"
        >
          <X size={24} />
        </button>

        {step === 'info' && (
          <div>
            <div className="flex justify-center mb-4">
              <div className="p-4 bg-cyan-500/20 rounded-full">
                <Shield className="text-cyan-400" size={32} />
              </div>
            </div>
            <h2 className="text-white font-semibold text-2xl mb-2 text-center">Verify Your Account</h2>
            <p className="text-slate-400 text-sm mb-6 text-center">
              Account verification is required to enable monetization features and protect against fraud.
            </p>

            <div className="bg-slate-800 rounded-lg p-4 mb-6 space-y-3">
              <div className="flex gap-3">
                <Check className="text-green-400 flex-shrink-0" size={20} />
                <p className="text-slate-300 text-sm">Detect and prevent VPN usage</p>
              </div>
              <div className="flex gap-3">
                <Check className="text-green-400 flex-shrink-0" size={20} />
                <p className="text-slate-300 text-sm">Verify your geographic location</p>
              </div>
              <div className="flex gap-3">
                <Check className="text-green-400 flex-shrink-0" size={20} />
                <p className="text-slate-300 text-sm">Enable earnings and withdrawals</p>
              </div>
            </div>

            <div className="bg-yellow-500/10 border border-yellow-500/30 rounded-lg p-3 mb-6">
              <div className="flex gap-2">
                <AlertCircle className="text-yellow-400 flex-shrink-0" size={18} />
                <p className="text-yellow-300 text-xs">
                  Make sure to disable any VPN or proxy before proceeding. Your location will be detected automatically.
                </p>
              </div>
            </div>

            <button
              onClick={handleSendCode}
              disabled={loading}
              className="w-full py-3 bg-gradient-to-r from-cyan-500 to-blue-500 text-white rounded-lg font-medium hover:from-cyan-600 hover:to-blue-600 transition-all disabled:opacity-50"
            >
              {loading ? 'Processing...' : 'Start Verification'}
            </button>
          </div>
        )}

        {step === 'code' && (
          <div>
            <div className="flex justify-center mb-4">
              <div className="p-4 bg-cyan-500/20 rounded-full">
                <Shield className="text-cyan-400" size={32} />
              </div>
            </div>
            <h2 className="text-white font-semibold text-2xl mb-2 text-center">Enter Verification Code</h2>
            <p className="text-slate-400 text-sm mb-6 text-center">
              We've generated a verification code. Enter it below to complete verification.
            </p>

            <div className="bg-blue-500/10 border border-blue-500/30 rounded-lg p-4 mb-6">
              <p className="text-blue-300 text-center font-mono text-2xl font-bold tracking-wider">
                {verificationCode}
              </p>
              <p className="text-blue-300/70 text-xs text-center mt-2">
                For demo purposes, the code is displayed above
              </p>
            </div>

            <input
              type="text"
              value={code}
              onChange={(e) => setCode(e.target.value)}
              placeholder="Enter 6-digit code"
              maxLength={6}
              className="w-full px-4 py-3 bg-slate-800 border border-slate-700 rounded-lg text-white text-center text-xl tracking-widest mb-4 focus:outline-none focus:ring-2 focus:ring-cyan-500"
            />

            {error && (
              <div className="bg-red-500/10 border border-red-500/30 rounded-lg p-3 mb-4">
                <p className="text-red-300 text-sm text-center">{error}</p>
              </div>
            )}

            <button
              onClick={handleVerifyCode}
              disabled={loading || code.length !== 6}
              className="w-full py-3 bg-gradient-to-r from-cyan-500 to-blue-500 text-white rounded-lg font-medium hover:from-cyan-600 hover:to-blue-600 transition-all disabled:opacity-50"
            >
              {loading ? 'Verifying...' : 'Verify Code'}
            </button>

            <button
              onClick={() => setStep('info')}
              className="w-full py-2 text-slate-400 hover:text-white transition-colors mt-2"
            >
              Back
            </button>
          </div>
        )}

        {step === 'success' && (
          <div className="text-center py-8">
            <div className="flex justify-center mb-4">
              <div className="p-4 bg-green-500/20 rounded-full">
                <Check className="text-green-400" size={48} />
              </div>
            </div>
            <h2 className="text-white font-semibold text-2xl mb-2">Verification Complete!</h2>
            <p className="text-slate-400 text-sm">
              Your account has been successfully verified. You can now access monetization features.
            </p>
          </div>
        )}
      </div>
    </div>
  );
}
