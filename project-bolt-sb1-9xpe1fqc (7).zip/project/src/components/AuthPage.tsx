import { useState, useEffect, useRef } from "react";
import { Video, Camera, Eye, EyeOff, ArrowLeft, Mail, Lock, User as UserIcon, Globe, FileText } from "lucide-react";
import { useAuth } from "../lib/newAuthContext";
import { getCountries } from "../lib/customAuth";

interface AuthPageProps {
  onAuthSuccess: () => void;
}

const FALLBACK_COUNTRIES = [
  "Afghanistan", "Albania", "Algeria", "Argentina", "Australia", "Austria", "Bangladesh",
  "Belgium", "Brazil", "Canada", "Chile", "China", "Colombia", "Czech Republic", "Denmark",
  "Egypt", "Finland", "France", "Germany", "Ghana", "Greece", "Hong Kong", "Hungary",
  "India", "Indonesia", "Iran", "Iraq", "Ireland", "Israel", "Italy", "Japan", "Jordan",
  "Kenya", "Kuwait", "Malaysia", "Mexico", "Morocco", "Netherlands", "New Zealand", "Nigeria",
  "Norway", "Pakistan", "Peru", "Philippines", "Poland", "Portugal", "Qatar", "Romania",
  "Russia", "Saudi Arabia", "Singapore", "South Africa", "South Korea", "Spain", "Sri Lanka",
  "Sweden", "Switzerland", "Taiwan", "Thailand", "Turkey", "UAE", "Uganda", "Ukraine",
  "United Kingdom", "United States", "Venezuela", "Vietnam", "Zimbabwe"
];

export default function AuthPage({ onAuthSuccess }: AuthPageProps) {
  const { login, signup, forgotPassword, resetPassword } = useAuth();

  const [mode, setMode] = useState<'login' | 'signup' | 'forgot' | 'reset'>('login');
  const [email, setEmail] = useState("");
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [bio, setBio] = useState("");
  const [country, setCountry] = useState("");
  const [avatarUrl, setAvatarUrl] = useState("");
  const [avatarPreview, setAvatarPreview] = useState("");
  const [birthday, setBirthday] = useState({ day: "", month: "", year: "" });
  const [countries, setCountries] = useState<string[]>(FALLBACK_COUNTRIES);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [success, setSuccess] = useState("");
  const [resetToken, setResetToken] = useState("");
  const [newPassword, setNewPassword] = useState("");
  const fileInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    getCountries().then(setCountries).catch(() => setCountries(FALLBACK_COUNTRIES));
  }, []);

  const isOldEnough = () => {
    if (!birthday.day || !birthday.month || !birthday.year) return false;
    const birthDate = new Date(`${birthday.year}-${birthday.month}-${birthday.day}`);
    const age = new Date(Date.now() - birthDate.getTime()).getUTCFullYear() - 1970;
    return age >= 13;
  };

  const handleAvatarChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      if (file.size > 5 * 1024 * 1024) {
        setError("Image must be less than 5MB");
        return;
      }
      const reader = new FileReader();
      reader.onloadend = () => {
        const result = reader.result as string;
        setAvatarPreview(result);
        setAvatarUrl(result);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError("");
    setSuccess("");
    setLoading(true);

    try {
      if (mode === 'login') {
        await login(email, password);
        onAuthSuccess();
      } else if (mode === 'signup') {
        if (!isOldEnough()) {
          setError("You must be at least 13 years old to sign up.");
          setLoading(false);
          return;
        }
        if (!country) {
          setError("Please select your country.");
          setLoading(false);
          return;
        }
        if (password !== confirmPassword) {
          setError("Passwords do not match.");
          setLoading(false);
          return;
        }
        if (password.length < 8) {
          setError("Password must be at least 8 characters.");
          setLoading(false);
          return;
        }
        await signup({
          email,
          password,
          username,
          country,
          avatar_url: avatarUrl || undefined,
          bio: bio || undefined,
        });
        onAuthSuccess();
      } else if (mode === 'forgot') {
        const result = await forgotPassword(email);
        setSuccess(result.message);
        if (result.reset_token) {
          setResetToken(result.reset_token);
          setMode('reset');
        }
      } else if (mode === 'reset') {
        if (newPassword.length < 8) {
          setError("Password must be at least 8 characters.");
          setLoading(false);
          return;
        }
        const result = await resetPassword(resetToken, newPassword);
        setSuccess(result.message);
        setTimeout(() => setMode('login'), 2000);
      }
    } catch (err: unknown) {
      const errorMessage = err instanceof Error ? err.message : "Authentication failed";
      setError(errorMessage);
    } finally {
      setLoading(false);
    }
  };

  const renderLogin = () => (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div className="relative">
        <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
        <input
          type="email"
          placeholder="Email address"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          className="w-full pl-11 pr-4 py-3 bg-slate-700/50 border border-slate-600 text-white rounded-xl focus:outline-none focus:border-cyan-500 transition-colors"
          required
        />
      </div>

      <div className="relative">
        <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
        <input
          type={showPassword ? "text" : "password"}
          placeholder="Password"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          className="w-full pl-11 pr-12 py-3 bg-slate-700/50 border border-slate-600 text-white rounded-xl focus:outline-none focus:border-cyan-500 transition-colors"
          required
        />
        <button
          type="button"
          onClick={() => setShowPassword(!showPassword)}
          className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-white"
        >
          {showPassword ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
        </button>
      </div>

      <button
        type="button"
        onClick={() => setMode('forgot')}
        className="text-sm text-cyan-400 hover:text-cyan-300"
      >
        Forgot password?
      </button>

      {error && <p className="text-red-400 text-sm bg-red-500/10 p-3 rounded-lg">{error}</p>}

      <button
        type="submit"
        disabled={loading}
        className="w-full py-3.5 bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-white font-semibold rounded-xl transition-all duration-200 disabled:opacity-50"
      >
        {loading ? "Signing in..." : "Sign In"}
      </button>
    </form>
  );

  const renderSignup = () => (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div className="flex justify-center mb-2">
        <div className="relative">
          <div
            onClick={() => fileInputRef.current?.click()}
            className="w-24 h-24 rounded-full bg-slate-700 border-2 border-dashed border-slate-500 flex items-center justify-center cursor-pointer hover:border-cyan-500 transition-colors overflow-hidden"
          >
            {avatarPreview ? (
              <img src={avatarPreview} alt="Avatar" className="w-full h-full object-cover" />
            ) : (
              <Camera className="w-8 h-8 text-slate-400" />
            )}
          </div>
          <input
            ref={fileInputRef}
            type="file"
            accept="image/*"
            onChange={handleAvatarChange}
            className="hidden"
          />
          <p className="text-xs text-slate-400 text-center mt-2">Add photo (optional)</p>
        </div>
      </div>

      <div className="relative">
        <UserIcon className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
        <input
          type="text"
          placeholder="Username"
          value={username}
          onChange={(e) => setUsername(e.target.value.toLowerCase().replace(/[^a-z0-9_]/g, ''))}
          className="w-full pl-11 pr-4 py-3 bg-slate-700/50 border border-slate-600 text-white rounded-xl focus:outline-none focus:border-cyan-500 transition-colors"
          required
          minLength={3}
          maxLength={30}
        />
      </div>

      <div className="relative">
        <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
        <input
          type="email"
          placeholder="Email address"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          className="w-full pl-11 pr-4 py-3 bg-slate-700/50 border border-slate-600 text-white rounded-xl focus:outline-none focus:border-cyan-500 transition-colors"
          required
        />
      </div>

      <div>
        <p className="text-sm text-slate-400 mb-2">Date of Birth</p>
        <div className="grid grid-cols-3 gap-2">
          <select
            value={birthday.month}
            onChange={(e) => setBirthday({ ...birthday, month: e.target.value })}
            className="p-3 bg-slate-700/50 border border-slate-600 text-white rounded-xl focus:outline-none focus:border-cyan-500"
            required
          >
            <option value="">Month</option>
            {Array.from({ length: 12 }, (_, i) => (
              <option key={i + 1} value={String(i + 1).padStart(2, "0")}>
                {new Date(2000, i).toLocaleString("default", { month: "short" })}
              </option>
            ))}
          </select>
          <select
            value={birthday.day}
            onChange={(e) => setBirthday({ ...birthday, day: e.target.value })}
            className="p-3 bg-slate-700/50 border border-slate-600 text-white rounded-xl focus:outline-none focus:border-cyan-500"
            required
          >
            <option value="">Day</option>
            {Array.from({ length: 31 }, (_, i) => (
              <option key={i + 1} value={String(i + 1).padStart(2, "0")}>
                {i + 1}
              </option>
            ))}
          </select>
          <select
            value={birthday.year}
            onChange={(e) => setBirthday({ ...birthday, year: e.target.value })}
            className="p-3 bg-slate-700/50 border border-slate-600 text-white rounded-xl focus:outline-none focus:border-cyan-500"
            required
          >
            <option value="">Year</option>
            {Array.from({ length: 100 }, (_, i) => new Date().getFullYear() - i).map((y) => (
              <option key={y} value={y}>{y}</option>
            ))}
          </select>
        </div>
      </div>

      <div className="relative">
        <Globe className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
        <select
          value={country}
          onChange={(e) => setCountry(e.target.value)}
          className="w-full pl-11 pr-4 py-3 bg-slate-700/50 border border-slate-600 text-white rounded-xl focus:outline-none focus:border-cyan-500 transition-colors appearance-none"
          required
        >
          <option value="">Select your country</option>
          {countries.map((c) => (
            <option key={c} value={c}>{c}</option>
          ))}
        </select>
      </div>

      <div className="relative">
        <FileText className="absolute left-3 top-3 w-5 h-5 text-slate-400" />
        <textarea
          placeholder="Bio (optional)"
          value={bio}
          onChange={(e) => setBio(e.target.value)}
          className="w-full pl-11 pr-4 py-3 bg-slate-700/50 border border-slate-600 text-white rounded-xl focus:outline-none focus:border-cyan-500 transition-colors resize-none"
          rows={2}
          maxLength={150}
        />
        <span className="absolute right-3 bottom-2 text-xs text-slate-500">{bio.length}/150</span>
      </div>

      <div className="relative">
        <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
        <input
          type={showPassword ? "text" : "password"}
          placeholder="Password (min 8 characters)"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          className="w-full pl-11 pr-12 py-3 bg-slate-700/50 border border-slate-600 text-white rounded-xl focus:outline-none focus:border-cyan-500 transition-colors"
          required
          minLength={8}
        />
        <button
          type="button"
          onClick={() => setShowPassword(!showPassword)}
          className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-white"
        >
          {showPassword ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
        </button>
      </div>

      <div className="relative">
        <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
        <input
          type={showPassword ? "text" : "password"}
          placeholder="Confirm password"
          value={confirmPassword}
          onChange={(e) => setConfirmPassword(e.target.value)}
          className="w-full pl-11 pr-4 py-3 bg-slate-700/50 border border-slate-600 text-white rounded-xl focus:outline-none focus:border-cyan-500 transition-colors"
          required
        />
      </div>

      {error && <p className="text-red-400 text-sm bg-red-500/10 p-3 rounded-lg">{error}</p>}

      <button
        type="submit"
        disabled={loading}
        className="w-full py-3.5 bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-white font-semibold rounded-xl transition-all duration-200 disabled:opacity-50"
      >
        {loading ? "Creating account..." : "Create Account"}
      </button>

      <p className="text-xs text-slate-400 text-center">
        By signing up, you agree to our Terms of Service and Privacy Policy
      </p>
    </form>
  );

  const renderForgotPassword = () => (
    <form onSubmit={handleSubmit} className="space-y-4">
      <button
        type="button"
        onClick={() => setMode('login')}
        className="flex items-center gap-2 text-slate-400 hover:text-white mb-4"
      >
        <ArrowLeft className="w-4 h-4" />
        Back to login
      </button>

      <p className="text-slate-300 text-sm mb-4">
        Enter your email address and we'll send you a link to reset your password.
      </p>

      <div className="relative">
        <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
        <input
          type="email"
          placeholder="Email address"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          className="w-full pl-11 pr-4 py-3 bg-slate-700/50 border border-slate-600 text-white rounded-xl focus:outline-none focus:border-cyan-500 transition-colors"
          required
        />
      </div>

      {error && <p className="text-red-400 text-sm bg-red-500/10 p-3 rounded-lg">{error}</p>}
      {success && <p className="text-green-400 text-sm bg-green-500/10 p-3 rounded-lg">{success}</p>}

      <button
        type="submit"
        disabled={loading}
        className="w-full py-3.5 bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-white font-semibold rounded-xl transition-all duration-200 disabled:opacity-50"
      >
        {loading ? "Sending..." : "Send Reset Link"}
      </button>
    </form>
  );

  const renderResetPassword = () => (
    <form onSubmit={handleSubmit} className="space-y-4">
      <p className="text-slate-300 text-sm mb-4">
        Enter your new password below.
      </p>

      <div className="relative">
        <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
        <input
          type={showPassword ? "text" : "password"}
          placeholder="New password (min 8 characters)"
          value={newPassword}
          onChange={(e) => setNewPassword(e.target.value)}
          className="w-full pl-11 pr-12 py-3 bg-slate-700/50 border border-slate-600 text-white rounded-xl focus:outline-none focus:border-cyan-500 transition-colors"
          required
          minLength={8}
        />
        <button
          type="button"
          onClick={() => setShowPassword(!showPassword)}
          className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-white"
        >
          {showPassword ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
        </button>
      </div>

      {error && <p className="text-red-400 text-sm bg-red-500/10 p-3 rounded-lg">{error}</p>}
      {success && <p className="text-green-400 text-sm bg-green-500/10 p-3 rounded-lg">{success}</p>}

      <button
        type="submit"
        disabled={loading}
        className="w-full py-3.5 bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-white font-semibold rounded-xl transition-all duration-200 disabled:opacity-50"
      >
        {loading ? "Resetting..." : "Reset Password"}
      </button>
    </form>
  );

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900 flex items-center justify-center p-4">
      <div className="bg-slate-800/80 backdrop-blur-xl p-8 rounded-2xl border border-slate-700/50 shadow-2xl max-w-md w-full max-h-[90vh] overflow-y-auto">
        <div className="flex justify-center mb-6">
          <div className="bg-gradient-to-r from-cyan-500 to-blue-600 p-3 rounded-2xl shadow-lg shadow-cyan-500/20">
            <Video className="w-10 h-10 text-white" />
          </div>
        </div>

        <h1 className="text-2xl font-bold text-center text-white mb-2">
          {mode === 'login' && "Welcome Back"}
          {mode === 'signup' && "Create Account"}
          {mode === 'forgot' && "Reset Password"}
          {mode === 'reset' && "New Password"}
        </h1>
        <p className="text-slate-400 text-center mb-6 text-sm">
          {mode === 'login' && "Sign in to continue to Nagris"}
          {mode === 'signup' && "Join the community today"}
          {mode === 'forgot' && "We'll help you get back in"}
          {mode === 'reset' && "Choose a strong password"}
        </p>

        {mode === 'login' && renderLogin()}
        {mode === 'signup' && renderSignup()}
        {mode === 'forgot' && renderForgotPassword()}
        {mode === 'reset' && renderResetPassword()}

        {(mode === 'login' || mode === 'signup') && (
          <div className="mt-6 text-center">
            <button
              onClick={() => {
                setMode(mode === 'login' ? 'signup' : 'login');
                setError("");
                setSuccess("");
              }}
              className="text-cyan-400 hover:text-cyan-300 text-sm font-medium"
            >
              {mode === 'login'
                ? "Don't have an account? Sign up"
                : "Already have an account? Sign in"}
            </button>
          </div>
        )}
      </div>
    </div>
  );
}
