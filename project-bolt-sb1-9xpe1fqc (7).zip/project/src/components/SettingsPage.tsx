import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  Clock, Shield, MessageCircle, Users, Download,
  LogOut, ChevronRight, Trash2, Bookmark, UserCircle2, ArrowLeft, ShoppingBag, BadgeCheck,
  Lock, X, Mail, FileText, AlertTriangle, HelpCircle, Wallet
} from 'lucide-react';
import type { User } from '../lib/types';
import { getCurrentUser, logout } from '../lib/customAuth';
import { useAuth } from '../lib/newAuthContext';
import { api } from '../lib/api';
import { getUserVerification } from '../lib/verification';
import VerificationModal from './VerificationModal';

interface UserSettings {
  is_private: boolean;
  who_can_comment: string;
  who_can_message: string;
  who_can_mention: string;
  allow_downloads: boolean;
  privacy_settings: {
    profile_visibility: string;
    who_can_comment: string;
    who_can_duet: string;
    who_can_message: string;
  };
  notification_settings: {
    likes: boolean;
    comments: boolean;
    new_followers: boolean;
    mentions: boolean;
    live_notifications: boolean;
  };
  theme_preference: string;
  show_activity_status: boolean;
  allow_mentions: boolean;
  allow_duets: boolean;
}

export default function EnhancedSettingsPage() {
  const navigate = useNavigate();
  const { changePassword } = useAuth();
  const [settings, setSettings] = useState<UserSettings | null>(null);
  const [loading, setLoading] = useState(true);
  const [user, setUser] = useState<User | null>(null);
  const [verification, setVerification] = useState<any>(null);
  const [showVerificationModal, setShowVerificationModal] = useState(false);
  const [showPasswordModal, setShowPasswordModal] = useState(false);
  const [showDeleteModal, setShowDeleteModal] = useState(false);
  const [currentPassword, setCurrentPassword] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [confirmNewPassword, setConfirmNewPassword] = useState('');
  const [deletePassword, setDeletePassword] = useState('');
  const [passwordError, setPasswordError] = useState('');
  const [passwordSuccess, setPasswordSuccess] = useState('');
  const [deleteError, setDeleteError] = useState('');
  const [passwordLoading, setPasswordLoading] = useState(false);
  const [deleteLoading, setDeleteLoading] = useState(false);

  useEffect(() => {
    loadUser();
    loadSettings();
    loadVerification();
  }, []);

  const loadUser = async () => {
    try {
      const currentUser = await getCurrentUser();
      if (!currentUser) return;

      const profile = await api.getUserProfile(currentUser.id);
      setUser(profile);
    } catch (err) {
      console.error('Failed to load user:', err);
    }
  };

  const loadVerification = async () => {
    try {
      const currentUser = await getCurrentUser();
      if (!currentUser) return;

      const verificationData = await getUserVerification(currentUser.id);
      setVerification(verificationData);
    } catch (err) {
      console.error('Failed to load verification:', err);
    }
  };

  const loadSettings = async () => {
    try {
      const currentUser = await getCurrentUser();
      if (!currentUser) return;

      const userSettings = await api.getUserSettings(currentUser.id);
      setSettings(userSettings);
    } catch (err) {
      console.error('Failed to load settings:', err);
    } finally {
      setLoading(false);
    }
  };

  const updateSettings = async (updates: Partial<UserSettings>) => {
    try {
      const currentUser = await getCurrentUser();
      if (!currentUser) return;

      const newSettings = { ...settings, ...updates };
      setSettings(newSettings);

      await api.updateUserSettings(currentUser.id, newSettings);
    } catch (err) {
      console.error('Failed to update settings:', err);
    }
  };

  const handleLogout = async () => {
    if (confirm('Are you sure you want to log out?')) {
      await logout();
    }
  };

  const handleSwitchAccount = () => {
    if (confirm('Switch to another account? You will be logged out.')) {
      handleLogout();
    }
  };

  const handleClearHistory = async () => {
    if (confirm('Are you sure you want to clear your watch history? This cannot be undone.')) {
      try {
        const currentUser = await getCurrentUser();
        if (!currentUser) return;

        await api.clearWatchHistory(currentUser.id);
        alert('Watch history cleared successfully');
      } catch (err) {
        console.error('Failed to clear history:', err);
        alert('Failed to clear watch history');
      }
    }
  };

  const handleChangePassword = async (e: React.FormEvent) => {
    e.preventDefault();
    setPasswordError('');
    setPasswordSuccess('');

    if (newPassword.length < 8) {
      setPasswordError('New password must be at least 8 characters');
      return;
    }

    if (newPassword !== confirmNewPassword) {
      setPasswordError('New passwords do not match');
      return;
    }

    setPasswordLoading(true);
    try {
      await changePassword(currentPassword, newPassword);
      setPasswordSuccess('Password changed successfully');
      setCurrentPassword('');
      setNewPassword('');
      setConfirmNewPassword('');
      setTimeout(() => {
        setShowPasswordModal(false);
        setPasswordSuccess('');
      }, 2000);
    } catch (err: unknown) {
      const errorMessage = err instanceof Error ? err.message : 'Failed to change password';
      setPasswordError(errorMessage);
    } finally {
      setPasswordLoading(false);
    }
  };

  const handleDeleteAccount = async (e: React.FormEvent) => {
    e.preventDefault();
    setDeleteError('');

    if (!deletePassword) {
      setDeleteError('Password is required');
      return;
    }

    if (!confirm('This will permanently delete your account and all data. This action cannot be undone. Are you absolutely sure?')) {
      return;
    }

    setDeleteLoading(true);
    try {
      await api.deleteAccount(deletePassword);
      alert('Account deleted successfully. You will now be logged out.');
      await logout();
    } catch (err: unknown) {
      const errorMessage = err instanceof Error ? err.message : 'Failed to delete account';
      setDeleteError(errorMessage);
    } finally {
      setDeleteLoading(false);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-900 via-blue-900 to-slate-900 flex items-center justify-center">
        <p className="text-white">Loading settings...</p>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-blue-900 to-slate-900 pb-20">
      <div className="max-w-2xl mx-auto">
        <div className="sticky top-0 bg-slate-900/80 backdrop-blur-lg border-b border-slate-700 px-4 py-4 flex items-center gap-4 z-10">
          <button
            onClick={() => navigate('/profile')}
            className="text-white hover:bg-slate-700/50 p-2 rounded-lg transition-colors"
          >
            <ArrowLeft size={24} />
          </button>
          <h1 className="text-xl font-bold text-white">Settings and privacy</h1>
        </div>

        <div className="px-4 py-6 space-y-2">
          <div className="bg-slate-800/50 backdrop-blur-lg rounded-2xl border border-slate-700 overflow-hidden">
            <button
              onClick={() => navigate('/profile')}
              className="w-full flex items-center gap-4 p-4 hover:bg-slate-700/30 transition-colors"
            >
              <img
                src={user?.avatar_url || 'https://via.placeholder.com/48'}
                alt={user?.username}
                className="w-12 h-12 rounded-full border-2 border-cyan-500"
              />
              <div className="flex-1 text-left">
                <p className="text-white font-medium">{user?.username || 'User'}</p>
                <p className="text-slate-400 text-sm">View and edit profile</p>
              </div>
              <ChevronRight size={20} className="text-slate-400" />
            </button>
          </div>

          <div className="text-slate-400 text-sm font-medium px-2 mt-6 mb-2">Account</div>

          <div className="bg-slate-800/50 backdrop-blur-lg rounded-2xl border border-slate-700 overflow-hidden">
            <div className="p-4 border-b border-slate-700">
              <div className="flex items-center justify-between mb-2">
                <span className="text-white font-medium">Email</span>
                <span className="text-slate-400 text-sm">{user?.email}</span>
              </div>
            </div>

            <button
              onClick={() => setShowPasswordModal(true)}
              className="w-full flex items-center justify-between p-4 hover:bg-slate-700/30 transition-colors border-b border-slate-700"
            >
              <div className="flex items-center gap-3">
                <Lock size={20} className="text-slate-400" />
                <span className="text-white font-medium">Change password</span>
              </div>
              <ChevronRight size={20} className="text-slate-400" />
            </button>

            <button
              onClick={handleSwitchAccount}
              className="w-full flex items-center justify-between p-4 hover:bg-slate-700/30 transition-colors"
            >
              <div className="flex items-center gap-3">
                <UserCircle2 size={20} className="text-slate-400" />
                <span className="text-white font-medium">Switch account</span>
              </div>
              <ChevronRight size={20} className="text-slate-400" />
            </button>
          </div>

          <div className="text-slate-400 text-sm font-medium px-2 mt-6 mb-2">Privacy & Safety</div>

          <div className="bg-slate-800/50 backdrop-blur-lg rounded-2xl border border-slate-700 overflow-hidden">
            <div className="p-4 space-y-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <Lock size={18} className="text-slate-400" />
                  <span className="text-white">Private Account</span>
                </div>
                <label className="relative inline-flex items-center cursor-pointer">
                  <input
                    type="checkbox"
                    checked={settings?.is_private || false}
                    onChange={(e) => updateSettings({ is_private: e.target.checked })}
                    className="sr-only peer"
                  />
                  <div className="w-11 h-6 bg-slate-600 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-gradient-to-r peer-checked:from-cyan-500 peer-checked:to-blue-600"></div>
                </label>
              </div>

              <div>
                <label className="flex items-center gap-3 mb-2">
                  <MessageCircle size={18} className="text-slate-400" />
                  <span className="text-white">Who can comment</span>
                </label>
                <select
                  value={settings?.who_can_comment || 'Everyone'}
                  onChange={(e) => updateSettings({ who_can_comment: e.target.value })}
                  className="w-full px-4 py-2 bg-slate-700/50 border border-slate-600 text-white rounded-lg focus:outline-none focus:border-cyan-500"
                >
                  <option value="Everyone">Everyone</option>
                  <option value="Followers">Followers only</option>
                  <option value="NoOne">No one</option>
                </select>
              </div>

              <div>
                <label className="flex items-center gap-3 mb-2">
                  <Mail size={18} className="text-slate-400" />
                  <span className="text-white">Who can message me</span>
                </label>
                <select
                  value={settings?.who_can_message || 'Everyone'}
                  onChange={(e) => updateSettings({ who_can_message: e.target.value })}
                  className="w-full px-4 py-2 bg-slate-700/50 border border-slate-600 text-white rounded-lg focus:outline-none focus:border-cyan-500"
                >
                  <option value="Everyone">Everyone</option>
                  <option value="Followers">Followers only</option>
                  <option value="NoOne">No one</option>
                </select>
              </div>

              <div>
                <label className="flex items-center gap-3 mb-2">
                  <Users size={18} className="text-slate-400" />
                  <span className="text-white">Who can mention me</span>
                </label>
                <select
                  value={settings?.who_can_mention || 'Everyone'}
                  onChange={(e) => updateSettings({ who_can_mention: e.target.value })}
                  className="w-full px-4 py-2 bg-slate-700/50 border border-slate-600 text-white rounded-lg focus:outline-none focus:border-cyan-500"
                >
                  <option value="Everyone">Everyone</option>
                  <option value="Followers">Followers only</option>
                  <option value="NoOne">No one</option>
                </select>
              </div>

              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <Download size={18} className="text-slate-400" />
                  <span className="text-white">Allow video downloads</span>
                </div>
                <label className="relative inline-flex items-center cursor-pointer">
                  <input
                    type="checkbox"
                    checked={settings?.allow_downloads || false}
                    onChange={(e) => updateSettings({ allow_downloads: e.target.checked })}
                    className="sr-only peer"
                  />
                  <div className="w-11 h-6 bg-slate-600 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-gradient-to-r peer-checked:from-cyan-500 peer-checked:to-blue-600"></div>
                </label>
              </div>
            </div>
          </div>

          <div className="text-slate-400 text-sm font-medium px-2 mt-6 mb-2">Content & Activity</div>

          <div className="bg-slate-800/50 backdrop-blur-lg rounded-2xl border border-slate-700 overflow-hidden">
            <button
              onClick={() => navigate('/watch-history')}
              className="w-full flex items-center justify-between p-4 hover:bg-slate-700/30 transition-colors border-b border-slate-700"
            >
              <div className="flex items-center gap-3">
                <Clock size={20} className="text-slate-400" />
                <span className="text-white font-medium">Watch history</span>
              </div>
              <ChevronRight size={20} className="text-slate-400" />
            </button>

            <button
              onClick={() => navigate('/saved-videos')}
              className="w-full flex items-center justify-between p-4 hover:bg-slate-700/30 transition-colors border-b border-slate-700"
            >
              <div className="flex items-center gap-3">
                <Bookmark size={20} className="text-slate-400" />
                <span className="text-white font-medium">Saved videos</span>
              </div>
              <ChevronRight size={20} className="text-slate-400" />
            </button>

            <button
              onClick={handleClearHistory}
              className="w-full flex items-center justify-between p-4 hover:bg-slate-700/30 transition-colors"
            >
              <div className="flex items-center gap-3">
                <Trash2 size={20} className="text-red-400" />
                <span className="text-white font-medium">Clear watch history</span>
              </div>
            </button>
          </div>

          <div className="text-slate-400 text-sm font-medium px-2 mt-6 mb-2">Monetization</div>

          <div className="bg-slate-800/50 backdrop-blur-lg rounded-2xl border border-slate-700 overflow-hidden">
            <button
              onClick={() => navigate('/wallet')}
              className="w-full flex items-center justify-between p-4 hover:bg-slate-700/30 transition-colors border-b border-slate-700"
            >
              <div className="flex items-center gap-3">
                <Wallet size={20} className="text-slate-400" />
                <span className="text-white font-medium">Wallet</span>
              </div>
              <ChevronRight size={20} className="text-slate-400" />
            </button>

            <button
              onClick={() => setShowVerificationModal(true)}
              className="w-full flex items-center justify-between p-4 hover:bg-slate-700/30 transition-colors border-b border-slate-700"
            >
              <div className="flex items-center gap-3">
                <BadgeCheck size={20} className={verification?.is_verified ? "text-green-400" : "text-slate-400"} />
                <div className="text-left">
                  <span className="text-white font-medium block">Account Verification</span>
                  {verification?.is_verified ? (
                    <span className="text-green-400 text-xs">Verified</span>
                  ) : (
                    <span className="text-yellow-400 text-xs">Required for monetization</span>
                  )}
                </div>
              </div>
              <ChevronRight size={20} className="text-slate-400" />
            </button>

            <button
              onClick={() => navigate('/shop')}
              className="w-full flex items-center justify-between p-4 hover:bg-slate-700/30 transition-colors"
            >
              <div className="flex items-center gap-3">
                <ShoppingBag size={20} className="text-slate-400" />
                <span className="text-white font-medium">Shop</span>
              </div>
              <ChevronRight size={20} className="text-slate-400" />
            </button>
          </div>

          <div className="text-slate-400 text-sm font-medium px-2 mt-6 mb-2">Legal & Support</div>

          <div className="bg-slate-800/50 backdrop-blur-lg rounded-2xl border border-slate-700 overflow-hidden">
            <button
              onClick={() => navigate('/terms-of-service')}
              className="w-full flex items-center justify-between p-4 hover:bg-slate-700/30 transition-colors border-b border-slate-700"
            >
              <div className="flex items-center gap-3">
                <FileText size={20} className="text-slate-400" />
                <span className="text-white font-medium">Terms of Service</span>
              </div>
              <ChevronRight size={20} className="text-slate-400" />
            </button>

            <button
              onClick={() => navigate('/privacy-policy')}
              className="w-full flex items-center justify-between p-4 hover:bg-slate-700/30 transition-colors border-b border-slate-700"
            >
              <div className="flex items-center gap-3">
                <Shield size={20} className="text-slate-400" />
                <span className="text-white font-medium">Privacy Policy</span>
              </div>
              <ChevronRight size={20} className="text-slate-400" />
            </button>

            <button
              onClick={() => navigate('/community-guidelines')}
              className="w-full flex items-center justify-between p-4 hover:bg-slate-700/30 transition-colors border-b border-slate-700"
            >
              <div className="flex items-center gap-3">
                <Users size={20} className="text-slate-400" />
                <span className="text-white font-medium">Community Guidelines</span>
              </div>
              <ChevronRight size={20} className="text-slate-400" />
            </button>

            <button
              onClick={() => window.location.href = 'mailto:support@nagris.com'}
              className="w-full flex items-center justify-between p-4 hover:bg-slate-700/30 transition-colors"
            >
              <div className="flex items-center gap-3">
                <HelpCircle size={20} className="text-slate-400" />
                <span className="text-white font-medium">Contact Support</span>
              </div>
              <ChevronRight size={20} className="text-slate-400" />
            </button>
          </div>

          <div className="bg-slate-800/50 backdrop-blur-lg rounded-2xl border border-slate-700 overflow-hidden mt-6">
            <button
              onClick={handleLogout}
              className="w-full flex items-center justify-between p-4 hover:bg-red-500/10 transition-colors group border-b border-slate-700"
            >
              <div className="flex items-center gap-3">
                <LogOut size={20} className="text-red-400" />
                <span className="text-red-400 font-medium">Log out</span>
              </div>
            </button>

            <button
              onClick={() => setShowDeleteModal(true)}
              className="w-full flex items-center justify-between p-4 hover:bg-red-500/10 transition-colors group"
            >
              <div className="flex items-center gap-3">
                <AlertTriangle size={20} className="text-red-400" />
                <span className="text-red-400 font-medium">Delete account</span>
              </div>
            </button>
          </div>

          <p className="text-center text-slate-500 text-xs mt-6">
            Version 1.0.0
          </p>
        </div>
      </div>

      {showVerificationModal && (
        <VerificationModal
          onClose={() => setShowVerificationModal(false)}
          onSuccess={() => {
            loadVerification();
          }}
        />
      )}

      {showPasswordModal && (
        <div className="fixed inset-0 bg-black/70 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-slate-800 rounded-2xl border border-slate-700 w-full max-w-md">
            <div className="flex items-center justify-between p-4 border-b border-slate-700">
              <h2 className="text-lg font-semibold text-white">Change Password</h2>
              <button
                onClick={() => {
                  setShowPasswordModal(false);
                  setPasswordError('');
                  setPasswordSuccess('');
                  setCurrentPassword('');
                  setNewPassword('');
                  setConfirmNewPassword('');
                }}
                className="text-slate-400 hover:text-white"
              >
                <X size={24} />
              </button>
            </div>

            <form onSubmit={handleChangePassword} className="p-4 space-y-4">
              <div>
                <label className="block text-sm text-slate-400 mb-2">Current Password</label>
                <input
                  type="password"
                  value={currentPassword}
                  onChange={(e) => setCurrentPassword(e.target.value)}
                  className="w-full px-4 py-3 bg-slate-700/50 border border-slate-600 text-white rounded-xl focus:outline-none focus:border-cyan-500"
                  required
                />
              </div>

              <div>
                <label className="block text-sm text-slate-400 mb-2">New Password</label>
                <input
                  type="password"
                  value={newPassword}
                  onChange={(e) => setNewPassword(e.target.value)}
                  className="w-full px-4 py-3 bg-slate-700/50 border border-slate-600 text-white rounded-xl focus:outline-none focus:border-cyan-500"
                  required
                  minLength={8}
                />
              </div>

              <div>
                <label className="block text-sm text-slate-400 mb-2">Confirm New Password</label>
                <input
                  type="password"
                  value={confirmNewPassword}
                  onChange={(e) => setConfirmNewPassword(e.target.value)}
                  className="w-full px-4 py-3 bg-slate-700/50 border border-slate-600 text-white rounded-xl focus:outline-none focus:border-cyan-500"
                  required
                />
              </div>

              {passwordError && (
                <p className="text-red-400 text-sm bg-red-500/10 p-3 rounded-lg">{passwordError}</p>
              )}

              {passwordSuccess && (
                <p className="text-green-400 text-sm bg-green-500/10 p-3 rounded-lg">{passwordSuccess}</p>
              )}

              <button
                type="submit"
                disabled={passwordLoading}
                className="w-full py-3 bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-white font-semibold rounded-xl transition-all disabled:opacity-50"
              >
                {passwordLoading ? 'Changing...' : 'Change Password'}
              </button>
            </form>
          </div>
        </div>
      )}

      {showDeleteModal && (
        <div className="fixed inset-0 bg-black/70 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-slate-800 rounded-2xl border border-red-500/50 w-full max-w-md">
            <div className="flex items-center justify-between p-4 border-b border-slate-700">
              <h2 className="text-lg font-semibold text-red-400 flex items-center gap-2">
                <AlertTriangle size={20} />
                Delete Account
              </h2>
              <button
                onClick={() => {
                  setShowDeleteModal(false);
                  setDeleteError('');
                  setDeletePassword('');
                }}
                className="text-slate-400 hover:text-white"
              >
                <X size={24} />
              </button>
            </div>

            <form onSubmit={handleDeleteAccount} className="p-4 space-y-4">
              <div className="bg-red-500/10 border border-red-500/30 rounded-lg p-4">
                <p className="text-red-400 text-sm font-medium mb-2">Warning: This action is permanent</p>
                <ul className="text-red-300 text-xs space-y-1 list-disc list-inside">
                  <li>All your videos will be deleted</li>
                  <li>Your profile will be permanently removed</li>
                  <li>Your followers and following will be cleared</li>
                  <li>This action cannot be undone</li>
                </ul>
              </div>

              <div>
                <label className="block text-sm text-slate-400 mb-2">Enter your password to confirm</label>
                <input
                  type="password"
                  value={deletePassword}
                  onChange={(e) => setDeletePassword(e.target.value)}
                  className="w-full px-4 py-3 bg-slate-700/50 border border-slate-600 text-white rounded-xl focus:outline-none focus:border-red-500"
                  required
                  placeholder="Your password"
                />
              </div>

              {deleteError && (
                <p className="text-red-400 text-sm bg-red-500/10 p-3 rounded-lg">{deleteError}</p>
              )}

              <div className="flex gap-3">
                <button
                  type="button"
                  onClick={() => {
                    setShowDeleteModal(false);
                    setDeleteError('');
                    setDeletePassword('');
                  }}
                  className="flex-1 py-3 bg-slate-700 hover:bg-slate-600 text-white font-semibold rounded-xl transition-all"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={deleteLoading}
                  className="flex-1 py-3 bg-red-600 hover:bg-red-500 text-white font-semibold rounded-xl transition-all disabled:opacity-50"
                >
                  {deleteLoading ? 'Deleting...' : 'Delete Forever'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
