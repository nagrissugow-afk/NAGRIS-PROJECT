import { useState, useRef, useEffect } from 'react';
import { X, Circle, Square, RotateCw, Check, Video, Image as ImageIcon } from 'lucide-react';

interface CameraRecorderProps {
  onRecordingComplete: (blob: Blob) => void;
  onClose: () => void;
}

export default function CameraRecorder({ onRecordingComplete, onClose }: CameraRecorderProps) {
  const videoRef = useRef<HTMLVideoElement>(null);
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const chunksRef = useRef<Blob[]>([]);
  const [isRecording, setIsRecording] = useState(false);
  const [isPaused, setIsPaused] = useState(false);
  const [recordingTime, setRecordingTime] = useState(0);
  const [facingMode, setFacingMode] = useState<'user' | 'environment'>('user');
  const [stream, setStream] = useState<MediaStream | null>(null);
  const [error, setError] = useState('');
  const [countdown, setCountdown] = useState<number | null>(null);
  const [recordedBlob, setRecordedBlob] = useState<Blob | null>(null);
  const timerRef = useRef<NodeJS.Timeout | null>(null);

  useEffect(() => {
    startCamera();
    return () => {
      stopCamera();
    };
  }, [facingMode]);

  useEffect(() => {
    if (isRecording && !isPaused) {
      timerRef.current = setInterval(() => {
        setRecordingTime(prev => {
          if (prev >= 30) {
            stopRecording();
            return 30;
          }
          return prev + 1;
        });
      }, 1000);
    } else {
      if (timerRef.current) {
        clearInterval(timerRef.current);
      }
    }

    return () => {
      if (timerRef.current) {
        clearInterval(timerRef.current);
      }
    };
  }, [isRecording, isPaused]);

  const startCamera = async () => {
    try {
      if (stream) {
        stream.getTracks().forEach(track => track.stop());
      }

      const mediaStream = await navigator.mediaDevices.getUserMedia({
        video: {
          facingMode,
          width: { ideal: 1080 },
          height: { ideal: 1920 },
          aspectRatio: { ideal: 9 / 16 },
        },
        audio: {
          echoCancellation: true,
          noiseSuppression: true,
          autoGainControl: true,
        },
      });

      if (videoRef.current) {
        videoRef.current.srcObject = mediaStream;
      }

      setStream(mediaStream);
      setError('');
    } catch (err) {
      console.error('Failed to access camera:', err);
      setError('Failed to access camera. Please grant camera and microphone permissions.');
    }
  };

  const stopCamera = () => {
    if (stream) {
      stream.getTracks().forEach(track => track.stop());
    }
  };

  const startCountdown = () => {
    setCountdown(3);
    const countdownInterval = setInterval(() => {
      setCountdown(prev => {
        if (prev === 1) {
          clearInterval(countdownInterval);
          startRecording();
          return null;
        }
        return prev! - 1;
      });
    }, 1000);
  };

  const startRecording = () => {
    if (!stream) return;

    const audioTracks = stream.getAudioTracks();
    const videoTracks = stream.getVideoTracks();

    console.log('Recording with:', {
      audio: audioTracks.length > 0,
      video: videoTracks.length > 0,
    });

    chunksRef.current = [];

    let options = { mimeType: 'video/webm;codecs=vp8,opus' };
    if (!MediaRecorder.isTypeSupported(options.mimeType)) {
      options = { mimeType: 'video/webm' };
      if (!MediaRecorder.isTypeSupported(options.mimeType)) {
        options = { mimeType: '' };
      }
    }

    const mediaRecorder = new MediaRecorder(stream, options);

    mediaRecorder.ondataavailable = (event) => {
      if (event.data.size > 0) {
        chunksRef.current.push(event.data);
      }
    };

    mediaRecorder.onstop = () => {
      const blob = new Blob(chunksRef.current, { type: 'video/webm' });
      setRecordedBlob(blob);
    };

    mediaRecorder.start(1000);
    mediaRecorderRef.current = mediaRecorder;
    setIsRecording(true);
    setRecordingTime(0);
  };

  const stopRecording = () => {
    if (mediaRecorderRef.current && isRecording) {
      mediaRecorderRef.current.stop();
      setIsRecording(false);
      setIsPaused(false);
    }
  };

  const togglePause = () => {
    if (!mediaRecorderRef.current) return;

    if (isPaused) {
      mediaRecorderRef.current.resume();
      setIsPaused(false);
    } else {
      mediaRecorderRef.current.pause();
      setIsPaused(true);
    }
  };

  const switchCamera = () => {
    setFacingMode(prev => prev === 'user' ? 'environment' : 'user');
  };

  const handleRetake = () => {
    setRecordedBlob(null);
    setRecordingTime(0);
    startCamera();
  };

  const handleUseVideo = () => {
    if (recordedBlob) {
      onRecordingComplete(recordedBlob);
    }
  };

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  if (recordedBlob) {
    return (
      <div className="fixed inset-0 bg-black z-50 flex flex-col">
        <div className="flex items-center justify-between p-4">
          <button
            onClick={handleRetake}
            className="text-white font-medium"
          >
            Retake
          </button>
          <h2 className="text-white font-bold">Preview</h2>
          <button
            onClick={handleUseVideo}
            className="text-cyan-400 font-medium"
          >
            Use Video
          </button>
        </div>

        <div className="flex-1 flex items-center justify-center bg-black">
          <div className="relative w-full max-w-[calc(100vh*9/16)] h-full">
            <video
              src={URL.createObjectURL(recordedBlob)}
              className="w-full h-full object-contain"
              controls
              autoPlay
              loop
            />
          </div>
        </div>

        <div className="p-4">
          <button
            onClick={handleUseVideo}
            className="w-full py-4 bg-gradient-to-r from-cyan-500 to-orange-500 text-white font-semibold rounded-lg hover:from-cyan-600 hover:to-orange-600 transition-all flex items-center justify-center gap-2"
          >
            <Check size={20} />
            Continue
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="fixed inset-0 bg-black z-50 flex flex-col">
      <div className="flex items-center justify-between p-4">
        <button
          onClick={onClose}
          className="text-white p-2 hover:bg-white/10 rounded-full transition-colors"
        >
          <X size={24} />
        </button>
        <h2 className="text-white font-bold">Record Video</h2>
        <button
          onClick={switchCamera}
          className="text-white p-2 hover:bg-white/10 rounded-full transition-colors"
        >
          <RotateCw size={24} />
        </button>
      </div>

      {error && (
        <div className="mx-4 mb-4 p-4 bg-red-500/20 border border-red-500 rounded-lg text-red-400 text-center">
          {error}
        </div>
      )}

      <div className="flex-1 relative flex items-center justify-center bg-black">
        <div className="relative w-full max-w-[calc(100vh*9/16)] h-full">
          <video
            ref={videoRef}
            autoPlay
            playsInline
            muted
            className="w-full h-full object-cover"
          />

          {countdown !== null && (
            <div className="absolute inset-0 flex items-center justify-center bg-black/50">
              <div className="text-white text-9xl font-bold animate-pulse">
                {countdown}
              </div>
            </div>
          )}

          <div className="absolute top-4 left-1/2 transform -translate-x-1/2 bg-black/50 px-4 py-2 rounded-full">
            <span className="text-white font-mono text-lg">
              {formatTime(recordingTime)} / 0:30
            </span>
          </div>

          {isRecording && (
            <div className="absolute top-4 right-4 flex items-center gap-2 bg-red-500 px-3 py-1 rounded-full">
              <div className="w-2 h-2 bg-white rounded-full animate-pulse" />
              <span className="text-white text-sm font-medium">REC</span>
            </div>
          )}
        </div>
      </div>

      <div className="p-8 flex items-center justify-center gap-8">
        {!isRecording ? (
          <button
            onClick={startCountdown}
            disabled={!!error}
            className="w-20 h-20 bg-red-500 rounded-full flex items-center justify-center hover:bg-red-600 transition-colors disabled:opacity-50 disabled:cursor-not-allowed border-4 border-white shadow-2xl"
          >
            <Circle size={40} className="text-white fill-current" />
          </button>
        ) : (
          <>
            <button
              onClick={togglePause}
              className="w-16 h-16 bg-white rounded-full flex items-center justify-center hover:bg-gray-200 transition-colors"
            >
              {isPaused ? (
                <Circle size={24} className="text-black fill-current" />
              ) : (
                <div className="flex gap-1">
                  <div className="w-2 h-6 bg-black" />
                  <div className="w-2 h-6 bg-black" />
                </div>
              )}
            </button>

            <button
              onClick={stopRecording}
              className="w-20 h-20 bg-red-500 rounded-full flex items-center justify-center hover:bg-red-600 transition-colors border-4 border-white shadow-2xl"
            >
              <Square size={32} className="text-white fill-current" />
            </button>
          </>
        )}
      </div>

      <div className="p-4 text-center text-slate-400 text-sm">
        {!isRecording ? 'Tap to start recording' : isPaused ? 'Recording paused' : 'Recording...'}
      </div>
    </div>
  );
}
