import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { ArrowLeft, Play, Heart, MessageCircle, Bookmark } from 'lucide-react';
import { api } from '../lib/api';
import type { Video } from '../lib/types';

export default function SavedVideosPage() {
  const navigate = useNavigate();
  const [videos, setVideos] = useState<Video[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadSavedVideos();
  }, []);

  const loadSavedVideos = async () => {
    try {
      const savedVideos = await api.getSavedVideos();
      setVideos(savedVideos);
    } catch (err) {
      console.error('Failed to load saved videos:', err);
    } finally {
      setLoading(false);
    }
  };

  const handleVideoClick = (videoId: string) => {
    navigate(`/?video=${videoId}`);
  };

  const handleUnsave = async (videoId: string, e: React.MouseEvent) => {
    e.stopPropagation();

    if (confirm('Remove this video from your saved collection?')) {
      try {
        await api.unsaveVideo(videoId);
        setVideos(videos.filter(v => v.id !== videoId));
      } catch (err) {
        console.error('Failed to unsave video:', err);
      }
    }
  };

  const formatCount = (count: number): string => {
    if (count >= 1000000) {
      return (count / 1000000).toFixed(1) + 'M';
    } else if (count >= 1000) {
      return (count / 1000).toFixed(1) + 'K';
    }
    return count.toString();
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-900 via-blue-900 to-slate-900 flex items-center justify-center">
        <p className="text-white">Loading saved videos...</p>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-blue-900 to-slate-900 pb-20">
      <div className="max-w-6xl mx-auto">
        <div className="sticky top-0 bg-slate-900/80 backdrop-blur-lg border-b border-slate-700 px-4 py-4 flex items-center gap-4 z-10">
          <button
            onClick={() => navigate('/settings')}
            className="text-white hover:bg-slate-700/50 p-2 rounded-lg transition-colors"
          >
            <ArrowLeft size={24} />
          </button>
          <div>
            <h1 className="text-xl font-bold text-white">Saved Videos</h1>
            <p className="text-slate-400 text-sm">{videos.length} video{videos.length !== 1 ? 's' : ''}</p>
          </div>
        </div>

        {videos.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-20 px-4">
            <div className="w-20 h-20 bg-slate-800 rounded-full flex items-center justify-center mb-4">
              <Bookmark size={40} className="text-slate-600" />
            </div>
            <h2 className="text-white text-xl font-semibold mb-2">No saved videos yet</h2>
            <p className="text-slate-400 text-center max-w-md">
              Save videos you love to watch them later. Tap the bookmark icon on any video to save it.
            </p>
          </div>
        ) : (
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4 p-4">
            {videos.map((video) => (
              <div
                key={video.id}
                onClick={() => handleVideoClick(video.id)}
                className="relative aspect-[9/16] bg-slate-800 rounded-xl overflow-hidden cursor-pointer group hover:ring-2 hover:ring-cyan-500 transition-all"
              >
                {video.thumbnail_url ? (
                  <img
                    src={video.thumbnail_url}
                    alt={video.title}
                    className="w-full h-full object-cover"
                  />
                ) : (
                  <div className="w-full h-full flex items-center justify-center bg-slate-700">
                    <Play size={48} className="text-slate-500" />
                  </div>
                )}

                <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent opacity-100 group-hover:opacity-100 transition-opacity">
                  <div className="absolute top-2 right-2">
                    <button
                      onClick={(e) => handleUnsave(video.id, e)}
                      className="p-2 bg-yellow-500 rounded-full hover:bg-yellow-600 transition-colors"
                      title="Remove from saved"
                    >
                      <Bookmark size={18} fill="white" className="text-white" />
                    </button>
                  </div>

                  <div className="absolute bottom-0 left-0 right-0 p-3">
                    <div className="flex items-center gap-2 mb-2">
                      <img
                        src={video.user?.avatar_url || 'https://via.placeholder.com/24'}
                        alt={video.user?.username}
                        className="w-6 h-6 rounded-full border border-white/50"
                      />
                      <span className="text-white text-xs font-medium truncate">
                        @{video.user?.username}
                      </span>
                    </div>

                    <p className="text-white text-sm font-medium mb-2 line-clamp-2">
                      {video.title}
                    </p>

                    <div className="flex items-center gap-4 text-white text-xs">
                      <div className="flex items-center gap-1">
                        <Heart size={14} />
                        <span>{formatCount(video.likes_count)}</span>
                      </div>
                      <div className="flex items-center gap-1">
                        <MessageCircle size={14} />
                        <span>{formatCount(video.comments_count)}</span>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity bg-black/20">
                  <div className="w-12 h-12 bg-white/90 rounded-full flex items-center justify-center">
                    <Play size={24} className="text-slate-900 ml-1" fill="currentColor" />
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
