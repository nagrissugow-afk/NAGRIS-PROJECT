import { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { Settings, Grid, Heart, Lock, Share2, UserPlus, UserMinus, ChevronDown, Menu, Video as VideoIcon, Radio, Ban, X, Link as LinkIcon, MapPin, Calendar, Trash2, Eye, EyeOff, MoreVertical } from 'lucide-react';
import { api } from '../lib/api';
import { useAuth } from '../lib/newAuthContext'; // ✅ use custom auth
import type { User, Video } from '../lib/types';
import FollowersModal from './FollowersModal';
import EditProfileModal from './EditProfileModal';

type TabType = 'videos' | 'liked' | 'private' | 'saved' | 'history';

export default function ProfilePage() {
  const { userId } = useParams();
  const navigate = useNavigate();
  const { user: authUser } = useAuth(); // ✅ current logged-in user
  const [user, setUser] = useState<User | null>(null);
  const [currentUserId, setCurrentUserId] = useState<string>('');
  const [activeTab, setActiveTab] = useState<TabType>('videos');
  const [videos, setVideos] = useState<Video[]>([]);
  const [isFollowing, setIsFollowing] = useState(false);
  const [loading, setLoading] = useState(true);
  const [showMenu, setShowMenu] = useState(false);
  const [showFollowersModal, setShowFollowersModal] = useState(false);
  const [followersModalType, setFollowersModalType] = useState<'followers' | 'following'>('followers');
  const [showEditModal, setShowEditModal] = useState(false);
  const [isBlocked, setIsBlocked] = useState(false);
  const [showVideoMenu, setShowVideoMenu] = useState<string | null>(null);

  useEffect(() => {
    if (authUser) {
      setCurrentUserId(authUser.id);
    }
    loadProfile();
  }, [userId, authUser]);

  useEffect(() => {
    if (user) {
      loadVideos();
    }
  }, [activeTab, user]);

  useEffect(() => {
    const handleClickOutside = () => {
      setShowVideoMenu(null);
    };
    if (showVideoMenu) {
      document.addEventListener('click', handleClickOutside);
      return () => document.removeEventListener('click', handleClickOutside);
    }
  }, [showVideoMenu]);

  const loadProfile = async () => {
    try {
      const profileId = userId || authUser?.id;
      if (!profileId) return;

      const profile = await api.getUserProfile(profileId);
      setUser(profile);

      if (profileId !== currentUserId) {
        const following = await api.isFollowing(profileId);
        setIsFollowing(following);

        const blocked = await api.isBlocked(profileId);
        setIsBlocked(blocked);
      }
    } catch (err) {
      console.error('Failed to load profile:', err);
    } finally {
      setLoading(false);
    }
  };

  const loadVideos = async () => {
    if (!user) return;
    try {
      const vids = await api.getUserVideos(user.id, activeTab);
      setVideos(vids);
    } catch (err) {
      console.error('Failed to load videos:', err);
    }
  };

  const handleFollow = async () => {
    if (!user) return;
    try {
      if (isFollowing) {
        await api.unfollowUser(user.id);
      } else {
        await api.followUser(user.id);
      }
      setIsFollowing(!isFollowing);
      loadProfile();
    } catch (err) {
      console.error('Failed to follow/unfollow:', err);
    }
  };

  const handleBlock = async () => {
    if (!user) return;
    if (confirm(`Are you sure you want to block @${user.username}?`)) {
      try {
        if (isBlocked) {
          await api.unblockUser(user.id);
          setIsBlocked(false);
        } else {
          await api.blockUser(user.id);
          setIsBlocked(true);
          setIsFollowing(false);
        }
        setShowMenu(false);
      } catch (err) {
        console.error('Failed to block/unblock user:', err);
      }
    }
  };

  const openFollowersModal = (type: 'followers' | 'following') => {
    setFollowersModalType(type);
    setShowFollowersModal(true);
  };

  const handleDeleteVideo = async (videoId: string) => {
    if (!confirm('Are you sure you want to delete this video? This action cannot be undone.')) {
      return;
    }
    try {
      await api.deleteVideo(videoId);
      loadVideos();
      setShowVideoMenu(null);
    } catch (err) {
      console.error('Failed to delete video:', err);
      alert('Failed to delete video');
    }
  };

  const handleTogglePrivacy = async (videoId: string) => {
    try {
      await api.toggleVideoPrivacy(videoId);
      loadVideos();
      setShowVideoMenu(null);
    } catch (err) {
      console.error('Failed to toggle privacy:', err);
      alert('Failed to toggle privacy');
    }
  };

  const isOwnProfile = user?.id === currentUserId;

  const tabs: { key: TabType; label: string; icon: any }[] = [
    { key: 'videos', label: 'Photos', icon: Grid },
    ...(isOwnProfile ? [
      { key: 'liked' as TabType, label: 'Liked', icon: Heart },
      { key: 'private' as TabType, label: 'Private', icon: Lock },
    ] : []),
  ];

  if (loading) {
    return (
      <div className="min-h-screen bg-white flex items-center justify-center">
        <p className="text-slate-600">Loading profile...</p>
      </div>
    );
  }

  if (!user) {
    return (
      <div className="min-h-screen bg-white flex items-center justify-center">
        <p className="text-slate-600">User not found</p>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-white pb-20">
      <div className="max-w-4xl mx-auto">
        <div className="bg-gradient-to-br from-slate-50 to-white border-b border-slate-200">
          <div className="px-4 pt-6 pb-4">
            <div className="flex items-start justify-between mb-4">
              <div className="flex items-start gap-4">
                <div className="relative">
                  <img
                    src={user.avatar_url || 'https://via.placeholder.com/120'}
                    alt={user.username}
                    className="w-24 h-24 md:w-32 md:h-32 rounded-full border-4 border-white shadow-lg"
                  />
                  {user.is_verified && (
                    <div className="absolute bottom-0 right-0 bg-cyan-500 rounded-full p-2 border-4 border-white">
                      <svg className="w-5 h-5 text-white" fill="currentColor" viewBox="0 0 20 20">
                        <path d="M6.267 3.455a3.066 3.066 0 001.745-.723 3.066 3.066 0 013.976 0 3.066 3.066 0 001.745.723 3.066 3.066 0 012.812 2.812c.051.643.304 1.254.723 1.745a3.066 3.066 0 010 3.976 3.066 3.066 0 00-.723 1.745 3.066 3.066 0 01-2.812 2.812 3.066 3.066 0 00-1.745.723 3.066 3.066 0 01-3.976 0 3.066 3.066 0 00-1.745-.723 3.066 3.066 0 01-2.812-2.812 3.066 3.066 0 00-.723-1.745 3.066 3.066 0 010-3.976 3.066 3.066 0 00.723-1.745 3.066 3.066 0 012.812-2.812zm7.44 5.252a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" />
                      </svg>
                    </div>
                  )}
                </div>

                <div className="flex-1 pt-2">
                  <div className="flex items-center gap-2 mb-1">
                    <h1 className="text-2xl font-bold text-slate-900">{user.username}</h1>
                  </div>
                  <p className="text-slate-500 text-sm mb-3">@{user.username}</p>

                  <div className="flex items-center gap-4 text-sm mb-3">
                    <button
                      onClick={() => openFollowersModal('following')}
                      className="hover:text-slate-900 transition-colors"
                    >
                      <span className="font-bold text-slate-900">{user.following_count}</span>
                      <span className="text-slate-600"> Following</span>
                    </button>
                    <button
                      onClick={() => openFollowersModal('followers')}
                      className="hover:text-slate-900 transition-colors"
                    >
                      <span className="font-bold text-slate-900">{user.followers_count}</span>
                      <span className="text-slate-600"> Followers</span>
                    </button>
                    <div>
                      <span className="font-bold text-slate-900">{user.total_likes}</span>
                      <span className="text-slate-600"> Likes</span>
                    </div>
                  </div>
                </div>
              </div>

              {isOwnProfile && (
                <div className="relative">
                  <button
                    onClick={() => setShowMenu(!showMenu)}
                    className="p-2 hover:bg-slate-100 rounded-full transition-colors"
                  >
                    <Menu size={24} className="text-slate-700" />
                  </button>

                  {showMenu && (
                    <div className="absolute right-0 top-full mt-2 w-56 bg-white rounded-xl border border-slate-200 shadow-2xl overflow-hidden z-50">
                      <button
                        onClick={() => { navigate('/?tab=my-videos'); setShowMenu(false); }}
                        className="w-full flex items-center gap-3 px-4 py-3 hover:bg-slate-50 transition-colors"
                      >
                        <VideoIcon size={18} className="text-cyan-500" />
                        <span className="text-slate-700">My Videos</span>
                      </button>
                      <button
                        onClick={() => { navigate('/live'); setShowMenu(false); }}
                        className="w-full flex items-center gap-3 px-4 py-3 hover:bg-slate-50 transition-colors border-t border-slate-100"
                      >
                        <Radio size={18} className="text-red-500" />
                        <span className="text-slate-700">Live Stream</span>
                      </button>
                      <button
                        onClick={() => { navigate('/settings'); setShowMenu(false); }}
                        className="w-full flex items-center gap-3 px-4 py-3 hover:bg-slate-50 transition-colors border-t border-slate-100"
                      >
                        <Settings size={18} className="text-slate-500" />
                        <span className="text-slate-700">Settings</span>
                      </button>
                    </div>
                  )}
                </div>
              )}
            </div>

            {user.bio && (
              <div className="mb-3 text-slate-700 text-sm leading-relaxed">
                {user.bio}
              </div>
            )}

            <div className="flex items-center gap-3 mb-4">
              {isOwnProfile ? (
                <button
                  onClick={() => setShowEditModal(true)}
                  className="px-8 py-2 bg-slate-900 text-white rounded-lg hover:bg-slate-800 transition-colors text-sm font-medium"
                >
                  Edit Profile
                </button>
              ) : (
                <>
                  <button
                    onClick={handleFollow}
                    className={`px-8 py-2 rounded-lg text-sm font-medium transition-colors ${
                      isFollowing
                        ? 'bg-slate-200 text-slate-900 hover:bg-slate-300'
                        : 'bg-slate-900 text-white hover:bg-slate-800'
                    }`}
                  >
                    {isFollowing ? 'Following' : 'Follow'}
                  </button>
                  <button
                    onClick={handleBlock}
                    className="px-4 py-2 bg-slate-200 text-slate-700 rounded-lg hover:bg-slate-300 transition-colors text-sm font-medium"
                    title={isBlocked ? 'Unblock user' : 'Block user'}
                  >
                    {isBlocked ? 'Unblock' : 'Block'}
                  </button>
                </>
              )}
              <button className="px-4 py-2 bg-slate-200 text-slate-700 rounded-lg hover:bg-slate-300 transition-colors">
                <Share2 size={18} />
              </button>
            </div>
          </div>

          <div className="flex border-t border-slate-200 bg-white">
            {tabs.map((tab) => (
              <button
                key={tab.key}
                onClick={() => setActiveTab(tab.key)}
                className={`flex-1 flex items-center justify-center gap-2 px-4 py-3 transition-colors ${
                  activeTab === tab.key
                    ? 'text-slate-900 border-b-2 border-slate-900'
                    : 'text-slate-500 hover:text-slate-700'
                }`}
              >
                <tab.icon size={16} />
                <span className="font-medium text-sm">{tab.label}</span>
              </button>
            ))}
          </div>
        </div>

        <div className="p-2">
          {videos.length === 0 ? (
            <div className="text-center py-16">
              <Grid size={48} className="mx-auto text-slate-300 mb-3" />
              <p className="text-slate-500 text-sm">No content yet</p>
            </div>
          ) : (
            <div className="grid grid-cols-3 gap-1">
              {videos.map((video) => {
                const formatViewCount = (count: number): string => {              
                  if (count >= 1000000) return `${(count / 1000000).toFixed(1)}M`;
                  if (count >= 1000) return `${(count / 1000).toFixed(1)}K`;
                  return count.toString();
                };

                return (
                  <div
                    key={video.id}
                    className="relative aspect-square bg-slate-900 cursor-pointer overflow-hidden group"
                    onClick={() => navigate(`/?video=${video.id}`)}
                  >
                    {/* Video thumbnail or first frame */}
                    <video
                       src={video.video_url}
                       muted
                       playsInline
                       preload="metadata"
                       className="w-full h-full object-cover"
                       onMouseEnter={(e) => (e.target as HTMLVideoElement).play()}
                       onMouseLeave={(e) => {
                         const vid = e.target as HTMLVideoElement;
                         vid.pause();
                         vid.currentTime = 0;
                       }}
                    />

                     {/* Duration in corner */}
                     <span className="absolute bottom-1 right-1 text-xs bg-black/70 text-white px-1.5 py-0.5 rounded">
                       {video.duration ? `${Math.floor(video.duration / 60)}:${String(video.duration % 60).padStart(2, '0')}` : '0:00'}
                     </span>

                   {/* Views overlay (like TikTok) */}
                 <div className="absolute inset-0 bg-black/0 group-hover:bg-black/30 transition-all flex items-end justify-start p-1">
                    <div className="flex items-center gap-1 text-white text-xs font-semibold opacity-90">
                       <VideoIcon size={14} />
                        {formatViewCount(video.views_count)}
                      </div>
                    </div>

                    {/* Controls menu for own videos */}
                    {isOwnProfile && (
                      <div className="absolute top-1 right-1">
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            setShowVideoMenu(showVideoMenu === video.id ? null : video.id);
                          }}
                          className="p-1.5 bg-black/70 hover:bg-black/90 rounded-full text-white transition-colors"
                        >
                          <MoreVertical size={16} />
                        </button>

                        {showVideoMenu === video.id && (
                          <div className="absolute right-0 top-full mt-1 w-48 bg-white rounded-lg shadow-xl border border-slate-200 overflow-hidden z-50">
                            <button
                              onClick={(e) => {
                                e.stopPropagation();
                                handleTogglePrivacy(video.id);
                              }}
                              className="w-full flex items-center gap-3 px-4 py-3 hover:bg-slate-50 transition-colors text-left"
                            >
                              {video.is_private ? (
                                <>
                                  <Eye size={16} className="text-cyan-500" />
                                  <span className="text-slate-700 text-sm">Make Public</span>
                                </>
                              ) : (
                                <>
                                  <EyeOff size={16} className="text-slate-500" />
                                  <span className="text-slate-700 text-sm">Make Private</span>
                                </>
                              )}
                            </button>
                            <button
                              onClick={(e) => {
                                e.stopPropagation();
                                handleDeleteVideo(video.id);
                              }}
                              className="w-full flex items-center gap-3 px-4 py-3 hover:bg-red-50 transition-colors border-t border-slate-100 text-left"
                            >
                              <Trash2 size={16} className="text-red-500" />
                              <span className="text-red-600 text-sm">Delete Video</span>
                            </button>
                          </div>
                        )}
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          )}
        </div>
      </div>

      {showFollowersModal && user && (
        <FollowersModal
          userId={user.id}
          type={followersModalType}
          onClose={() => setShowFollowersModal(false)}
        />
      )}

      {showEditModal && (
        <EditProfileModal
          onClose={() => setShowEditModal(false)}
          onSuccess={loadProfile}
        />
      )}
    </div>
  );
}
