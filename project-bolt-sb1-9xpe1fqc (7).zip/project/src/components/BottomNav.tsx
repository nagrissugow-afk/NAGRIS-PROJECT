import { Home, PlusSquare, Bell, User, Wallet, Radio } from 'lucide-react';
import { useNavigate, useLocation } from 'react-router-dom';
import { useAuth } from '../lib/newAuthContext';
import { useState, useEffect } from 'react';
import { supabase } from '../lib/supabase';
import { getUser } from '../lib/customAuth';

export default function BottomNav() {
  const navigate = useNavigate();
  const location = useLocation();
  const { requireAuth } = useAuth();
  const [unreadCount, setUnreadCount] = useState(0);

  const isActive = (path: string) => location.pathname === path;

  useEffect(() => {
    const user = getUser();
    if (!user) return;

    const fetchUnreadCount = async () => {
      const { count } = await supabase
        .from('notifications')
        .select('*', { count: 'exact', head: true })
        .eq('user_id', user.id)
        .eq('is_read', false);

      setUnreadCount(count || 0);
    };

    fetchUnreadCount();

    const channel = supabase
      .channel('unread_notifications')
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'notifications',
          filter: `user_id=eq.${user.id}`,
        },
        () => {
          fetchUnreadCount();
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, []);

  const handleNavigate = (path: string, requiresAuth: boolean = false) => {
    if (requiresAuth && !requireAuth()) {
      return;
    }
    navigate(path);
  };

  const navItems = [
    { path: '/', icon: Home, label: 'Home', requiresAuth: false },
    { path: '/live', icon: Radio, label: 'Live', requiresAuth: true },
    { path: '/upload', icon: PlusSquare, label: 'Upload', requiresAuth: true },
    { path: '/notifications', icon: Bell, label: 'Inbox', requiresAuth: true },
    { path: '/wallet', icon: Wallet, label: 'Wallet', requiresAuth: true },
    { path: '/profile', icon: User, label: 'Profile', requiresAuth: true },
  ];

  return (
    <nav className="fixed bottom-0 left-0 right-0 bg-slate-900/95 backdrop-blur-lg border-t border-slate-800 z-40">
      <div className="flex justify-around items-center h-16 max-w-screen-xl mx-auto px-2">
        {navItems.map((item) => {
          const Icon = item.icon;
          const active = isActive(item.path);
          const isNotifications = item.path === '/notifications';
          const showBadge = isNotifications && unreadCount > 0;

          return (
            <button
              key={item.path}
              onClick={() => handleNavigate(item.path, item.requiresAuth)}
              className={`flex flex-col items-center justify-center flex-1 h-full transition-colors relative ${
                active ? 'text-cyan-400' : 'text-slate-400 hover:text-white'
              }`}
            >
              <div className="relative">
                <Icon size={24} className={active ? 'stroke-2' : ''} />
                {showBadge && (
                  <span className="absolute -top-1 -right-1 bg-red-500 text-white text-[10px] font-bold rounded-full min-w-[16px] h-4 flex items-center justify-center px-1">
                    {unreadCount > 99 ? '99+' : unreadCount}
                  </span>
                )}
              </div>
              <span className="text-xs mt-1 font-medium">{item.label}</span>
            </button>
          );
        })}
      </div>
    </nav>
  );
}
