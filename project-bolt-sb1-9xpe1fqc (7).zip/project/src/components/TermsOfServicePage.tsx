import { ArrowLeft } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

export default function TermsOfServicePage() {
  const navigate = useNavigate();

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-blue-900 to-slate-900 pb-20">
      <div className="max-w-4xl mx-auto">
        <div className="sticky top-0 bg-slate-900/80 backdrop-blur-lg border-b border-slate-700 px-4 py-4 flex items-center gap-4 z-10">
          <button
            onClick={() => navigate(-1)}
            className="text-white hover:bg-slate-700/50 p-2 rounded-lg transition-colors"
          >
            <ArrowLeft size={24} />
          </button>
          <h1 className="text-xl font-bold text-white">Terms of Service</h1>
        </div>

        <div className="px-4 py-8 space-y-6 text-slate-300">
          <div className="bg-slate-800/50 backdrop-blur-lg rounded-2xl border border-slate-700 p-6 space-y-4">
            <p className="text-sm text-slate-400">Last Updated: December 2024</p>

            <section>
              <h2 className="text-xl font-bold text-white mb-3">1. Acceptance of Terms</h2>
              <p>By accessing or using Nagris, you agree to be bound by these Terms of Service. If you do not agree to these terms, please do not use our service.</p>
            </section>

            <section>
              <h2 className="text-xl font-bold text-white mb-3">2. User Accounts</h2>
              <p className="mb-2">When creating an account, you agree to:</p>
              <ul className="list-disc list-inside space-y-1 ml-4">
                <li>Provide accurate and complete information</li>
                <li>Maintain the security of your account credentials</li>
                <li>Be responsible for all activities under your account</li>
                <li>Notify us immediately of any unauthorized access</li>
              </ul>
            </section>

            <section>
              <h2 className="text-xl font-bold text-white mb-3">3. Content Guidelines</h2>
              <p className="mb-2">You may not post content that:</p>
              <ul className="list-disc list-inside space-y-1 ml-4">
                <li>Violates laws or regulations</li>
                <li>Infringes on intellectual property rights</li>
                <li>Contains hate speech, harassment, or bullying</li>
                <li>Promotes violence or dangerous activities</li>
                <li>Contains explicit adult content</li>
                <li>Spreads misinformation or spam</li>
              </ul>
            </section>

            <section>
              <h2 className="text-xl font-bold text-white mb-3">4. Intellectual Property</h2>
              <p className="mb-2">You retain ownership of content you post, but grant Nagris a worldwide, non-exclusive license to use, reproduce, and distribute your content on our platform.</p>
            </section>

            <section>
              <h2 className="text-xl font-bold text-white mb-3">5. Monetization</h2>
              <p className="mb-2">Eligible creators may participate in monetization programs. By participating, you agree to:</p>
              <ul className="list-disc list-inside space-y-1 ml-4">
                <li>Meet and maintain eligibility requirements</li>
                <li>Comply with payment processing terms</li>
                <li>Provide accurate tax and payment information</li>
                <li>Understand that earnings are not guaranteed</li>
              </ul>
            </section>

            <section>
              <h2 className="text-xl font-bold text-white mb-3">6. Prohibited Activities</h2>
              <p className="mb-2">You may not:</p>
              <ul className="list-disc list-inside space-y-1 ml-4">
                <li>Use bots, automation, or artificial engagement</li>
                <li>Attempt to hack or compromise the platform</li>
                <li>Impersonate others or misrepresent identity</li>
                <li>Engage in fraudulent activities</li>
                <li>Circumvent platform restrictions or bans</li>
              </ul>
            </section>

            <section>
              <h2 className="text-xl font-bold text-white mb-3">7. Account Termination</h2>
              <p>We reserve the right to suspend or terminate accounts that violate these terms. You may delete your account at any time through Settings.</p>
            </section>

            <section>
              <h2 className="text-xl font-bold text-white mb-3">8. Disclaimers</h2>
              <p>The service is provided "as is" without warranties of any kind. We do not guarantee uninterrupted or error-free service.</p>
            </section>

            <section>
              <h2 className="text-xl font-bold text-white mb-3">9. Limitation of Liability</h2>
              <p>Nagris shall not be liable for any indirect, incidental, special, or consequential damages arising from use of the service.</p>
            </section>

            <section>
              <h2 className="text-xl font-bold text-white mb-3">10. Changes to Terms</h2>
              <p>We may modify these terms at any time. Continued use of the service after changes constitutes acceptance of the new terms.</p>
            </section>

            <section>
              <h2 className="text-xl font-bold text-white mb-3">11. Governing Law</h2>
              <p>These terms are governed by applicable international laws and regulations.</p>
            </section>

            <section>
              <h2 className="text-xl font-bold text-white mb-3">12. Contact Us</h2>
              <p>For questions about these terms, please contact us through the Support section in Settings.</p>
            </section>
          </div>
        </div>
      </div>
    </div>
  );
}
