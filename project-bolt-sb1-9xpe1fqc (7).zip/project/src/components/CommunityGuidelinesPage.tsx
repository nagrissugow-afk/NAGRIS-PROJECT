import { ArrowLeft } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

export default function CommunityGuidelinesPage() {
  const navigate = useNavigate();

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-blue-900 to-slate-900 pb-20">
      <div className="max-w-4xl mx-auto">
        <div className="sticky top-0 bg-slate-900/80 backdrop-blur-lg border-b border-slate-700 px-4 py-4 flex items-center gap-4 z-10">
          <button
            onClick={() => navigate(-1)}
            className="text-white hover:bg-slate-700/50 p-2 rounded-lg transition-colors"
          >
            <ArrowLeft size={24} />
          </button>
          <h1 className="text-xl font-bold text-white">Community Guidelines</h1>
        </div>

        <div className="px-4 py-8 space-y-6 text-slate-300">
          <div className="bg-slate-800/50 backdrop-blur-lg rounded-2xl border border-slate-700 p-6 space-y-4">
            <p className="text-sm text-slate-400">Last Updated: December 2024</p>

            <div className="bg-gradient-to-r from-cyan-500/10 to-blue-500/10 border border-cyan-500/30 rounded-xl p-4">
              <p className="text-white font-medium">Nagris is a creative, inclusive community. Help us keep it safe and welcoming for everyone.</p>
            </div>

            <section>
              <h2 className="text-xl font-bold text-white mb-3">Safety and Respect</h2>
              <p className="mb-2">We do not tolerate:</p>
              <ul className="list-disc list-inside space-y-1 ml-4">
                <li>Harassment, bullying, or threats of violence</li>
                <li>Hate speech based on race, religion, gender, or other protected characteristics</li>
                <li>Doxxing or sharing private information without consent</li>
                <li>Impersonation or identity theft</li>
                <li>Predatory behavior or grooming</li>
              </ul>
            </section>

            <section>
              <h2 className="text-xl font-bold text-white mb-3">Dangerous Content</h2>
              <p className="mb-2">Do not post content that:</p>
              <ul className="list-disc list-inside space-y-1 ml-4">
                <li>Promotes self-harm or suicide</li>
                <li>Depicts graphic violence or gore</li>
                <li>Glorifies dangerous acts or challenges</li>
                <li>Promotes eating disorders</li>
                <li>Provides instructions for illegal activities</li>
              </ul>
            </section>

            <section>
              <h2 className="text-xl font-bold text-white mb-3">Adult Content</h2>
              <p className="mb-2">Nagris prohibits:</p>
              <ul className="list-disc list-inside space-y-1 ml-4">
                <li>Sexually explicit content</li>
                <li>Nudity or partial nudity</li>
                <li>Sexual solicitation</li>
                <li>Content involving minors in any inappropriate context</li>
              </ul>
            </section>

            <section>
              <h2 className="text-xl font-bold text-white mb-3">Integrity and Authenticity</h2>
              <p className="mb-2">Be genuine:</p>
              <ul className="list-disc list-inside space-y-1 ml-4">
                <li>Do not spread misinformation or conspiracy theories</li>
                <li>Do not manipulate platform features or metrics</li>
                <li>Disclose paid partnerships and sponsored content</li>
                <li>Do not engage in spam or artificial engagement</li>
                <li>Respect intellectual property and copyright</li>
              </ul>
            </section>

            <section>
              <h2 className="text-xl font-bold text-white mb-3">Regulated Content</h2>
              <p className="mb-2">Follow platform rules for:</p>
              <ul className="list-disc list-inside space-y-1 ml-4">
                <li>Firearms and weapons</li>
                <li>Drugs and controlled substances</li>
                <li>Alcohol and tobacco</li>
                <li>Gambling and contests</li>
                <li>Political content and advocacy</li>
              </ul>
            </section>

            <section>
              <h2 className="text-xl font-bold text-white mb-3">Illegal Activities</h2>
              <p>Content promoting or facilitating illegal activities is strictly prohibited. This includes fraud, trafficking, and other criminal acts.</p>
            </section>

            <section>
              <h2 className="text-xl font-bold text-white mb-3">Reporting Violations</h2>
              <p className="mb-2">If you see content that violates these guidelines:</p>
              <ul className="list-disc list-inside space-y-1 ml-4">
                <li>Use the report feature on videos and profiles</li>
                <li>Provide detailed information about the violation</li>
                <li>Block users who make you uncomfortable</li>
                <li>Contact support for urgent safety concerns</li>
              </ul>
            </section>

            <section>
              <h2 className="text-xl font-bold text-white mb-3">Enforcement</h2>
              <p className="mb-2">Violations may result in:</p>
              <ul className="list-disc list-inside space-y-1 ml-4">
                <li>Content removal</li>
                <li>Warning notices</li>
                <li>Temporary account suspension</li>
                <li>Permanent account termination</li>
                <li>Loss of monetization privileges</li>
                <li>Legal action in severe cases</li>
              </ul>
            </section>

            <section>
              <h2 className="text-xl font-bold text-white mb-3">Appeals</h2>
              <p>If you believe your content was removed in error, you may appeal the decision through the Support section.</p>
            </section>

            <section>
              <h2 className="text-xl font-bold text-white mb-3">Be Creative, Be Kind</h2>
              <p>Nagris thrives when our community supports each other. Create amazing content, engage positively, and help build a platform everyone can enjoy.</p>
            </section>
          </div>
        </div>
      </div>
    </div>
  );
}
