import { useState, useEffect } from 'react';
import { ArrowLeft, Coins, Gift, Sparkles, Check } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { getAvailableGifts, getUserCoins, purchaseCoins, COIN_PACKAGES } from '../lib/gifts';
import type { User } from '../lib/types';
import { useAuth } from '../lib/newAuthContext';  // ✅ custom auth

export default function ShopPage() {
  const navigate = useNavigate();
  const { user } = useAuth(); // ✅ get logged-in user
  const [activeTab, setActiveTab] = useState<'coins' | 'gifts'>('coins');
  const [gifts, setGifts] = useState<any[]>([]);
  const [userCoins, setUserCoins] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [purchasing, setPurchasing] = useState(false);

  useEffect(() => {
    if (user) {
      loadShopData(user.id);
    } else {
      setLoading(false);
    }
  }, [user]);

  const loadShopData = async (userId: string) => {
    try {
      const [giftsData, coinsData] = await Promise.all([
        getAvailableGifts(),
        getUserCoins(userId)
      ]);

      setGifts(giftsData);
      setUserCoins(coinsData);
    } catch (err) {
      console.error('Failed to load shop data:', err);
    } finally {
      setLoading(false);
    }
  };

  const handlePurchaseCoins = async (packageIndex: number) => {
    if (!user) {
      alert('Not authenticated');
      return;
    }

    const pkg = COIN_PACKAGES[packageIndex];
    if (!confirm(`Purchase ${pkg.coins + pkg.bonus} coins for $${pkg.usd}?`)) return;

    setPurchasing(true);
    try {
      // 🚨 Real payment integration will go here later
      alert('Payment integration coming soon! (Stripe/PayPal)');

      const result = await purchaseCoins(user.id, pkg.coins + pkg.bonus);
      if (result.success) {
        alert(`Successfully purchased ${pkg.coins + pkg.bonus} coins!`);
        loadShopData(user.id);
      } else {
        alert(result.message || 'Purchase failed');
      }
    } catch (err) {
      console.error('Purchase failed:', err);
      alert('Purchase failed');
    } finally {
      setPurchasing(false);
    }
  };
  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-900 via-blue-900 to-slate-900 flex items-center justify-center">
        <p className="text-white">Loading shop...</p>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-blue-900 to-slate-900 pb-20">
      <div className="sticky top-0 bg-slate-900/80 backdrop-blur-lg border-b border-slate-700 px-4 py-4 flex items-center gap-4 z-10">
        <button
          onClick={() => navigate('/profile')}
          className="text-white hover:bg-slate-700/50 p-2 rounded-lg transition-colors"
        >
          <ArrowLeft size={24} />
        </button>
        <h1 className="text-xl font-bold text-white">Shop</h1>
        <div className="ml-auto flex items-center gap-2 bg-slate-800 px-3 py-2 rounded-lg">
          <Coins className="text-yellow-400" size={20} />
          <span className="text-white font-bold">{userCoins?.balance || 0}</span>
        </div>
      </div>

      <div className="max-w-2xl mx-auto p-4">
        <div className="flex gap-2 mb-6 bg-slate-800/50 p-1 rounded-lg">
          <button
            onClick={() => setActiveTab('coins')}
            className={`flex-1 py-2 px-4 rounded-lg font-medium transition-all ${
              activeTab === 'coins'
                ? 'bg-gradient-to-r from-yellow-500 to-orange-500 text-white'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <Coins className="inline mr-2" size={18} />
            Coins
          </button>
          <button
            onClick={() => setActiveTab('gifts')}
            className={`flex-1 py-2 px-4 rounded-lg font-medium transition-all ${
              activeTab === 'gifts'
                ? 'bg-gradient-to-r from-pink-500 to-purple-500 text-white'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <Gift className="inline mr-2" size={18} />
            Gifts
          </button>
        </div>

        {activeTab === 'coins' && (
          <div>
            <div className="bg-gradient-to-r from-yellow-500 to-orange-500 rounded-xl p-6 mb-6">
              <div className="flex items-center gap-3 mb-2">
                <Sparkles className="text-white" size={24} />
                <h2 className="text-white text-2xl font-bold">Buy Coins</h2>
              </div>
              <p className="text-white/90 text-sm">
                Use coins to send gifts to your favorite creators during videos and live streams
              </p>
            </div>

            <div className="grid gap-4">
              {COIN_PACKAGES.map((pkg, index) => (
                <div
                  key={index}
                  className="bg-slate-800/50 backdrop-blur-lg rounded-xl border border-slate-700 p-5 hover:border-yellow-500/50 transition-all"
                >
                  <div className="flex items-center justify-between mb-3">
                    <div>
                      <div className="flex items-center gap-2 mb-1">
                        <Coins className="text-yellow-400" size={24} />
                        <span className="text-white text-2xl font-bold">
                          {pkg.coins.toLocaleString()}
                        </span>
                      </div>
                      {pkg.bonus > 0 && (
                        <div className="flex items-center gap-1 bg-green-500/20 px-2 py-1 rounded-full w-fit">
                          <Sparkles className="text-green-400" size={12} />
                          <span className="text-green-400 text-xs font-medium">
                            +{pkg.bonus} Bonus
                          </span>
                        </div>
                      )}
                    </div>
                    <div className="text-right">
                      <p className="text-white text-2xl font-bold">${pkg.usd}</p>
                      <p className="text-slate-400 text-xs">USD</p>
                    </div>
                  </div>
                  <button
                    onClick={() => handlePurchaseCoins(index)}
                    disabled={purchasing}
                    className="w-full py-3 bg-gradient-to-r from-yellow-500 to-orange-500 text-white rounded-lg font-medium hover:from-yellow-600 hover:to-orange-600 transition-all disabled:opacity-50"
                  >
                    {purchasing ? 'Processing...' : 'Purchase'}
                  </button>
                </div>
              ))}
            </div>

            <div className="mt-6 bg-blue-500/10 border border-blue-500/30 rounded-lg p-4">
              <p className="text-blue-300 text-sm">
                <Check className="inline mr-1" size={16} />
                Secure payment processing through Stripe
              </p>
              <p className="text-blue-300 text-sm mt-1">
                <Check className="inline mr-1" size={16} />
                Coins never expire
              </p>
            </div>
          </div>
        )}

        {activeTab === 'gifts' && (
          <div>
            <div className="bg-gradient-to-r from-pink-500 to-purple-500 rounded-xl p-6 mb-6">
              <div className="flex items-center gap-3 mb-2">
                <Gift className="text-white" size={24} />
                <h2 className="text-white text-2xl font-bold">Gift Gallery</h2>
              </div>
              <p className="text-white/90 text-sm">
                Send these gifts to show your appreciation to creators
              </p>
            </div>

            <div className="grid grid-cols-2 gap-4">
              {gifts.map((gift) => (
                <div
                  key={gift.id}
                  className="bg-slate-800/50 backdrop-blur-lg rounded-xl border border-slate-700 p-4 text-center hover:border-pink-500/50 transition-all"
                >
                  <div className="text-4xl mb-2">
                    {gift.icon_url ? (
                      <img src={gift.icon_url} alt={gift.name} className="w-16 h-16 mx-auto" />
                    ) : (
                      <Gift className="w-16 h-16 mx-auto text-pink-400" />
                    )}
                  </div>
                  <h3 className="text-white font-semibold mb-1">{gift.name}</h3>
                  <p className="text-slate-400 text-xs mb-3">{gift.description}</p>
                  <div className="flex items-center justify-center gap-2 bg-slate-700/50 px-3 py-2 rounded-lg">
                    <Coins className="text-yellow-400" size={16} />
                    <span className="text-white font-bold">{gift.coin_cost}</span>
                  </div>
                  <p className="text-slate-500 text-xs mt-2">${gift.usd_value.toFixed(2)} USD</p>
                </div>
              ))}
            </div>

            <div className="mt-6 bg-pink-500/10 border border-pink-500/30 rounded-lg p-4">
              <p className="text-pink-300 text-sm">
                Gifts can be sent during videos and live streams. Creators earn from the gifts they receive.
              </p>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
