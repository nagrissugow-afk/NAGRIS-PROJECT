import { useState, useEffect } from 'react';
import { DollarSign, TrendingUp, Gift, Calendar, AlertCircle, Check, Eye, Heart, Users, Shield, Award, Clock, CheckCircle, XCircle, ArrowDownCircle, ArrowUpCircle, Lock } from 'lucide-react';
import type { User } from '../lib/types';
import { getMonetizationEligibility, getUserVerification, isEligibleCountry, getCountryName, refreshMonetizationStatus } from '../lib/verification';
import { getWalletEarnings, requestWithdrawal } from '../lib/gifts';
import { useAuth } from '../lib/newAuthContext';
import { supabase } from '../lib/supabase';

interface Transaction {
  id: string;
  type: 'gift' | 'views' | 'withdrawal' | 'deposit';
  amount: number;
  status: 'pending' | 'completed' | 'failed' | 'cancelled';
  reference_id: string;
  metadata: any;
  created_at: string;
}

interface WithdrawalRequest {
  id: string;
  amount: number;
  status: 'pending' | 'approved' | 'rejected';
  method: string;
  created_at: string;
  processed_at: string | null;
}

export default function WalletPage() {
  const { user } = useAuth();
  const [earnings, setEarnings] = useState<any>(null);
  const [eligibility, setEligibility] = useState<any>(null);
  const [verification, setVerification] = useState<any>(null);
  const [showWithdrawModal, setShowWithdrawModal] = useState(false);
  const [withdrawType, setWithdrawType] = useState<'views' | 'gifts'>('gifts');
  const [amount, setAmount] = useState('');
  const [paymentMethod, setPaymentMethod] = useState('');
  const [paymentDetails, setPaymentDetails] = useState('');
  const [loading, setLoading] = useState(true);
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [withdrawalRequests, setWithdrawalRequests] = useState<WithdrawalRequest[]>([]);
  const [lockedBalance, setLockedBalance] = useState(0);
  const [activeTab, setActiveTab] = useState<'overview' | 'transactions' | 'withdrawals'>('overview');

  useEffect(() => {
    if (user) {
      loadWalletData(user.id);
    } else {
      setLoading(false);
    }
  }, [user]);

  const loadWalletData = async (userId: string) => {
    try {
      await refreshMonetizationStatus(userId);

      const [earningsData, eligibilityData, verificationData] = await Promise.all([
        getWalletEarnings(userId),
        getMonetizationEligibility(userId),
        getUserVerification(userId),
        loadTransactions(userId),
        loadWithdrawalRequests(userId),
        loadLockedBalance(userId)
      ]);

      setEarnings(earningsData);
      setEligibility(eligibilityData);
      setVerification(verificationData);
    } catch (err) {
      console.error('Failed to load wallet data:', err);
    } finally {
      setLoading(false);
    }
  };

  const loadTransactions = async (userId: string) => {
    try {
      const { data, error } = await supabase
        .from('wallet_transactions')
        .select('*')
        .eq('user_id', userId)
        .order('created_at', { ascending: false })
        .limit(50);

      if (error) throw error;
      setTransactions(data || []);
    } catch (err) {
      console.error('Failed to load transactions:', err);
    }
  };

  const loadWithdrawalRequests = async (userId: string) => {
    try {
      const { data, error } = await supabase
        .from('withdrawal_requests')
        .select('*')
        .eq('user_id', userId)
        .order('created_at', { ascending: false });

      if (error) throw error;
      setWithdrawalRequests(data || []);
    } catch (err) {
      console.error('Failed to load withdrawal requests:', err);
    }
  };

  const loadLockedBalance = async (userId: string) => {
    try {
      const { data, error } = await supabase
        .from('users')
        .select('locked_balance')
        .eq('id', userId)
        .maybeSingle();

      if (error) throw error;
      setLockedBalance(data?.locked_balance || 0);
    } catch (err) {
      console.error('Failed to load locked balance:', err);
    }
  };

  const canWithdrawViews = () => {
    if (isTestUser || isAdmin) return true;
    if (!eligibility || !verification?.is_verified) return false;
    return eligibility.eligible_for_view_payouts && eligibility.meets_requirements;
  };

  const getPaymentMethods = () => {
    if (!verification) return [];
    const country = verification.country_code;
    if (country === 'KE') return ['M-Pesa', 'PayPal', 'Bank Transfer'];
    if (country === 'SO') return ['EVC Plus', 'Zaad', 'Dahabshiil', 'PayPal'];
    return ['PayPal', 'Bank Transfer'];
  };

  const handleWithdraw = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!earnings || !user) return;

    const withdrawAmount = parseFloat(amount);
    if (withdrawAmount < 10) {
      alert('Minimum withdrawal amount is $10');
      return;
    }

    const maxAmount = withdrawType === 'views' ? earnings.view_earnings : earnings.gift_earnings;
    const availableAmount = maxAmount - (earnings.pending_withdrawal || 0);

    if (withdrawAmount > availableAmount) {
      alert('Insufficient balance');
      return;
    }

    try {
      const result = await requestWithdrawal(
        user.id,
        withdrawAmount,
        paymentMethod,
        { account: paymentDetails, type: withdrawType }
      );

      if (result.success) {
        alert('Withdrawal request submitted successfully!');
        setShowWithdrawModal(false);
        setAmount('');
        setPaymentDetails('');
        loadWalletData(user.id);
      } else {
        alert(result.message || 'Failed to submit withdrawal request');
      }
    } catch (err) {
      console.error('Failed to create withdrawal:', err);
      alert('Failed to create withdrawal request');
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-900 via-blue-900 to-slate-900 flex items-center justify-center">
        <p className="text-white">Loading wallet...</p>
      </div>
    );
  }

  const getTransactionIcon = (type: string) => {
    switch (type) {
      case 'gift': return <Gift className="text-orange-400" size={20} />;
      case 'views': return <Eye className="text-purple-400" size={20} />;
      case 'withdrawal': return <ArrowDownCircle className="text-red-400" size={20} />;
      case 'deposit': return <ArrowUpCircle className="text-green-400" size={20} />;
      default: return <DollarSign className="text-slate-400" size={20} />;
    }
  };

  const getStatusBadge = (status: string) => {
    const badges = {
      pending: { icon: Clock, color: 'text-yellow-400 bg-yellow-400/10 border-yellow-400/30' },
      completed: { icon: CheckCircle, color: 'text-green-400 bg-green-400/10 border-green-400/30' },
      approved: { icon: CheckCircle, color: 'text-green-400 bg-green-400/10 border-green-400/30' },
      failed: { icon: XCircle, color: 'text-red-400 bg-red-400/10 border-red-400/30' },
      cancelled: { icon: XCircle, color: 'text-gray-400 bg-gray-400/10 border-gray-400/30' },
      rejected: { icon: XCircle, color: 'text-red-400 bg-red-400/10 border-red-400/30' }
    };

    const badge = badges[status as keyof typeof badges] || badges.pending;
    const Icon = badge.icon;

    return (
      <span className={`inline-flex items-center gap-1 px-2 py-1 rounded-full text-xs font-medium border ${badge.color}`}>
        <Icon size={14} />
        {status.charAt(0).toUpperCase() + status.slice(1)}
      </span>
    );
  };

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', {
      month: 'short',
      day: 'numeric',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  const totalBalance = (earnings?.view_earnings || 0) + (earnings?.gift_earnings || 0);
  const availableBalance = totalBalance - lockedBalance;
  const isVerified = verification?.is_verified || false;
  const isEligibleRegion = verification && isEligibleCountry(verification.country_code);
  const meetsRequirements = eligibility?.meets_requirements || false;
  const isTestUser = user?.is_test_account || false;
  const isAdmin = user?.is_admin || false;

  const viewsRemaining = Math.max(0, 1000000 - (eligibility?.total_views || 0));
  const likesRemaining = Math.max(0, 20000 - (eligibility?.total_likes || 0));
  const followersRemaining = Math.max(0, 10000 - (eligibility?.total_followers || 0));

  const viewsProgress = Math.min(100, ((eligibility?.total_views || 0) / 1000000) * 100);
  const likesProgress = Math.min(100, ((eligibility?.total_likes || 0) / 20000) * 100);
  const followersProgress = Math.min(100, ((eligibility?.total_followers || 0) / 10000) * 100);

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-blue-900 to-slate-900 p-4 pb-20">
      <div className="max-w-4xl mx-auto">
        <h1 className="text-3xl font-bold text-white mb-6">My Wallet</h1>

        {(isTestUser || isAdmin) && (
          <div className="bg-blue-500/10 border border-blue-500/50 rounded-lg p-4 mb-6">
            <div className="flex gap-3">
              <Shield className="text-blue-400 flex-shrink-0" size={24} />
              <div className="text-blue-200">
                <p className="font-semibold mb-1">
                  {isAdmin ? 'Admin Account' : 'Test Account'}
                </p>
                <p className="text-sm">
                  This account has special privileges for testing. Monetization requirements are bypassed.
                </p>
              </div>
            </div>
          </div>
        )}

        <div className="flex gap-2 mb-6 border-b border-slate-700">
          <button
            onClick={() => setActiveTab('overview')}
            className={`px-4 py-2 font-medium transition-colors ${
              activeTab === 'overview'
                ? 'text-cyan-400 border-b-2 border-cyan-400'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            Overview
          </button>
          <button
            onClick={() => setActiveTab('transactions')}
            className={`px-4 py-2 font-medium transition-colors ${
              activeTab === 'transactions'
                ? 'text-cyan-400 border-b-2 border-cyan-400'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            Transactions
          </button>
          <button
            onClick={() => setActiveTab('withdrawals')}
            className={`px-4 py-2 font-medium transition-colors ${
              activeTab === 'withdrawals'
                ? 'text-cyan-400 border-b-2 border-cyan-400'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            Withdrawals
          </button>
        </div>

        {!isVerified && (
          <div className="bg-yellow-500/10 border border-yellow-500/50 rounded-lg p-4 mb-6">
            <div className="flex gap-3">
              <AlertCircle className="text-yellow-400 flex-shrink-0" size={24} />
              <div className="text-yellow-200">
                <p className="font-semibold mb-1">Verification Required</p>
                <p className="text-sm">Please verify your account in Settings to enable monetization features.</p>
              </div>
            </div>
          </div>
        )}

        <div className="bg-gradient-to-r from-cyan-500 to-orange-500 rounded-2xl p-6 mb-6">
          <p className="text-white/80 text-sm mb-2">Total Balance</p>
          <p className="text-white text-4xl font-bold mb-2">${totalBalance.toFixed(2)}</p>
          {lockedBalance > 0 && (
            <div className="flex items-center gap-2 text-white/80 text-sm mb-4">
              <Lock size={16} />
              <span>Available: ${availableBalance.toFixed(2)}</span>
              <span className="mx-1">•</span>
              <span>Locked: ${lockedBalance.toFixed(2)}</span>
            </div>
          )}
          <div className="flex gap-4 text-white/90 text-sm">
            <div>
              <p className="font-medium">Total Earned</p>
              <p className="text-2xl font-bold">${(earnings?.total_earnings || 0).toFixed(2)}</p>
            </div>
            <div>
              <p className="font-medium">Total Withdrawn</p>
              <p className="text-2xl font-bold">${(earnings?.total_withdrawn || 0).toFixed(2)}</p>
            </div>
          </div>
        </div>

        {activeTab === 'overview' && (
          <>
            <div className="bg-cyan-500/10 border border-cyan-500/50 rounded-lg p-4 mb-6">
              <div className="flex gap-2 mb-2">
                <Calendar className="text-cyan-400 flex-shrink-0" size={20} />
                <div className="text-sm text-cyan-200">
                  <p className="font-semibold mb-1">Payout Schedule</p>
                  <p>• Gift payouts: Processed weekly (Fridays)</p>
                  <p>• View payouts: Processed monthly (20th-25th)</p>
                </div>
              </div>
            </div>

        {isVerified && isEligibleRegion && !meetsRequirements && (
          <div className="bg-slate-800/50 backdrop-blur-lg rounded-xl border border-slate-700 p-6 mb-6">
            <div className="flex items-center gap-3 mb-4">
              <Award className="text-cyan-400" size={28} />
              <div>
                <h2 className="text-xl font-bold text-white">Monetization Requirements</h2>
                <p className="text-slate-400 text-sm">Complete all three to start earning from views</p>
              </div>
            </div>

            <div className="space-y-4">
              <div>
                <div className="flex items-center justify-between mb-2">
                  <div className="flex items-center gap-2">
                    <Eye className="text-purple-400" size={20} />
                    <span className="text-white font-medium">1,000,000 Total Views</span>
                  </div>
                  <span className="text-slate-400 text-sm">
                    {viewsRemaining > 0 ? `${viewsRemaining.toLocaleString()} remaining` : '✓ Complete'}
                  </span>
                </div>
                <div className="w-full bg-slate-700 rounded-full h-2">
                  <div
                    className="bg-purple-500 h-2 rounded-full transition-all duration-500"
                    style={{ width: `${viewsProgress}%` }}
                  />
                </div>
                <p className="text-xs text-slate-500 mt-1">
                  {(eligibility?.total_views || 0).toLocaleString()} views
                </p>
              </div>

              <div>
                <div className="flex items-center justify-between mb-2">
                  <div className="flex items-center gap-2">
                    <Heart className="text-pink-400" size={20} />
                    <span className="text-white font-medium">20,000 Total Likes</span>
                  </div>
                  <span className="text-slate-400 text-sm">
                    {likesRemaining > 0 ? `${likesRemaining.toLocaleString()} remaining` : '✓ Complete'}
                  </span>
                </div>
                <div className="w-full bg-slate-700 rounded-full h-2">
                  <div
                    className="bg-pink-500 h-2 rounded-full transition-all duration-500"
                    style={{ width: `${likesProgress}%` }}
                  />
                </div>
                <p className="text-xs text-slate-500 mt-1">
                  {(eligibility?.total_likes || 0).toLocaleString()} likes
                </p>
              </div>

              <div>
                <div className="flex items-center justify-between mb-2">
                  <div className="flex items-center gap-2">
                    <Users className="text-blue-400" size={20} />
                    <span className="text-white font-medium">10,000 Followers</span>
                  </div>
                  <span className="text-slate-400 text-sm">
                    {followersRemaining > 0 ? `${followersRemaining.toLocaleString()} remaining` : '✓ Complete'}
                  </span>
                </div>
                <div className="w-full bg-slate-700 rounded-full h-2">
                  <div
                    className="bg-blue-500 h-2 rounded-full transition-all duration-500"
                    style={{ width: `${followersProgress}%` }}
                  />
                </div>
                <p className="text-xs text-slate-500 mt-1">
                  {(eligibility?.total_followers || 0).toLocaleString()} followers
                </p>
              </div>
            </div>

            <div className="mt-4 p-3 bg-cyan-500/10 border border-cyan-500/30 rounded-lg">
              <p className="text-cyan-300 text-xs">
                <Shield className="inline mr-1" size={14} />
                Only legitimate views, likes, and followers count toward requirements. Bot activity is automatically detected and excluded.
              </p>
            </div>
          </div>
        )}

        <div className="grid md:grid-cols-2 gap-4 mb-6">
          <div className="bg-slate-800/50 backdrop-blur-lg rounded-xl border border-slate-700 p-6">
            <div className="flex items-center gap-3 mb-4">
              <div className="p-3 bg-purple-500/20 rounded-lg">
                <TrendingUp className="text-purple-400" size={24} />
              </div>
              <div>
                <p className="text-slate-400 text-sm">Views Balance</p>
                <p className="text-white text-2xl font-bold">${(earnings?.view_earnings || 0).toFixed(2)}</p>
              </div>
            </div>
            {canWithdrawViews() ? (
              <button
                onClick={() => {
                  setWithdrawType('views');
                  setShowWithdrawModal(true);
                }}
                className="w-full py-2 bg-purple-500 text-white rounded-lg hover:bg-purple-600 transition-colors font-medium"
              >
                Withdraw
              </button>
            ) : (
              <div className="text-xs text-slate-400 p-3 bg-slate-700/50 rounded-lg">
                {!isVerified ? (
                  <p>Please verify your account to enable withdrawals</p>
                ) : !isEligibleRegion ? (
                  <p>View payouts coming soon in your country</p>
                ) : (
                  <p>Complete all requirements above to withdraw view earnings</p>
                )}
              </div>
            )}
          </div>

          <div className="bg-slate-800/50 backdrop-blur-lg rounded-xl border border-slate-700 p-6">
            <div className="flex items-center gap-3 mb-4">
              <div className="p-3 bg-orange-500/20 rounded-lg">
                <Gift className="text-orange-400" size={24} />
              </div>
              <div>
                <p className="text-slate-400 text-sm">Gifts Balance</p>
                <p className="text-white text-2xl font-bold">${(earnings?.gift_earnings || 0).toFixed(2)}</p>
              </div>
            </div>
            <button
              onClick={() => {
                setWithdrawType('gifts');
                setShowWithdrawModal(true);
              }}
              disabled={!isVerified || (earnings?.gift_earnings || 0) < 10}
              className="w-full py-2 bg-orange-500 text-white rounded-lg hover:bg-orange-600 transition-colors font-medium disabled:opacity-50 disabled:cursor-not-allowed"
            >
              Withdraw
            </button>
            {!isVerified && (
              <p className="text-xs text-slate-400 mt-2">Verification required to withdraw</p>
            )}
          </div>
        </div>

            {isVerified && verification && (
              <div className="bg-slate-800/50 backdrop-blur-lg rounded-xl border border-slate-700 p-4 mb-6">
                <div className="flex items-center gap-2 text-green-400 text-sm">
                  <Check size={18} />
                  <span>Verified • {getCountryName(verification.country_code)}</span>
                </div>
              </div>
            )}
          </>
        )}

        {activeTab === 'transactions' && (
          <div className="space-y-4">
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-xl font-bold text-white">Transaction History</h2>
              <p className="text-slate-400 text-sm">{transactions.length} transactions</p>
            </div>

            {transactions.length === 0 ? (
              <div className="bg-slate-800/50 backdrop-blur-lg rounded-xl border border-slate-700 p-12 text-center">
                <DollarSign className="mx-auto text-slate-600 mb-4" size={48} />
                <p className="text-slate-400">No transactions yet</p>
              </div>
            ) : (
              <div className="space-y-3">
                {transactions.map((transaction) => (
                  <div
                    key={transaction.id}
                    className="bg-slate-800/50 backdrop-blur-lg rounded-xl border border-slate-700 p-4"
                  >
                    <div className="flex items-start justify-between gap-4">
                      <div className="flex items-start gap-3 flex-1">
                        <div className="p-2 bg-slate-700/50 rounded-lg">
                          {getTransactionIcon(transaction.type)}
                        </div>
                        <div className="flex-1">
                          <div className="flex items-center gap-2 mb-1">
                            <p className="text-white font-medium capitalize">{transaction.type}</p>
                            {getStatusBadge(transaction.status)}
                          </div>
                          <p className="text-slate-400 text-sm mb-1">
                            {formatDate(transaction.created_at)}
                          </p>
                          <p className="text-slate-500 text-xs font-mono">
                            {transaction.reference_id}
                          </p>
                        </div>
                      </div>
                      <div className="text-right">
                        <p className={`text-lg font-bold ${
                          transaction.type === 'withdrawal' ? 'text-red-400' : 'text-green-400'
                        }`}>
                          {transaction.type === 'withdrawal' ? '-' : '+'}${transaction.amount.toFixed(2)}
                        </p>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {activeTab === 'withdrawals' && (
          <div className="space-y-4">
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-xl font-bold text-white">Withdrawal Requests</h2>
              <p className="text-slate-400 text-sm">{withdrawalRequests.length} requests</p>
            </div>

            {withdrawalRequests.length === 0 ? (
              <div className="bg-slate-800/50 backdrop-blur-lg rounded-xl border border-slate-700 p-12 text-center">
                <ArrowDownCircle className="mx-auto text-slate-600 mb-4" size={48} />
                <p className="text-slate-400">No withdrawal requests yet</p>
              </div>
            ) : (
              <div className="space-y-3">
                {withdrawalRequests.map((request) => (
                  <div
                    key={request.id}
                    className="bg-slate-800/50 backdrop-blur-lg rounded-xl border border-slate-700 p-4"
                  >
                    <div className="flex items-start justify-between gap-4 mb-3">
                      <div className="flex items-start gap-3 flex-1">
                        <div className="p-2 bg-slate-700/50 rounded-lg">
                          <ArrowDownCircle className="text-red-400" size={20} />
                        </div>
                        <div className="flex-1">
                          <div className="flex items-center gap-2 mb-1">
                            <p className="text-white font-medium">Withdrawal Request</p>
                            {getStatusBadge(request.status)}
                          </div>
                          <p className="text-slate-400 text-sm mb-1">
                            Method: {request.method}
                          </p>
                          <p className="text-slate-500 text-xs">
                            Requested: {formatDate(request.created_at)}
                          </p>
                          {request.processed_at && (
                            <p className="text-slate-500 text-xs">
                              Processed: {formatDate(request.processed_at)}
                            </p>
                          )}
                        </div>
                      </div>
                      <div className="text-right">
                        <p className="text-2xl font-bold text-white">
                          ${request.amount.toFixed(2)}
                        </p>
                      </div>
                    </div>

                    {request.status === 'pending' && (
                      <div className="mt-3 p-3 bg-yellow-500/10 border border-yellow-500/30 rounded-lg">
                        <p className="text-yellow-300 text-sm flex items-center gap-2">
                          <Lock size={14} />
                          This amount is currently locked and will be processed soon
                        </p>
                      </div>
                    )}

                    {request.status === 'approved' && (
                      <div className="mt-3 p-3 bg-green-500/10 border border-green-500/30 rounded-lg">
                        <p className="text-green-300 text-sm flex items-center gap-2">
                          <CheckCircle size={14} />
                          Approved - Funds will be sent to your {request.method} account
                        </p>
                      </div>
                    )}

                    {request.status === 'rejected' && (
                      <div className="mt-3 p-3 bg-red-500/10 border border-red-500/30 rounded-lg">
                        <p className="text-red-300 text-sm flex items-center gap-2">
                          <XCircle size={14} />
                          Request was rejected - Funds returned to your balance
                        </p>
                      </div>
                    )}
                  </div>
                ))}
              </div>
            )}
          </div>
        )}
      </div>

      {showWithdrawModal && (
        <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-slate-900 rounded-2xl max-w-md w-full p-6 border border-slate-700">
            <h2 className="text-white font-semibold text-xl mb-4">
              Withdraw {withdrawType === 'views' ? 'Views' : 'Gifts'} Balance
            </h2>

            <form onSubmit={handleWithdraw} className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-slate-300 mb-2">
                  Amount (USD)
                </label>
                <input
                  type="number"
                  value={amount}
                  onChange={(e) => setAmount(e.target.value)}
                  className="w-full px-4 py-3 bg-slate-800 border border-slate-700 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-cyan-500"
                  placeholder="10.00"
                  min="10"
                  step="0.01"
                  required
                />
                <p className="text-xs text-slate-500 mt-1">Minimum withdrawal: $10</p>
              </div>

              <div>
                <label className="block text-sm font-medium text-slate-300 mb-2">
                  Payment Method
                </label>
                <select
                  value={paymentMethod}
                  onChange={(e) => setPaymentMethod(e.target.value)}
                  className="w-full px-4 py-3 bg-slate-800 border border-slate-700 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-cyan-500"
                  required
                >
                  <option value="">Select method</option>
                  {getPaymentMethods().map((method) => (
                    <option key={method} value={method}>{method}</option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium text-slate-300 mb-2">
                  Account Details
                </label>
                <input
                  type="text"
                  value={paymentDetails}
                  onChange={(e) => setPaymentDetails(e.target.value)}
                  className="w-full px-4 py-3 bg-slate-800 border border-slate-700 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-cyan-500"
                  placeholder="Phone number / Account ID"
                  required
                />
              </div>

              <div className="flex gap-3 pt-2">
                <button
                  type="button"
                  onClick={() => setShowWithdrawModal(false)}
                  className="flex-1 px-4 py-3 bg-slate-800 text-white rounded-lg hover:bg-slate-700 transition-colors"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="flex-1 px-4 py-3 bg-gradient-to-r from-cyan-500 to-orange-500 text-white rounded-lg hover:from-cyan-600 hover:to-orange-600 transition-all"
                >
                  Submit Request
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
