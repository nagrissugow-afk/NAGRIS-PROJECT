import { ArrowLeft } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

export default function PrivacyPolicyPage() {
  const navigate = useNavigate();

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-blue-900 to-slate-900 pb-20">
      <div className="max-w-4xl mx-auto">
        <div className="sticky top-0 bg-slate-900/80 backdrop-blur-lg border-b border-slate-700 px-4 py-4 flex items-center gap-4 z-10">
          <button
            onClick={() => navigate(-1)}
            className="text-white hover:bg-slate-700/50 p-2 rounded-lg transition-colors"
          >
            <ArrowLeft size={24} />
          </button>
          <h1 className="text-xl font-bold text-white">Privacy Policy</h1>
        </div>

        <div className="px-4 py-8 space-y-6 text-slate-300">
          <div className="bg-slate-800/50 backdrop-blur-lg rounded-2xl border border-slate-700 p-6 space-y-4">
            <p className="text-sm text-slate-400">Last Updated: December 2024</p>

            <section>
              <h2 className="text-xl font-bold text-white mb-3">1. Information We Collect</h2>
              <p className="mb-2">We collect the following information:</p>
              <ul className="list-disc list-inside space-y-1 ml-4">
                <li>Account information (email, username, password)</li>
                <li>Profile information (bio, avatar, country)</li>
                <li>Content you create (videos, comments, likes)</li>
                <li>Usage data (watch history, interactions)</li>
                <li>Device and technical information</li>
              </ul>
            </section>

            <section>
              <h2 className="text-xl font-bold text-white mb-3">2. How We Use Your Information</h2>
              <p className="mb-2">Your information is used to:</p>
              <ul className="list-disc list-inside space-y-1 ml-4">
                <li>Provide and improve our services</li>
                <li>Personalize your experience</li>
                <li>Process monetization and payments</li>
                <li>Ensure platform security and safety</li>
                <li>Communicate important updates</li>
                <li>Comply with legal obligations</li>
              </ul>
            </section>

            <section>
              <h2 className="text-xl font-bold text-white mb-3">3. Information Sharing</h2>
              <p className="mb-2">We do not sell your personal information. We may share data with:</p>
              <ul className="list-disc list-inside space-y-1 ml-4">
                <li>Service providers who assist in platform operations</li>
                <li>Payment processors for monetization</li>
                <li>Law enforcement when legally required</li>
                <li>Other users as part of platform features (public profiles, videos)</li>
              </ul>
            </section>

            <section>
              <h2 className="text-xl font-bold text-white mb-3">4. Data Security</h2>
              <p>We implement industry-standard security measures to protect your data, including encryption, secure authentication, and regular security audits.</p>
            </section>

            <section>
              <h2 className="text-xl font-bold text-white mb-3">5. Your Privacy Rights</h2>
              <p className="mb-2">You have the right to:</p>
              <ul className="list-disc list-inside space-y-1 ml-4">
                <li>Access your personal data</li>
                <li>Correct inaccurate information</li>
                <li>Delete your account and data</li>
                <li>Control privacy settings</li>
                <li>Opt out of certain data collection</li>
                <li>Export your data</li>
              </ul>
            </section>

            <section>
              <h2 className="text-xl font-bold text-white mb-3">6. Cookies and Tracking</h2>
              <p>We use cookies and similar technologies to enhance user experience, analyze usage, and maintain session security. You can control cookie settings through your browser.</p>
            </section>

            <section>
              <h2 className="text-xl font-bold text-white mb-3">7. Data Retention</h2>
              <p>We retain your data as long as your account is active or as needed to provide services. Deleted data is removed within 90 days, except where required by law.</p>
            </section>

            <section>
              <h2 className="text-xl font-bold text-white mb-3">8. Children's Privacy</h2>
              <p>Nagris is not intended for users under 13 years of age. We do not knowingly collect data from children under 13.</p>
            </section>

            <section>
              <h2 className="text-xl font-bold text-white mb-3">9. International Data Transfers</h2>
              <p>Your data may be processed in countries where our servers and service providers operate. We ensure appropriate safeguards are in place.</p>
            </section>

            <section>
              <h2 className="text-xl font-bold text-white mb-3">10. Third-Party Services</h2>
              <p>Our platform may integrate with third-party services. Those services have their own privacy policies which we encourage you to review.</p>
            </section>

            <section>
              <h2 className="text-xl font-bold text-white mb-3">11. Changes to Privacy Policy</h2>
              <p>We may update this policy periodically. We will notify you of significant changes through the platform or email.</p>
            </section>

            <section>
              <h2 className="text-xl font-bold text-white mb-3">12. Contact Us</h2>
              <p>For privacy questions or to exercise your rights, contact us through the Support section in Settings.</p>
            </section>
          </div>
        </div>
      </div>
    </div>
  );
}
