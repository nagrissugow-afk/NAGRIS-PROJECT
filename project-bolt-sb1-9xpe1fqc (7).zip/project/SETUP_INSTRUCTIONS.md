# Setup Instructions - Custom Authentication System

## Quick Start

### 1. Apply Database Migration

The new authentication system requires a fresh database schema. Apply the migration:

```bash
# The migration file is located at:
supabase/migrations/20251018000001_create_standalone_auth.sql
```

This migration will:
- Drop the old users table (linked to Supabase Auth)
- Create a new standalone users table with password_hash field
- Recreate all dependent tables (videos, comments, follows, etc.)
- Set up proper indexes and RLS policies

**⚠️ WARNING**: This will delete all existing user data. Back up if needed!

### 2. Deploy Edge Function

Deploy the authentication Edge Function to Supabase:

The auth function is located at:
```
supabase/functions/auth/index.ts
```

This Edge Function handles:
- POST /auth/signup - User registration
- POST /auth/login - User authentication
- POST /auth/forgot-password - Password reset request
- POST /auth/reset-password - Password reset completion
- GET /auth/me - Get current user

### 3. Configure Environment Variables

Ensure your `.env` file has:

```env
VITE_SUPABASE_URL=your_supabase_project_url
VITE_SUPABASE_ANON_KEY=your_supabase_anon_key
SUPABASE_SERVICE_ROLE_KEY=your_service_role_key
JWT_SECRET=your-super-secret-jwt-key-change-in-production
```

**Important**: Generate a strong JWT_SECRET for production!

### 4. Install Dependencies

```bash
npm install
```

### 5. Build and Run

```bash
# Development
npm run dev

# Production build
npm run build
```

## Testing the System

### Test Signup Flow

1. Open the application (you'll see the auth page)
2. Click "Don't have an account? Sign up"
3. Fill in:
   - Username: `testuser`
   - Email: `test@example.com`
   - Password: `password123`
4. Click "Sign Up"
5. You should be redirected to the home page
6. Check browser localStorage for `auth_token` and `auth_user`

### Test Login Flow

1. Logout (if logged in)
2. Enter email: `test@example.com`
3. Enter password: `password123`
4. Click "Log In"
5. You should be redirected to home page

### Test Protected Routes

1. **While Logged Out**:
   - Try to access `/upload` → Redirected to home
   - Try to access `/wallet` → Redirected to home
   - Try to access `/profile` → Redirected to home

2. **While Logged In**:
   - Access `/upload` → Success
   - Access `/wallet` → Success
   - Access `/profile` → Success

### Test Session Persistence

1. Login to the application
2. Refresh the browser page
3. You should remain logged in
4. Close browser and reopen
5. Navigate to the app
6. You should still be logged in

### Test Logout

1. While logged in, click logout button
2. localStorage should be cleared
3. You should be redirected to home
4. Protected routes should be inaccessible

### Test Password Reset

1. On login page, click "Forgot password?"
2. Enter your email
3. Click "Send Reset Link"
4. Check browser console logs for reset token
5. Copy the token (in production, this would be in email)
6. The form will automatically show reset password page
7. Enter the token and new password
8. Submit
9. Try logging in with new password

## Verification Checklist

- [ ] Database migration applied successfully
- [ ] Auth Edge Function deployed
- [ ] Environment variables configured
- [ ] Application builds without errors
- [ ] Can create new account
- [ ] Cannot create duplicate email/username
- [ ] Can login with correct credentials
- [ ] Cannot login with wrong credentials
- [ ] Session persists across page refreshes
- [ ] Logout clears session
- [ ] Protected routes require authentication
- [ ] Password reset flow works

## Common Issues

### Edge Function Not Found (404)

**Cause**: Auth Edge Function not deployed

**Solution**: Deploy the function using Supabase CLI or dashboard

### "Invalid or expired reset token"

**Cause**: Reset token expired (1 hour limit) or already used

**Solution**: Request a new password reset

### "Unauthorized" Error

**Cause**: JWT token missing, invalid, or expired

**Solution**: Login again to get a fresh token

### Build Errors

**Cause**: TypeScript or import errors

**Solution**:
```bash
npm install
npm run build
```

### Cannot Access Protected Routes

**Cause**: Not logged in or token expired

**Solution**: Login to get valid session

## Production Deployment

### Before Going Live:

1. **Change JWT_SECRET**
   ```bash
   # Generate strong secret
   openssl rand -base64 32
   ```

2. **Set Up Email Service**
   - Replace console.log in forgot-password endpoint
   - Use SendGrid, AWS SES, Mailgun, etc.
   - Create email templates

3. **Enable HTTPS**
   - Configure SSL certificate
   - Force HTTPS redirects
   - Update CORS settings

4. **Add Rate Limiting**
   - Limit login attempts
   - Prevent brute force attacks
   - Add IP blocking for suspicious activity

5. **Set Up Monitoring**
   - Error tracking (Sentry, etc.)
   - Performance monitoring
   - User analytics

6. **Database Backups**
   - Enable automatic backups
   - Test restore procedures
   - Document backup strategy

## API Endpoints

### Base URL
```
https://your-project.supabase.co/functions/v1/auth
```

### Endpoints

**POST /signup**
```json
{
  "username": "johndoe",
  "email": "john@example.com",
  "password": "password123"
}
```

**POST /login**
```json
{
  "email": "john@example.com",
  "password": "password123"
}
```

**POST /forgot-password**
```json
{
  "email": "john@example.com"
}
```

**POST /reset-password**
```json
{
  "token": "reset-token-here",
  "newPassword": "newpassword123"
}
```

**GET /me**
```
Authorization: Bearer your-jwt-token
```

## Support

For detailed documentation, see `AUTH_SYSTEM_DOCUMENTATION.md`

For technical issues:
1. Check browser console for errors
2. Verify environment variables
3. Test with fresh signup/login
4. Review Edge Function logs in Supabase dashboard
