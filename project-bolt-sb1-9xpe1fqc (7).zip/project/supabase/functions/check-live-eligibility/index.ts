import { createClient } from 'npm:@supabase/supabase-js@2.57.4';
import { crypto } from 'https://deno.land/std@0.177.0/crypto/mod.ts';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, OPTIONS',
  'Access-Control-Allow-Headers': 'Content-Type, Authorization, X-Client-Info, Apikey',
};

interface User {
  id: string;
  is_admin: boolean;
  is_test_account: boolean;
  is_verified: boolean;
  followers_count: number;
}

async function hashPassword(password: string): Promise<string> {
  const encoder = new TextEncoder();
  const data = encoder.encode(password);
  const hashBuffer = await crypto.subtle.digest('SHA-256', data);
  const hashArray = Array.from(new Uint8Array(hashBuffer));
  return hashArray.map(b => b.toString(16).padStart(2, '0')).join('');
}

Deno.serve(async (req: Request) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, {
      status: 200,
      headers: corsHeaders,
    });
  }

  try {
    const authHeader = req.headers.get('Authorization');
    if (!authHeader || !authHeader.startsWith('Bearer ')) {
      return new Response(
        JSON.stringify({ eligible: false, error: 'Unauthorized' }),
        {
          status: 401,
          headers: {
            ...corsHeaders,
            'Content-Type': 'application/json',
          },
        }
      );
    }

    const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
    const supabaseKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
    const supabase = createClient(supabaseUrl, supabaseKey);

    const token = authHeader.substring(7);
    const tokenHash = await hashPassword(token);

    const { data: session, error: sessionError } = await supabase
      .from('sessions')
      .select('user_id, expires_at')
      .eq('token_hash', tokenHash)
      .maybeSingle();

    if (sessionError || !session) {
      return new Response(
        JSON.stringify({ eligible: false, error: 'Invalid or expired session' }),
        {
          status: 401,
          headers: {
            ...corsHeaders,
            'Content-Type': 'application/json',
          },
        }
      );
    }

    if (new Date(session.expires_at) < new Date()) {
      return new Response(
        JSON.stringify({ eligible: false, error: 'Session expired' }),
        {
          status: 401,
          headers: {
            ...corsHeaders,
            'Content-Type': 'application/json',
          },
        }
      );
    }

    const { data: user, error: userError } = await supabase
      .from('users')
      .select('id, is_admin, is_test_account, is_verified, followers_count')
      .eq('id', session.user_id)
      .maybeSingle();

    if (userError || !user) {
      return new Response(
        JSON.stringify({ eligible: false, error: 'User not found' }),
        {
          status: 404,
          headers: {
            ...corsHeaders,
            'Content-Type': 'application/json',
          },
        }
      );
    }

    const isAdmin = user.is_admin === true;
    const isTestAccount = user.is_test_account === true;
    const isVerified = user.is_verified === true;
    const hasEnoughFollowers = (user.followers_count || 0) >= 500;

    const eligible = isAdmin || isTestAccount || isVerified || hasEnoughFollowers;

    if (!eligible) {
      return new Response(
        JSON.stringify({
          eligible: false,
          error: 'Need 500 followers to start live streaming.',
        }),
        {
          status: 403,
          headers: {
            ...corsHeaders,
            'Content-Type': 'application/json',
          },
        }
      );
    }

    return new Response(
      JSON.stringify({
        eligible: true,
        reason: isAdmin ? 'admin' : isTestAccount ? 'test_account' : isVerified ? 'verified' : 'followers',
      }),
      {
        status: 200,
        headers: {
          ...corsHeaders,
          'Content-Type': 'application/json',
        },
      }
    );
  } catch (err) {
    console.error('Error checking live eligibility:', err);
    return new Response(
      JSON.stringify({ eligible: false, error: 'Internal server error' }),
      {
        status: 500,
        headers: {
          ...corsHeaders,
          'Content-Type': 'application/json',
        },
      }
    );
  }
});
