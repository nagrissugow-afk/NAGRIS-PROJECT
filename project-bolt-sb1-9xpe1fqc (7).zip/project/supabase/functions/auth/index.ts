import { createClient } from 'npm:@supabase/supabase-js@2';
import { crypto } from 'https://deno.land/std@0.177.0/crypto/mod.ts';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, OPTIONS',
  'Access-Control-Allow-Headers': 'Content-Type, Authorization, X-Client-Info, Apikey',
};

const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
const supabaseKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
const supabase = createClient(supabaseUrl, supabaseKey);

async function hashPassword(password: string): Promise<string> {
  const encoder = new TextEncoder();
  const data = encoder.encode(password);
  const hashBuffer = await crypto.subtle.digest('SHA-256', data);
  const hashArray = Array.from(new Uint8Array(hashBuffer));
  return hashArray.map(b => b.toString(16).padStart(2, '0')).join('');
}

async function generateToken(): Promise<string> {
  const array = new Uint8Array(32);
  crypto.getRandomValues(array);
  return Array.from(array, b => b.toString(16).padStart(2, '0')).join('');
}

Deno.serve(async (req: Request) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { status: 200, headers: corsHeaders });
  }

  try {
    const url = new URL(req.url);
    const path = url.pathname;

    if (path.endsWith('/login')) {
      const { email, password } = await req.json();

      const passwordHash = await hashPassword(password);

      const { data: user, error: userError } = await supabase
        .from('users')
        .select('*')
        .eq('email', email)
        .eq('password_hash', passwordHash)
        .maybeSingle();

      if (userError || !user) {
        return new Response(
          JSON.stringify({ error: true, message: 'Invalid credentials' }),
          { status: 401, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      }

      const accessToken = await generateToken();
      const refreshToken = await generateToken();
      const expiresAt = new Date(Date.now() + 7 * 24 * 60 * 60 * 1000);
      const refreshExpiresAt = new Date(Date.now() + 30 * 24 * 60 * 60 * 1000);

      const tokenHash = await hashPassword(accessToken);
      const refreshTokenHash = await hashPassword(refreshToken);

      await supabase.from('sessions').insert({
        user_id: user.id,
        token_hash: tokenHash,
        refresh_token_hash: refreshTokenHash,
        expires_at: expiresAt.toISOString(),
        refresh_expires_at: refreshExpiresAt.toISOString(),
        ip_address: req.headers.get('x-forwarded-for') || 'unknown',
        device_info: { userAgent: req.headers.get('user-agent') || 'unknown' },
      });

      const { data: wallet } = await supabase
        .from('wallet')
        .select('balance, total_earned, total_withdrawn')
        .eq('user_id', user.id)
        .maybeSingle();

      return new Response(
        JSON.stringify({
          success: true,
          user: {
            ...user,
            wallet_balance: wallet?.balance || 0,
            total_earned: wallet?.total_earned || 0,
            total_withdrawn: wallet?.total_withdrawn || 0,
          },
          access_token: accessToken,
          refresh_token: refreshToken,
        }),
        { status: 200, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    if (path.endsWith('/signup')) {
      const { email, password, username, country, avatar_url, bio } = await req.json();

      const { data: existingUser } = await supabase
        .from('users')
        .select('id')
        .or(`email.eq.${email},username.eq.${username}`)
        .maybeSingle();

      if (existingUser) {
        return new Response(
          JSON.stringify({ error: true, message: 'Email or username already exists' }),
          { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      }

      const passwordHash = await hashPassword(password);

      const { data: newUser, error: insertError } = await supabase
        .from('users')
        .insert({
          email,
          username,
          password_hash: passwordHash,
          country,
          avatar_url,
          bio,
          email_verified: false,
        })
        .select()
        .single();

      if (insertError || !newUser) {
        return new Response(
          JSON.stringify({ error: true, message: 'Failed to create user' }),
          { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      }

      await supabase.from('wallet').insert({
        user_id: newUser.id,
        balance: 0,
        total_earned: 0,
        total_withdrawn: 0,
        pending: 0,
      });

      const accessToken = await generateToken();
      const refreshToken = await generateToken();
      const expiresAt = new Date(Date.now() + 7 * 24 * 60 * 60 * 1000);
      const refreshExpiresAt = new Date(Date.now() + 30 * 24 * 60 * 60 * 1000);

      const tokenHash = await hashPassword(accessToken);
      const refreshTokenHash = await hashPassword(refreshToken);

      await supabase.from('sessions').insert({
        user_id: newUser.id,
        token_hash: tokenHash,
        refresh_token_hash: refreshTokenHash,
        expires_at: expiresAt.toISOString(),
        refresh_expires_at: refreshExpiresAt.toISOString(),
        ip_address: req.headers.get('x-forwarded-for') || 'unknown',
        device_info: { userAgent: req.headers.get('user-agent') || 'unknown' },
      });

      return new Response(
        JSON.stringify({
          success: true,
          user: newUser,
          access_token: accessToken,
          refresh_token: refreshToken,
        }),
        { status: 201, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    if (path.endsWith('/logout')) {
      const authHeader = req.headers.get('Authorization');
      if (authHeader?.startsWith('Bearer ')) {
        const token = authHeader.substring(7);
        const tokenHash = await hashPassword(token);
        await supabase.from('sessions').delete().eq('token_hash', tokenHash);
      }

      return new Response(
        JSON.stringify({ success: true, message: 'Logged out' }),
        { status: 200, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    if (path.endsWith('/countries')) {
      const countries = [
        'United States', 'United Kingdom', 'Canada', 'Australia', 'Germany',
        'France', 'Spain', 'Italy', 'Netherlands', 'Belgium', 'Switzerland',
        'Sweden', 'Norway', 'Denmark', 'Finland', 'Austria', 'Ireland',
        'Portugal', 'Greece', 'Poland', 'Czech Republic', 'Hungary',
        'Romania', 'Bulgaria', 'Croatia', 'Slovakia', 'Slovenia',
        'Estonia', 'Latvia', 'Lithuania', 'Iceland', 'Luxembourg',
        'Malta', 'Cyprus', 'Japan', 'South Korea', 'Singapore',
        'New Zealand', 'Israel', 'United Arab Emirates', 'Saudi Arabia',
        'India', 'Brazil', 'Mexico', 'Argentina', 'Chile', 'Colombia',
        'South Africa', 'Nigeria', 'Kenya', 'Egypt', 'Morocco',
      ];

      return new Response(
        JSON.stringify({ success: true, countries }),
        { status: 200, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    return new Response(
      JSON.stringify({ error: true, message: 'Not found' }),
      { status: 404, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  } catch (error) {
    return new Response(
      JSON.stringify({ error: true, message: error.message }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
});