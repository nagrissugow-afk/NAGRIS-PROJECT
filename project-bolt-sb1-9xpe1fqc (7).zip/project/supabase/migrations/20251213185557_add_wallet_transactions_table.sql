/*
  # Add Wallet Transactions Table

  ## New Table
  
  ### `wallet_transactions`
  Tracks all wallet activity including gifts, views revenue, and withdrawals
  - `id` (uuid, primary key)
  - `user_id` (uuid, foreign key to users)
  - `type` (text) - 'gift', 'views', 'withdrawal', 'deposit'
  - `amount` (numeric) - transaction amount
  - `status` (text) - 'pending', 'completed', 'failed', 'cancelled'
  - `reference_id` (text) - unique reference for tracking
  - `metadata` (jsonb) - additional details
  - `created_at` (timestamptz)
  - `updated_at` (timestamptz)

  ## Updates to Existing Tables
  
  ### `users` table
  - Add `locked_balance` (numeric) - amount locked in pending withdrawals

  ## Security
  - Enable RLS on wallet_transactions
  - Users can read their own transactions
  - Admins can view all transactions
*/

-- Add locked_balance to users table
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'users' AND column_name = 'locked_balance'
  ) THEN
    ALTER TABLE users ADD COLUMN locked_balance numeric DEFAULT 0 CHECK (locked_balance >= 0);
  END IF;
END $$;

-- Create wallet_transactions table
CREATE TABLE IF NOT EXISTS wallet_transactions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES users(id) ON DELETE CASCADE NOT NULL,
  type text NOT NULL CHECK (type IN ('gift', 'views', 'withdrawal', 'deposit')),
  amount numeric NOT NULL CHECK (amount > 0),
  status text NOT NULL DEFAULT 'completed' CHECK (status IN ('pending', 'completed', 'failed', 'cancelled')),
  reference_id text UNIQUE NOT NULL,
  metadata jsonb DEFAULT '{}',
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create indexes
CREATE INDEX IF NOT EXISTS idx_wallet_transactions_user_id ON wallet_transactions(user_id);
CREATE INDEX IF NOT EXISTS idx_wallet_transactions_created_at ON wallet_transactions(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_wallet_transactions_type ON wallet_transactions(type);
CREATE INDEX IF NOT EXISTS idx_wallet_transactions_status ON wallet_transactions(status);

-- Enable RLS
ALTER TABLE wallet_transactions ENABLE ROW LEVEL SECURITY;

-- Drop existing policies if they exist
DROP POLICY IF EXISTS "Users can view own transactions" ON wallet_transactions;
DROP POLICY IF EXISTS "Admins can view all transactions" ON wallet_transactions;
DROP POLICY IF EXISTS "System can insert transactions" ON wallet_transactions;
DROP POLICY IF EXISTS "Admins can update transaction status" ON wallet_transactions;

-- RLS Policies for wallet_transactions
CREATE POLICY "Users can view own transactions"
  ON wallet_transactions FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id OR EXISTS (
    SELECT 1 FROM users
    WHERE users.id = auth.uid()
    AND users.is_admin = true
  ));

CREATE POLICY "System can insert transactions"
  ON wallet_transactions FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Admins can update transactions"
  ON wallet_transactions FOR UPDATE
  TO authenticated
  USING (EXISTS (
    SELECT 1 FROM users
    WHERE users.id = auth.uid()
    AND users.is_admin = true
  ))
  WITH CHECK (EXISTS (
    SELECT 1 FROM users
    WHERE users.id = auth.uid()
    AND users.is_admin = true
  ));

-- Function to create transaction from gift
CREATE OR REPLACE FUNCTION record_gift_transaction(
  p_sender_id uuid,
  p_recipient_id uuid,
  p_amount numeric,
  p_gift_id text DEFAULT NULL,
  p_room_id uuid DEFAULT NULL
)
RETURNS uuid AS $$
DECLARE
  v_transaction_id uuid;
  v_ref_id text;
BEGIN
  v_ref_id := 'GIFT-' || COALESCE(p_gift_id, gen_random_uuid()::text);
  
  INSERT INTO wallet_transactions (
    user_id,
    type,
    amount,
    status,
    reference_id,
    metadata
  ) VALUES (
    p_recipient_id,
    'gift',
    p_amount,
    'completed',
    v_ref_id,
    jsonb_build_object(
      'sender_id', p_sender_id,
      'gift_id', p_gift_id,
      'room_id', p_room_id
    )
  ) RETURNING id INTO v_transaction_id;
  
  RETURN v_transaction_id;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Function to update withdrawal_requests and create transaction
CREATE OR REPLACE FUNCTION handle_withdrawal_request()
RETURNS TRIGGER AS $$
DECLARE
  v_available_balance numeric;
  v_ref_id text;
BEGIN
  IF TG_OP = 'INSERT' THEN
    -- Check available balance
    SELECT (w.balance - COALESCE(u.locked_balance, 0))
    INTO v_available_balance
    FROM wallet w
    JOIN users u ON u.id = w.user_id
    WHERE w.user_id = NEW.user_id;
    
    IF v_available_balance < NEW.amount THEN
      RAISE EXCEPTION 'Insufficient available balance';
    END IF;
    
    -- Lock the balance
    UPDATE users
    SET locked_balance = COALESCE(locked_balance, 0) + NEW.amount
    WHERE id = NEW.user_id;
    
    -- Update wallet pending
    UPDATE wallet
    SET pending = COALESCE(pending, 0) + NEW.amount,
        updated_at = now()
    WHERE user_id = NEW.user_id;
    
    -- Create transaction record
    v_ref_id := 'WD-' || NEW.id::text;
    INSERT INTO wallet_transactions (
      user_id,
      type,
      amount,
      status,
      reference_id,
      metadata
    ) VALUES (
      NEW.user_id,
      'withdrawal',
      NEW.amount,
      'pending',
      v_ref_id,
      jsonb_build_object(
        'withdrawal_id', NEW.id,
        'method', NEW.method
      )
    );
    
  ELSIF TG_OP = 'UPDATE' AND OLD.status != NEW.status THEN
    -- Handle status change
    IF OLD.status = 'pending' AND NEW.status IN ('approved', 'rejected') THEN
      -- Unlock the balance
      UPDATE users
      SET locked_balance = GREATEST(COALESCE(locked_balance, 0) - OLD.amount, 0)
      WHERE id = OLD.user_id;
      
      IF NEW.status = 'approved' THEN
        -- Deduct from balance
        UPDATE wallet
        SET balance = GREATEST(balance - OLD.amount, 0),
            total_withdrawn = COALESCE(total_withdrawn, 0) + OLD.amount,
            pending = GREATEST(COALESCE(pending, 0) - OLD.amount, 0),
            updated_at = now()
        WHERE user_id = OLD.user_id;
        
        -- Update transaction status
        UPDATE wallet_transactions
        SET status = 'completed',
            updated_at = now()
        WHERE reference_id = 'WD-' || OLD.id::text;
      ELSE
        -- Rejected - return to available balance
        UPDATE wallet
        SET pending = GREATEST(COALESCE(pending, 0) - OLD.amount, 0),
            updated_at = now()
        WHERE user_id = OLD.user_id;
        
        -- Update transaction status
        UPDATE wallet_transactions
        SET status = 'cancelled',
            updated_at = now()
        WHERE reference_id = 'WD-' || OLD.id::text;
      END IF;
    END IF;
  END IF;
  
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Trigger for withdrawal requests
DROP TRIGGER IF EXISTS trigger_handle_withdrawal_request ON withdrawal_requests;
CREATE TRIGGER trigger_handle_withdrawal_request
  BEFORE INSERT OR UPDATE ON withdrawal_requests
  FOR EACH ROW
  EXECUTE FUNCTION handle_withdrawal_request();