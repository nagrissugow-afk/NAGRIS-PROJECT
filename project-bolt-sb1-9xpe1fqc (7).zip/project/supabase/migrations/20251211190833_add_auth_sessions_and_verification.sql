/*
  # Add Authentication Sessions and Email Verification

  ## Changes
  1. Add email verification fields to users table
  2. Add password reset fields to users table
  3. Create sessions table for JWT token management

  ## New Columns on Users Table
    - `email_verified` (boolean) - Whether email has been verified
    - `email_verification_token` (text) - Token for email verification
    - `email_verification_expires` (timestamptz) - When verification token expires
    - `password_reset_token` (text) - Token for password reset
    - `password_reset_expires` (timestamptz) - When reset token expires

  ## New Tables
    - `sessions` - Stores active user sessions with JWT tokens
      - `id` (uuid, primary key)
      - `user_id` (uuid, foreign key to users)
      - `token_hash` (text) - Hashed JWT token for validation
      - `refresh_token_hash` (text) - Hashed refresh token
      - `device_info` (jsonb) - Browser/device information
      - `ip_address` (text) - IP address of session
      - `expires_at` (timestamptz) - When session expires
      - `refresh_expires_at` (timestamptz) - When refresh token expires
      - `created_at` (timestamptz)
      - `last_active_at` (timestamptz)

  ## Security
    - RLS enabled on sessions table
    - Users can only view/delete their own sessions
*/

-- Add email verification fields to users
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'users' AND column_name = 'email_verified'
  ) THEN
    ALTER TABLE users ADD COLUMN email_verified boolean DEFAULT false;
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'users' AND column_name = 'email_verification_token'
  ) THEN
    ALTER TABLE users ADD COLUMN email_verification_token text;
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'users' AND column_name = 'email_verification_expires'
  ) THEN
    ALTER TABLE users ADD COLUMN email_verification_expires timestamptz;
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'users' AND column_name = 'password_reset_token'
  ) THEN
    ALTER TABLE users ADD COLUMN password_reset_token text;
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'users' AND column_name = 'password_reset_expires'
  ) THEN
    ALTER TABLE users ADD COLUMN password_reset_expires timestamptz;
  END IF;
END $$;

-- Create sessions table
CREATE TABLE IF NOT EXISTS sessions (
  id uuid PRIMARY KEY DEFAULT extensions.uuid_generate_v4(),
  user_id uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  token_hash text NOT NULL,
  refresh_token_hash text,
  device_info jsonb DEFAULT '{}',
  ip_address text,
  expires_at timestamptz NOT NULL,
  refresh_expires_at timestamptz,
  created_at timestamptz DEFAULT now(),
  last_active_at timestamptz DEFAULT now()
);

-- Create indexes for performance
CREATE INDEX IF NOT EXISTS idx_sessions_user_id ON sessions(user_id);
CREATE INDEX IF NOT EXISTS idx_sessions_token_hash ON sessions(token_hash);
CREATE INDEX IF NOT EXISTS idx_sessions_expires_at ON sessions(expires_at);
CREATE INDEX IF NOT EXISTS idx_users_email_verification_token ON users(email_verification_token);
CREATE INDEX IF NOT EXISTS idx_users_password_reset_token ON users(password_reset_token);

-- Enable RLS on sessions
ALTER TABLE sessions ENABLE ROW LEVEL SECURITY;

-- Sessions policies
DROP POLICY IF EXISTS "Users can view own sessions" ON sessions;
CREATE POLICY "Users can view own sessions"
  ON sessions FOR SELECT
  USING (user_id = current_setting('app.current_user_id', true)::uuid);

DROP POLICY IF EXISTS "Users can delete own sessions" ON sessions;
CREATE POLICY "Users can delete own sessions"
  ON sessions FOR DELETE
  USING (user_id = current_setting('app.current_user_id', true)::uuid);

DROP POLICY IF EXISTS "System can manage sessions" ON sessions;
CREATE POLICY "System can manage sessions"
  ON sessions FOR ALL
  USING (true)
  WITH CHECK (true);
