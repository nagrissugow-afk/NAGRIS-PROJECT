/*
  # Fix Users Table RLS Policy

  ## Changes
    - Add INSERT policy to allow new user registrations
    - Users can insert their own profile during signup
  
  ## Security
    - Only authenticated users can update their own profile
    - Everyone can view user profiles (public data)
    - Anyone can create a new user account (for signup)
*/

-- Drop existing policies to recreate them
DROP POLICY IF EXISTS "Anyone can view user profiles" ON users;
DROP POLICY IF EXISTS "Users can update own profile" ON users;

-- Allow anyone to view user profiles
CREATE POLICY "Anyone can view user profiles"
  ON users FOR SELECT
  USING (true);

-- Allow new user registration (INSERT without auth)
CREATE POLICY "Anyone can create user account"
  ON users FOR INSERT
  WITH CHECK (true);

-- Allow users to update their own profile
CREATE POLICY "Users can update own profile"
  ON users FOR UPDATE
  USING (id = current_setting('app.current_user_id', true)::uuid)
  WITH CHECK (id = current_setting('app.current_user_id', true)::uuid);
