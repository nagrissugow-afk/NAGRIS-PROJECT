/*
  # Add Automatic Notification System

  ## Overview
  This migration adds automatic notifications for all user interactions
  to ensure users get notified of all relevant activity.

  ## Changes Made

  ### 1. Schema Updates
  - Add `related_comment_id` column to notifications table for comment-related notifications

  ### 2. Notification Trigger Functions
  Creates trigger functions to automatically generate notifications for:
  - **Follow notifications**: When someone follows a user
  - **Video like notifications**: When someone likes a user's video
  - **Comment notifications**: When someone comments on a user's video
  - **Comment reply notifications**: When someone replies to a user's comment
  - **Comment like notifications**: When someone likes a user's comment

  ## Security
  - All triggers run with proper user context
  - Notifications are only created for valid actions
  - Users don't receive notifications for their own actions
*/

-- Add related_comment_id column to notifications table
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'notifications' AND column_name = 'related_comment_id'
  ) THEN
    ALTER TABLE notifications ADD COLUMN related_comment_id uuid REFERENCES comments(id) ON DELETE CASCADE;
    CREATE INDEX IF NOT EXISTS idx_notifications_related_comment_id ON notifications(related_comment_id);
  END IF;
END $$;

-- =====================================================
-- TRIGGER FUNCTION: Follow Notifications
-- =====================================================
CREATE OR REPLACE FUNCTION notify_follow()
RETURNS TRIGGER AS $$
DECLARE
  follower_username text;
BEGIN
  -- Get follower's username
  SELECT username INTO follower_username FROM users WHERE id = NEW.follower_id;

  -- Create notification for the user being followed
  INSERT INTO notifications (user_id, type, title, message, related_user_id)
  VALUES (
    NEW.following_id,
    'follow',
    'New Follower',
    follower_username || ' started following you',
    NEW.follower_id
  );

  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Drop and recreate trigger for follows
DROP TRIGGER IF EXISTS trigger_notify_follow ON follows;
CREATE TRIGGER trigger_notify_follow
  AFTER INSERT ON follows
  FOR EACH ROW
  EXECUTE FUNCTION notify_follow();

-- =====================================================
-- TRIGGER FUNCTION: Video Like Notifications
-- =====================================================
CREATE OR REPLACE FUNCTION notify_video_like()
RETURNS TRIGGER AS $$
DECLARE
  liker_username text;
  video_owner_id uuid;
BEGIN
  -- Only process video likes (not comment likes)
  IF NEW.video_id IS NULL THEN
    RETURN NEW;
  END IF;

  -- Get the video owner
  SELECT user_id INTO video_owner_id FROM videos WHERE id = NEW.video_id;

  -- Don't notify if user likes their own video
  IF video_owner_id = NEW.user_id THEN
    RETURN NEW;
  END IF;

  -- Get liker's username
  SELECT username INTO liker_username FROM users WHERE id = NEW.user_id;

  -- Create notification for the video owner
  INSERT INTO notifications (user_id, type, title, message, related_user_id, related_video_id)
  VALUES (
    video_owner_id,
    'like',
    'New Like',
    liker_username || ' liked your video',
    NEW.user_id,
    NEW.video_id
  );

  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Drop and recreate trigger for video likes
DROP TRIGGER IF EXISTS trigger_notify_video_like ON likes;
CREATE TRIGGER trigger_notify_video_like
  AFTER INSERT ON likes
  FOR EACH ROW
  WHEN (NEW.video_id IS NOT NULL)
  EXECUTE FUNCTION notify_video_like();

-- =====================================================
-- TRIGGER FUNCTION: Comment Notifications
-- =====================================================
CREATE OR REPLACE FUNCTION notify_comment()
RETURNS TRIGGER AS $$
DECLARE
  commenter_username text;
  video_owner_id uuid;
  parent_comment_owner_id uuid;
BEGIN
  -- Get commenter's username
  SELECT username INTO commenter_username FROM users WHERE id = NEW.user_id;

  -- Get the video owner
  SELECT user_id INTO video_owner_id FROM videos WHERE id = NEW.video_id;

  -- If this is a reply to another comment
  IF NEW.parent_id IS NOT NULL THEN
    -- Get the parent comment owner
    SELECT user_id INTO parent_comment_owner_id FROM comments WHERE id = NEW.parent_id;

    -- Notify the parent comment owner (if not replying to self)
    IF parent_comment_owner_id != NEW.user_id THEN
      INSERT INTO notifications (user_id, type, title, message, related_user_id, related_video_id, related_comment_id)
      VALUES (
        parent_comment_owner_id,
        'comment_reply',
        'New Reply',
        commenter_username || ' replied to your comment',
        NEW.user_id,
        NEW.video_id,
        NEW.id
      );
    END IF;

    -- Also notify video owner if they're not the commenter and not the parent comment owner
    IF video_owner_id != NEW.user_id AND video_owner_id != parent_comment_owner_id THEN
      INSERT INTO notifications (user_id, type, title, message, related_user_id, related_video_id, related_comment_id)
      VALUES (
        video_owner_id,
        'comment',
        'New Comment',
        commenter_username || ' commented on your video',
        NEW.user_id,
        NEW.video_id,
        NEW.id
      );
    END IF;
  ELSE
    -- This is a top-level comment, notify video owner
    IF video_owner_id != NEW.user_id THEN
      INSERT INTO notifications (user_id, type, title, message, related_user_id, related_video_id, related_comment_id)
      VALUES (
        video_owner_id,
        'comment',
        'New Comment',
        commenter_username || ' commented on your video',
        NEW.user_id,
        NEW.video_id,
        NEW.id
      );
    END IF;
  END IF;

  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Drop and recreate trigger for comments
DROP TRIGGER IF EXISTS trigger_notify_comment ON comments;
CREATE TRIGGER trigger_notify_comment
  AFTER INSERT ON comments
  FOR EACH ROW
  EXECUTE FUNCTION notify_comment();

-- =====================================================
-- TRIGGER FUNCTION: Comment Like Notifications
-- =====================================================
CREATE OR REPLACE FUNCTION notify_comment_like()
RETURNS TRIGGER AS $$
DECLARE
  liker_username text;
  comment_owner_id uuid;
BEGIN
  -- Only process comment likes (not video likes)
  IF NEW.comment_id IS NULL THEN
    RETURN NEW;
  END IF;

  -- Get the comment owner
  SELECT user_id INTO comment_owner_id FROM comments WHERE id = NEW.comment_id;

  -- Don't notify if user likes their own comment
  IF comment_owner_id = NEW.user_id THEN
    RETURN NEW;
  END IF;

  -- Get liker's username
  SELECT username INTO liker_username FROM users WHERE id = NEW.user_id;

  -- Create notification for the comment owner
  INSERT INTO notifications (user_id, type, title, message, related_user_id, related_comment_id)
  VALUES (
    comment_owner_id,
    'comment_like',
    'New Like',
    liker_username || ' liked your comment',
    NEW.user_id,
    NEW.comment_id
  );

  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Drop and recreate trigger for comment likes
DROP TRIGGER IF EXISTS trigger_notify_comment_like ON likes;
CREATE TRIGGER trigger_notify_comment_like
  AFTER INSERT ON likes
  FOR EACH ROW
  WHEN (NEW.comment_id IS NOT NULL)
  EXECUTE FUNCTION notify_comment_like();