/*
  # Add Privacy & Safety Features

  ## Overview
  This migration adds comprehensive privacy settings, blocking, reporting, and watch history features
  required for production app store compliance.

  ## Changes Made

  ### 1. User Privacy Settings
  - Add privacy settings columns to users table:
    - is_private (private account toggle)
    - who_can_comment (Everyone/Followers/NoOne)
    - who_can_message (Everyone/Followers/NoOne)
    - who_can_mention (Everyone/Followers/NoOne)
    - allow_downloads (boolean)

  ### 2. Blocked Users Table
  Creates `blocked_users` table to manage user blocking:
  - blocker_id: User who is blocking
  - blocked_id: User who is being blocked
  - Prevents blocked users from interacting
  
  ### 3. Reports Table
  Creates `reports` table for user and content reporting:
  - reporter_id: User making the report
  - reported_user_id: User being reported (if applicable)
  - reported_video_id: Video being reported (if applicable)
  - report_type: Type of violation
  - description: Details of the report
  - status: pending/reviewed/resolved

  ### 4. Watch History Table
  Creates `watch_history` table to track viewed videos:
  - user_id: Viewer
  - video_id: Watched video
  - watched_at: Timestamp
  - watch_duration: How long watched (seconds)

  ## Security
  - RLS enabled on all new tables
  - Users can only manage their own blocks and reports
  - Admin access for reviewing reports
  - Privacy settings enforced at database level
*/

-- =====================================================
-- 1. Add Privacy Settings to Users Table
-- =====================================================

DO $$
BEGIN
  -- Add is_private column
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'users' AND column_name = 'is_private'
  ) THEN
    ALTER TABLE users ADD COLUMN is_private boolean DEFAULT false;
  END IF;

  -- Add who_can_comment column
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'users' AND column_name = 'who_can_comment'
  ) THEN
    ALTER TABLE users ADD COLUMN who_can_comment text DEFAULT 'Everyone' CHECK (who_can_comment IN ('Everyone', 'Followers', 'NoOne'));
  END IF;

  -- Add who_can_message column
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'users' AND column_name = 'who_can_message'
  ) THEN
    ALTER TABLE users ADD COLUMN who_can_message text DEFAULT 'Everyone' CHECK (who_can_message IN ('Everyone', 'Followers', 'NoOne'));
  END IF;

  -- Add who_can_mention column
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'users' AND column_name = 'who_can_mention'
  ) THEN
    ALTER TABLE users ADD COLUMN who_can_mention text DEFAULT 'Everyone' CHECK (who_can_mention IN ('Everyone', 'Followers', 'NoOne'));
  END IF;

  -- Add allow_downloads column
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'users' AND column_name = 'allow_downloads'
  ) THEN
    ALTER TABLE users ADD COLUMN allow_downloads boolean DEFAULT true;
  END IF;
END $$;

-- =====================================================
-- 2. Create Blocked Users Table
-- =====================================================

CREATE TABLE IF NOT EXISTS blocked_users (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  blocker_id uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  blocked_id uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  created_at timestamptz DEFAULT now(),
  UNIQUE(blocker_id, blocked_id),
  CHECK (blocker_id != blocked_id)
);

CREATE INDEX IF NOT EXISTS idx_blocked_users_blocker ON blocked_users(blocker_id);
CREATE INDEX IF NOT EXISTS idx_blocked_users_blocked ON blocked_users(blocked_id);

ALTER TABLE blocked_users ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view their blocks"
  ON blocked_users FOR SELECT
  TO authenticated
  USING (auth.uid() = blocker_id);

CREATE POLICY "Users can create blocks"
  ON blocked_users FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = blocker_id);

CREATE POLICY "Users can delete their blocks"
  ON blocked_users FOR DELETE
  TO authenticated
  USING (auth.uid() = blocker_id);

-- =====================================================
-- 3. Create Reports Table
-- =====================================================

CREATE TABLE IF NOT EXISTS reports (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  reporter_id uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  reported_user_id uuid REFERENCES users(id) ON DELETE CASCADE,
  reported_video_id uuid REFERENCES videos(id) ON DELETE CASCADE,
  report_type text NOT NULL CHECK (report_type IN (
    'spam',
    'harassment',
    'hate_speech',
    'violence',
    'nudity',
    'misinformation',
    'copyright',
    'other'
  )),
  description text,
  status text DEFAULT 'pending' CHECK (status IN ('pending', 'reviewed', 'resolved', 'dismissed')),
  admin_notes text,
  created_at timestamptz DEFAULT now(),
  reviewed_at timestamptz,
  reviewed_by uuid REFERENCES users(id),
  CHECK (reported_user_id IS NOT NULL OR reported_video_id IS NOT NULL)
);

CREATE INDEX IF NOT EXISTS idx_reports_reporter ON reports(reporter_id);
CREATE INDEX IF NOT EXISTS idx_reports_status ON reports(status);
CREATE INDEX IF NOT EXISTS idx_reports_created ON reports(created_at DESC);

ALTER TABLE reports ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view their own reports"
  ON reports FOR SELECT
  TO authenticated
  USING (auth.uid() = reporter_id);

CREATE POLICY "Users can create reports"
  ON reports FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = reporter_id);

CREATE POLICY "Admins can view all reports"
  ON reports FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM users
      WHERE users.id = auth.uid()
      AND users.is_admin = true
    )
  );

CREATE POLICY "Admins can update reports"
  ON reports FOR UPDATE
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM users
      WHERE users.id = auth.uid()
      AND users.is_admin = true
    )
  )
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM users
      WHERE users.id = auth.uid()
      AND users.is_admin = true
    )
  );

-- =====================================================
-- 4. Create Watch History Table
-- =====================================================

CREATE TABLE IF NOT EXISTS watch_history (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  video_id uuid NOT NULL REFERENCES videos(id) ON DELETE CASCADE,
  watched_at timestamptz DEFAULT now(),
  watch_duration integer DEFAULT 0,
  UNIQUE(user_id, video_id, watched_at)
);

CREATE INDEX IF NOT EXISTS idx_watch_history_user ON watch_history(user_id, watched_at DESC);
CREATE INDEX IF NOT EXISTS idx_watch_history_video ON watch_history(video_id);

ALTER TABLE watch_history ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view their own watch history"
  ON watch_history FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can add to their watch history"
  ON watch_history FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can delete their watch history"
  ON watch_history FOR DELETE
  TO authenticated
  USING (auth.uid() = user_id);
