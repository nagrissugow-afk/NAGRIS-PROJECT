/*
  # Add Admin and Test Account Fields

  1. Changes
    - Add `is_admin` column to users table (boolean, default false)
    - Add `is_test_account` column to users table (boolean, default false)
  
  2. Purpose
    - Enable admins to bypass live streaming restrictions
    - Allow test accounts for development/testing without requiring 500 followers
    - Normal users still require verification or 500 followers to live stream
*/

-- Add is_admin field
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'users' AND column_name = 'is_admin'
  ) THEN
    ALTER TABLE users ADD COLUMN is_admin boolean DEFAULT false NOT NULL;
  END IF;
END $$;

-- Add is_test_account field
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'users' AND column_name = 'is_test_account'
  ) THEN
    ALTER TABLE users ADD COLUMN is_test_account boolean DEFAULT false NOT NULL;
  END IF;
END $$;

-- Create index for faster queries
CREATE INDEX IF NOT EXISTS idx_users_admin ON users(is_admin) WHERE is_admin = true;
CREATE INDEX IF NOT EXISTS idx_users_test_account ON users(is_test_account) WHERE is_test_account = true;